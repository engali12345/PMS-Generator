PMS GENERATOR  v1.3.0
Primavera P6 XER to PMS Excel Automation
Developed by Eng. Ali Ahmed | IGCC
(c) 2026 PMS Generator. Developed by Eng. Ali Ahmed / IGCC. All Rights Reserved.
=====================================================================================

ملاحظة صريحة / READ FIRST - what was and was NOT tested (details in section 9)
  - الواجهة (PySide6) والـ EXE: ما انفتحت ولا انبنت بالبيئة اللي طورت بيها (Linux بدون Qt وبدون Windows).
    اختبرت منطق الواجهة بدون Qt فقط. لازم تجرب الواجهة والـ EXE على Windows (خطوات 3 و 4).
  - الـ Baseline والأوزان بالتكلفة/الموارد: ما اختبرتها على XER حقيقي (الملف الحقيقي MWP-CB38 ما فيه Baseline ولا موارد).

1) الملفات
   pms_main.py              نقطة التشغيل                      p6_to_pms.py   المحرك (+ سطر الأوامر)
   pms_gui.py               الواجهة (PySide6)                  pms_weights.py خيارات الأوزان
   pms_continue.py          استكمال PMS سابق                   pms_common.py  الهوية/أخطاء/مساعدات
   PMS_Master_Template.xlsx القالب الموحّد (تنسيق ومعادلات فقط)
   pms_icon.ico / .png      الأيقونة (make_icon.py يرسمها)
   Run_PMS_Generator.bat    تشغيل من ملفات Python               Build_EXE.bat  بناء PMS_Generator.exe
   LICENSE.txt, THIRD_PARTY_LICENSES.txt, requirements.txt, tests\ (pytest unit tests + standalone regression scripts), sample_MWP-CB38\

2) تغيير اللوگو والألوان
   من داخل البرنامج اضغط Appearance. اختر صورة اللوگو والألوان ثم Save and apply. تحفظ الإعدادات في %LOCALAPPDATA%\PMS_Generator\appearance.json، ولا تحتاج إعادة بناء EXE لتغييرها. لتغيير أيقونة ملف EXE نفسها (أيقونة Windows) أعد بناء EXE بعد استبدال pms_icon.ico.

2b) اللوكو والثيم الافتراضي (جديد)
   - اللوكو الافتراضي صار صورتك (pms_logo.png): تظهر كاملة بشاشة البداية وبنافذة About، والشعار الدائري (الترس والسهم)
     مقصوص منها للأيقونة (pms_icon.png / pms_icon.ico) وللهيدر. make_icon.py يعيد توليد الأيقونات من pms_logo.png.
   - الثيم الافتراضي: خلفية غامقة فخمة مع لون ذهبي مأخوذ من اللوكو، وخطوط Segoe UI واضحة. الألوان الثلاثة اللي تغيّرها بنافذة
     Appearance (Header/Buttons/Background) تشتق منها بقية الألوان تلقائياً، وإذا اخترت خلفية فاتحة ينتقل لثيم فاتح مقروء.
   - إذا كنت محفوظ ألوان قديمة (appearance.json بـ %LOCALAPPDATA%\PMS_Generator): اضغط Appearance ثم Reset defaults ثم Save and apply
     حتى يظهر الثيم الجديد، أو احذف الملف.
   - أيقونة ملف EXE نفسها (Windows) تتغير فقط بإعادة تشغيل Build_EXE.bat.

2c) ألوان الـ WBS ومشروع مستقل لكل XER (v1.2.0 + واجهة الوضعين v1.3.0)
   - السبب القديم: القالب فيه 6 مستويات ألوان فقط (أرجواني، ذهبي غامق، أخضر، أصفر، أزرق، أحمر). المستويات 7 وما فوق كانت ترجع
     للمستوى الأخير = أحمر، وألوان 1-6 كانت تنسخ من قالب Mishrif Qurainat لأي مشروع. هذا انصلح: اللون يتحدد حسب المستوى (الرقم بعمود B)
     أو حسب عقدة الـ WBS، مو حسب رقم الصف، ولكل لون مصدر مسجل.
   - المصدر الحقيقي لألوان P6: ألوان العرض بـ P6 تنخزن بالـ Layout (Group & Sort)، وملف XER ما يصدّر الـ Layout. فحصت XER الحقيقي (9 جداول):
     ما فيه أي حقل لون ولا UDF. لذلك البرنامج ما يقدر يعرف ألوانك من الـ XER لحاله، وما يدّعي ذلك.
   - ترتيب المصادر لكل صف WBS:
       VERIFIED   لون صريح داخل XER نفس المشروع: حقل بـ PROJWBS اسمه يحتوي color/colour، أو حقل UDF على الـ WBS اسمه يحتوي color
                  وقيمته hex مثل #FFC000 (تقدر تسوي UDF بـ P6: Enterprise > Data > User Defined Fields > WBS).
       USER       خريطة ألوان تزوّدها للمشروع: ملف .json أو .csv (Level,Color) أو ملف PMS .xlsx تنسخ منه ألوان المستويات
                  (Advanced settings > WBS colour map). تنحفظ تلقائياً لهذا المشروع فقط (حسب اسم المشروع) بـ
                  %LOCALAPPDATA%\PMS_Generator\color_maps ولا تنطبق على أي مشروع ثاني.
       FALLBACK   لوحة مستويات موثقة بالكود (15 لون مميز؛ 1-6 نفس الاصطلاح القديم، 7+ ألوان مختلفة). تنذكر كتحذير، وهي مو ألوان P6.
       UNAVAILABLE بدون لون، إذا اخترت "No colour" بـ Advanced.
   - مثال CSV:  Level,Color  ثم 1,#7030A0  2,#7F6000 ... 11,#996633      مثال JSON: {"levels": {"1": "#7030A0"}, "nodes": {"WBS-CODE": "#00FF7F"}}
   - تقرير التحقق فيه قسم WBS COLOR VALIDATION: عدد صفوف WBS والمستويات وعدد كل مصدر وسبب أي تحذير. عبارة "EXACT COLOR FIDELITY"
     تنكتب كنجاح فقط إذا كل صفوف WBS ألوانها من XER نفسه؛ غير هذا تنكتب NOT VERIFIED مع السبب. البرنامج يفحص الملف الناتج مقابل
     خطة الألوان (مو مقابل P6).
   - كل XER يُعالج لحاله: ما في كاش بين المشاريع، والواجهة تمسح قائمة المشاريع/الـ Baseline/ملف الألوان/ملف التكلفة عند تحميل XER ثاني.


2d) WBS Color Mapping — Auto Color / Manual Color (v1.3.0)
   - الشاشة الرئيسية تحتوي على Auto Color وManual Color. يتم حفظ الوضع المفضل للمستخدم محلياً.
   - Auto Color: يقرأ الألوان الصريحة القابلة للتحقق من XER. إذا لم توجد، يظهر Source Colors Unavailable؛ لا تُقدّم لوحة FALLBACK على أنها ألوان P6. يمكن تعطيل استخدام الخرائط المحفوظة تلقائياً في هذا الوضع.
   - Manual Color: ينشئ صفاً لكل مستوى WBS المكتشف من سلسلة parent_wbs_id في XER، مع معاينة لون، اختيار لون كامل عبر Color Picker، وإدخال HEX. الأزرار تتيح Apply / Save Project Mapping / Reset / Import / Export.
   - تُحفظ خريطة الواجهة باسم يحتوي على معرف مشروع P6 وبصمة الهوية، وليس اسم المشروع وحده. الخرائط اليدوية تتطلب XER بمشروع واحد لتجنّب خلط ألوان عدة مشاريع في خريطة واحدة.
   - مصدر اللون يسجل VERIFIED / USER / FALLBACK / UNAVAILABLE في منطق التحقق الحالي. ألوان WBS لا تطبّق على صفوف الأنشطة.
   - تنبيه: لا يمكن التحقق من ألوان Layout المعروضة في Primavera من XER عادي وحده؛ للحصول على ألوان P6 الأصلية يلزم مصدر موثوق إضافي (مثل Layout أو خريطة مؤكدة من المشروع).

3) التشغيل من الملفات (بدون بناء EXE)
   pip install -r requirements.txt        (مرة وحدة: openpyxl + PySide6)
   دبل كلك Run_PMS_Generator.bat  -> تنفتح النافذة.  أو اسحب ملف .xer على الملف.
   إذا PySide6 مو مثبت، يفتح شباك Tk بسيط كبديل (بدون اختيار مشاريع/أوزان).

4) بناء EXE على Windows
   دبل كلك Build_EXE.bat (يحتاج Python 3.10+ ونت لتنزيل المكتبات مرة وحدة). تم إصلاح ملف البناء ليستخدم Python الخاص بالبيئة مباشرة بدل أمر pip المنفصل، وينشئ بيئة نظيفة عند الحاجة.
   الناتج: dist\PMS_Generator\PMS_Generator.exe  (مجلد كامل؛ انسخ المجلد كله لأي جهاز).
   اختبره: دبل كلك على الـ exe بدون CMD، اختر XER، Generate PMS. إذا طلع خطأ ابعثلي ملف Log (زر Log بالنافذة).
   مبني كـ one-dir (مجلد) حتى يبقى متوافق مع ترخيص LGPL لمكتبة Qt. أول تشغيل ممكن يبطّي ثواني، وبعض برامج الحماية
   تحذّر من أي exe جديد غير موقّع.

5) خطوات الاستخدام
   1- اختر ملف XER (سحب وإفلات أو Browse). يظهر الاسم والمسار والحجم والمشاريع وحالة الـ Baseline والموارد.
      إذا الملف فيه أكثر من مشروع: علّم المشروع/المشاريع المطلوبة (ما ينحمّل شي بدون اختيارك).
   2- مجلد الإخراج (الافتراضي بجنب الـ XER). الاسم: PMS_<Project>_Rev00.xlsx  (Rev = رقم التقرير - 1).
   3- إعدادات التقرير: رقم التقرير (تلقائي)، تاريخ نهاية الفترة (افتراضي = Data Date من P6)،
      وPMS سابق (اختياري) لاستكمال الفترة التالية.
   4- Weight Settings (القسم 6).  5- Advanced (اختياري).  6- GENERATE PMS.
   بعد النجاح: Open PMS (Excel) / Open results folder / Validation report / Log.
   إذا الملف موجود: يسألك Replace أو Keep both أو Cancel (ما يستبدل بدون تأكيدك).
   لا يعدّل ملف الـ XER ولا القالب، ولا يرسل أي ملف للإنترنت.

6) Baseline
   المحرك يفحص جدول PROJECT (sum_base_proj_id، orig_proj_id، base_type_id، project_flag،
   baselines_to_export، baseline_names_to_export، last_baseline_update_date) ويطابق أنشطة الـ Baseline بالـ Activity ID.
   الحالات: FOUND (موجود وانستخرج) | NOT_IN_FILE (ما موجود بالملف) | PARTIAL (جزئي أو ما ينربط بثقة)
            | NOT_EXPORTED (P6 فيه Baseline بس ما انصدّر مع الملف).
   BL PROJECT START/FINISH (شيت S-CURVE، الخلايا B1:C2) تنكتب من بيانات الـ Baseline فقط، وإلا NOT AVAILABLE
   مع السبب بتقرير التحقق. ما تنستخدم تواريخ الجدول الحالي كـ Baseline أبداً.
   PLANNED START/FINISH = تواريخ الـ Baseline إذا موجود (إعداد Planned dates بـ Advanced)، وإلا التواريخ الحالية + تحذير.
   لو P6 يعرض BL Start/Finish بس الأداة تقول "ما موجود": افتح تقرير التحقق، قسم Baseline diagnostics: يطبع حقول PROJECT
   كما وردت بالملف. الحل غالباً: ثبّت الـ Baseline كـ Project Baseline بالمشروع، وصدّر XER وعلّم الـ Baseline ضمن
   خطوات التصدير (اسم الخطوة قد يختلف بين إصدارات P6)، ثم اعمل Inspect للتأكد.

7) Weight Settings  (عمود G = BUDGETED UNIT؛ عمود F = G / المجموع، فمجموع الأوزان 100% تلقائياً على الأنشطة اللي لها بيانات)
   الافتراضي: No Automatic Weighting (فارغ، إدخال يدوي).
   A Cost-Based: Schedule Baseline Cost (تكلفة مشروع الـ Baseline) | Current Budgeted Cost (التكلفة الحالية) |
     Manual Input/Custom Cost (فارغ إلا إذا حددت ملف CSV/XLSX بعمودين: Activity ID, Cost).
     التكلفة = مجموع TASKRSRC.target_cost + مصاريف PROJCOST. ما نخلط التكلفة الحالية بالـ Baseline.
   B Resource-Based: Man-Hours (TASKRSRC.target_qty للعمالة RT_Labor فقط) | Total Resource Units (عمالة+معدات؛ المواد فقط
     إذا وحدتها ساعات). إذا عندك مواد بوحدات مختلفة: يرفض ويحذّر بدل ما ينتج أوزان مضللة.
   C Equal (1 لكل نشاط) | Duration (المدة المخططة بالساعات) | None.
   قواعد: الـ Milestones وLOE وWBS Summary وزنها 0. الأنشطة اللي ما عندها بيانات: G فارغ وتنذكر بالتقرير.
   كل صف تخصيص (taskrsrc_id) ينحسب مرة وحدة. هذي أوزان محسوبة من الجدول، مو أوزان تعاقدية معتمدة.
   إذا الأوزان فارغة، ملف S-CURVE يكتب تحذير أن التقدم الموزون غير صالح لحد الإدخال.

8) استكمال PMS سابق
   يحافظ على: رقم التقرير+1، بداية الفترة = نهاية السابقة+1، CUM السابق (PREV. PERIOD وCUM يبدأن بقيمة السابق كنسبة
   = CUM/BUG QTY)، التواريخ الفعلية، الأوزان (إذا ما اخترت طريقة أوزان تلقائية)، وتاريخ منحنى S الفعلي.
   المطابقة: Activity ID + الاسم + مسار WBS. نفس الـ ID مع تغيير الاسم والـ WBS معاً = "suspect" ما تنتقل بياناته
   (تنذكر بالتقرير). ما تنتقل بيانات نشاط لنشاط ثاني. إذا الخلايا بالـ PMS السابق معادلات بلا قيمة محفوظة:
   افتح الملف بـ Excel واحفظه ثم أعد التشغيل.

9) ملفات الإخراج
   PMS_<Project>_RevNN.xlsx  (+ PMS_<Project>_RevNN_validation.txt).  Errors = الملف فيه مشكلة بنيوية؛
   Warnings = انولد بس يحتاج مراجعتك. Log: %LOCALAPPDATA%\PMS_Generator\logs\pms_generator.log
   تعديلات على معادلات القالب: الوحيد: عمود F صار =IFERROR(G/$G$8,0) حتى لا يظهر #DIV/0! قبل إدخال الأوزان.
   #N/A بالصفين 8 و9 من S-CURVE بعد تاريخ التقرير مقصود (من القالب). اسم الشيت صار PMS.

10) شنو انختبر فعلاً
   حقيقي: ملف XER حقيقي واحد (MWP-CB38، 182 نشاط): استيراد كامل، المعادلات بدون أخطاء (LibreOffice)، ألوان/ترتيب.
   محاكاة (مصنوعة بالكود، مو تصدير P6): مشروع 132kV مبني من القالب (289 صف مطابقة)، مشروعان بـ XER واحد، Baseline
     (مربوط/غير مربوط/غير مصدّر)، موارد وتكلفة، مشروع ضخم 1800 نشاط، أسماء عربية cp1256/utf-8،
     استكمال تقرير سابق (renamed/moved/new/removed/suspect). الأوزان قورنت بحساب مستقل ومجموع F = 100%.
   لم ينختبر: الواجهة الحقيقية (Qt)، بناء/تشغيل EXE، XER حقيقي فيه Baseline أو موارد/تكلفة، فتح الملفات بـ Excel نفسه
     (جرّبت LibreOffice)، XER بترميزات غير cp1252/cp1256/utf-8.
   tests\: test_wbs_mapping_modes.py (unit tests) | wbs_colors_regression.py (standalone regression suite) | continue_regression.py (PMS continuation) | gui_stub_smoke.py (optional logic smoke test) | make_test_xers.py | verify_calc.py
