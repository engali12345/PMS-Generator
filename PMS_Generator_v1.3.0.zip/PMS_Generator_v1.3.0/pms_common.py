# -*- coding: utf-8 -*-
"""Shared constants, branding, exceptions and small helpers (no heavy imports)."""
import logging
import logging.handlers
import os
import re
import sys
from datetime import datetime

# ------------------------------------------------------------------ branding
APP_NAME = "PMS GENERATOR"
APP_SUBTITLE = "Primavera P6 XER to PMS Excel Automation"
APP_VERSION = "1.3.0"
DEVELOPER = "Eng. Ali Ahmed"
DEVELOPER_UPPER = "ENG. ALI AHMED"
DEVELOPER_ORG = "IGCC"
COPYRIGHT = "\u00a9 2026 PMS Generator. Developed by Eng. Ali Ahmed / IGCC. All Rights Reserved."
FOOTER = "Developed by Eng. Ali Ahmed | IGCC"


class PmsError(Exception):
    """A problem the user can understand (bad file, bad template ...). Blocks file creation."""


class PmsExistsError(PmsError):
    """The output file already exists and overwrite was not confirmed."""

    def __init__(self, path):
        super().__init__("The output file already exists: %s" % path)
        self.path = path


class PmsChooseProject(PmsError):
    """The XER holds several live projects and the caller did not say which one to use."""

    def __init__(self, projects):
        self.projects = projects
        super().__init__("The XER contains %d projects. Choose the project to convert (or 'all'): %s" % (
            len(projects), "; ".join("%s [id %s]" % (p["short"], p["id"]) for p in projects)))


# ------------------------------------------------------------------ helpers
def dt(s):
    """P6 date text -> datetime at midnight (PMS works with whole days, like the template)."""
    s = (s or "").strip()
    if not s:
        return None
    for f in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            d = datetime.strptime(s, f)
            return datetime(d.year, d.month, d.day)
        except ValueError:
            pass
    return None


def num(s, d=0.0):
    try:
        return float(str(s).strip())
    except (ValueError, TypeError):
        return d


def mn(xs):
    xs = [x for x in xs if x]
    return min(xs) if xs else None


def mx(xs):
    xs = [x for x in xs if x]
    return max(xs) if xs else None


def natkey(s):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", s or "")]


def safe_filename(s, default="Project"):
    s = re.sub(r"[\\/:*?\"<>|\r\n\t]+", "_", (s or "").strip())
    s = re.sub(r"\s+", "_", s).strip("._")
    return (s or default)[:60]


def app_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_path(name):
    """Find a bundled data file (PyInstaller aware)."""
    for base in (app_dir(), os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else None, os.getcwd()):
        if base and os.path.isfile(os.path.join(base, name)):
            return os.path.join(base, name)
    return os.path.join(app_dir(), name)


def log_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, "PMS_Generator", "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = os.path.join(os.path.expanduser("~"), "PMS_Generator_logs")
        os.makedirs(d, exist_ok=True)
    return d


def log_path():
    return os.path.join(log_dir(), "pms_generator.log")


_LOGGER = None


def get_logger():
    global _LOGGER
    if _LOGGER is None:
        lg = logging.getLogger("pms")
        lg.setLevel(logging.DEBUG)
        if not lg.handlers:
            try:
                h = logging.handlers.RotatingFileHandler(log_path(), maxBytes=1_000_000, backupCount=3, encoding="utf-8")
                h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
                lg.addHandler(h)
            except OSError:
                lg.addHandler(logging.NullHandler())
        _LOGGER = lg
    return _LOGGER
