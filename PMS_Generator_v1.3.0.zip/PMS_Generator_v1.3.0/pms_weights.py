# -*- coding: utf-8 -*-
"""
Weight Settings for the PMS (column G = BUDGETED UNIT).

The template turns column G into ABSOLUTE WTG (column F = G / total), so G only needs a RELATIVE value
(cost, man-hours, duration ...). The weights therefore always add up to 100 % over the activities that have data.

Nothing is invented: activities without data keep G EMPTY and are listed in the validation report.
Milestones and activities that are not real work (Level of Effort, WBS Summary) get weight 0.
"""
import csv
import os
from collections import Counter, defaultdict

from pms_common import PmsError, num

METHODS = {
    "none": "No Automatic Weighting (manual entry)",
    "cost_baseline": "Cost-Based: Schedule Baseline Cost",
    "cost_current": "Cost-Based: Current Budgeted Cost",
    "cost_custom": "Cost-Based: Manual Input / Custom Cost file",
    "res_labor": "Resource-Based: Man-Hours (Labor only)",
    "res_total": "Resource-Based: Total Resource Units (Labor + Non-Labor)",
    "equal": "Equal Weight per Activity",
    "duration": "Duration-Based Weight",
}
TIME_UNITS = {"h", "hr", "hrs", "hour", "hours"}
NON_WORK_TYPES = ("TT_LOE", "TT_WBS")          # not real work -> weight 0
MILESTONES = ("TT_Mile", "TT_FinMile")


def _key(a):
    return (a["proj"], a["id"])


def _read_custom_cost(path):
    """CSV or XLSX with an 'Activity ID' column and a 'Cost' column (case-insensitive, first sheet)."""
    if not path or not os.path.isfile(path):
        raise PmsError("The custom cost file was not found.")
    rows = []
    if path.lower().endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        ws = load_workbook(path, read_only=True, data_only=True).worksheets[0]
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
    else:
        raw = open(path, "rb").read()
        for enc in ("utf-8-sig", "cp1256", "cp1252"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        dialect = csv.Sniffer().sniff(text[:2000], delimiters=",;\t") if text.strip() else csv.excel
        rows = list(csv.reader(text.splitlines(), dialect))
    hdr_i = None
    for i, r in enumerate(rows[:30]):
        cells = [str(c or "").strip().lower() for c in r]
        if any(c in ("activity id", "activity_id", "task_code", "id") for c in cells):
            hdr_i = i
            break
    if hdr_i is None:
        raise PmsError("Custom cost file: a header row with 'Activity ID' and 'Cost' was not found.")
    cells = [str(c or "").strip().lower() for c in rows[hdr_i]]
    ci = next(i for i, c in enumerate(cells) if c in ("activity id", "activity_id", "task_code", "id"))
    cc = next((i for i, c in enumerate(cells) if c in ("cost", "budgeted cost", "budget", "amount", "value")), None)
    if cc is None:
        raise PmsError("Custom cost file: a 'Cost' column was not found.")
    out, dup = {}, []
    for r in rows[hdr_i + 1:]:
        if ci >= len(r) or cc >= len(r) or r[ci] in (None, ""):
            continue
        k = str(r[ci]).strip()
        try:
            v = float(str(r[cc]).replace(",", "").strip())
        except ValueError:
            continue
        if k in out:
            dup.append(k)
        out[k] = v
    return out, dup


def compute_weights(T, model, opts):
    """Returns dict(method, label, unit, values{(proj,id): number|None}, notes, warnings, missing, zero_weight, applied, total)."""
    method = opts.get("weight_method") or "none"
    if method not in METHODS:
        raise PmsError("Unknown weight method: %s" % method)
    res = dict(method=method, label=METHODS[method], unit="", values={}, notes=[], warnings=[], missing=[], zero_weight=[],
               applied=False, total=0.0, source="")
    acts = model["acts"]
    if method == "none":
        res["notes"].append("Weights are left EMPTY - enter BUDGETED UNIT manually.")
        return res
    live_ids = {a["proj"] for a in acts}

    def finish(values, unit, source):
        total = sum(v for v in values.values() if v)
        res.update(values=values, unit=unit, source=source, total=total, applied=total > 0)
        if total <= 0:
            res["applied"] = False
            res["values"] = {}
            res["warnings"].append("WEIGHTS NOT APPLIED: the chosen source produced a total of 0 - G was left empty.")
        return res

    def classify(a):
        if a["type"] in MILESTONES:
            return "milestone"
        if a["type"] in NON_WORK_TYPES:
            return "nonwork"
        return "work"

    # ---------------------------------------------------------------- equal / duration
    if method in ("equal", "duration"):
        values = {}
        for a in acts:
            c = classify(a)
            if c != "work":
                values[_key(a)] = 0
                res["zero_weight"].append("%s (%s)" % (a["id"], "milestone" if c == "milestone" else "LOE/WBS summary"))
            elif method == "equal":
                values[_key(a)] = 1
            elif a["dur_hr"] > 0:
                values[_key(a)] = a["dur_hr"]
            else:
                values[_key(a)] = 0
                res["zero_weight"].append("%s (zero duration)" % a["id"])
        res["notes"].append("Milestones, Level-of-Effort and WBS-Summary activities get weight 0.")
        if method == "duration":
            res["notes"].append("Duration weight = planned (target) duration in working hours from P6; G shows hours.")
        return finish(values, "activities" if method == "equal" else "hours", "XER TASK table")

    if method == "cost_baseline" and (model["baseline"]["state"] not in ("FOUND", "PARTIAL") or not any(a["bl_task_id"] for a in acts)):
        res["warnings"].append("WEIGHTS NOT APPLIED: Baseline cost needs a baseline project inside the XER (baseline state: %s). "
                               "Current budgeted cost was NOT substituted - they are different data." % model["baseline"]["state"])
        return res

    # ---------------------------------------------------------------- everything below needs assignments or custom costs
    tr_all = T.get("TASKRSRC", [])
    if method != "cost_custom" and not tr_all and not (method.startswith("cost") and T.get("PROJCOST")):
        res["warnings"].append("WEIGHTS NOT APPLIED: the XER has no resource assignments (table TASKRSRC) / costs. "
                               "Export the XER with resource assignments, or choose another weight source.")
        return res

    rsrc = {r["rsrc_id"]: r for r in T.get("RSRC", [])}
    unit_names = {u.get("unit_id"): (u.get("unit_abbrev_name") or u.get("unit_name") or "").strip().lower() for u in T.get("UNIT", [])}

    def assignments(task_ids, proj_ids):
        seen, per = set(), defaultdict(list)
        dups = 0
        for r in tr_all:
            if r.get("proj_id") not in proj_ids or r.get("task_id") not in task_ids:
                continue
            pk = r.get("taskrsrc_id")
            if pk:                                   # the primary key identifies a row; the same row twice = double counting
                if pk in seen:
                    dups += 1
                    continue
                seen.add(pk)
            per[r.get("task_id")].append(r)
        if dups:
            res["warnings"].append("%d duplicated assignment rows (same taskrsrc_id) were ignored to avoid double counting." % dups)
        return per

    def expenses(task_ids, proj_ids):
        per = defaultdict(float)
        for c in T.get("PROJCOST", []):
            if c.get("proj_id") in proj_ids and c.get("task_id") in task_ids:
                per[c["task_id"]] += num(c.get("target_cost"))
        return per

    # ---------------------------------------------------------------- cost based
    if method.startswith("cost"):
        values, missing = {}, []
        if method == "cost_custom":
            path = opts.get("custom_cost_file")
            if not path:
                res["notes"].append("Manual Input selected without a custom cost file: weights are left EMPTY for manual entry.")
                return res
            costs, dup = _read_custom_cost(path)
            if dup:
                res["warnings"].append("Custom cost file: duplicated Activity IDs (last value used): %s" % ", ".join(dup[:8]))
            known = {a["id"] for a in acts}
            unknown = [k for k in costs if k not in known]
            if unknown:
                res["warnings"].append("Custom cost file: %d Activity IDs are not in the XER and were ignored (first: %s)." % (
                    len(unknown), ", ".join(unknown[:8])))
            dupids = {i for i, n in Counter(a["id"] for a in acts).items() if n > 1}
            for a in acts:
                c = classify(a)
                if c != "work":
                    values[_key(a)] = 0
                    res["zero_weight"].append("%s (%s)" % (a["id"], "milestone" if c == "milestone" else "LOE/WBS summary"))
                elif a["id"] in dupids:
                    values[_key(a)] = None
                    missing.append("%s (same ID in several projects - cannot assign a cost safely)" % a["id"])
                elif a["id"] in costs:
                    values[_key(a)] = costs[a["id"]]
                else:
                    values[_key(a)] = None
                    missing.append(a["id"])
            res["missing"] = missing
            res["notes"].append("Weights come from the custom cost file: %s" % os.path.basename(path))
            return finish(values, "custom cost", "custom file")
        if method == "cost_baseline":
            if model["baseline"]["state"] not in ("FOUND", "PARTIAL") or not any(a["bl_task_id"] for a in acts):
                res["warnings"].append("WEIGHTS NOT APPLIED: Baseline cost needs a baseline project with resource assignments inside "
                                       "the XER (baseline state: %s). Current cost was NOT substituted - they are different data." %
                                       model["baseline"]["state"])
                return res
            bl_ids = {a["bl_task_id"] for a in acts if a["bl_task_id"]}
            bl_projs = {t_["proj_id"] for t_ in T["TASK"] if t_.get("task_id") in bl_ids}
            per = assignments(bl_ids, bl_projs)
            exp = expenses(bl_ids, bl_projs)
            tid = lambda a: a["bl_task_id"]
            src = "BASELINE project assignments (TASKRSRC.target_cost) + expenses"
            if not any(per.values()) and not exp:
                res["warnings"].append("WEIGHTS NOT APPLIED: the baseline project in the XER has no cost assignments.")
                return res
        else:
            tids = {a["task_id"] for a in acts}
            per = assignments(tids, live_ids)
            exp = expenses(tids, live_ids)
            tid = lambda a: a["task_id"]
            src = "CURRENT budgeted cost (TASKRSRC.target_cost) + expenses"
        curs = Counter(rsrc.get(r.get("rsrc_id"), {}).get("curr_id") for lst in per.values() for r in lst)
        curs.pop(None, None)
        if len([c for c in curs if c]) > 1:
            res["warnings"].append("Resources use more than one currency id (%s). P6 stores budgeted costs in the base currency; "
                                   "check that the values are comparable." % ", ".join(str(c) for c in curs))
        for a in acts:
            c = classify(a)
            t_ = tid(a)
            if c != "work":
                values[_key(a)] = 0
                res["zero_weight"].append("%s (%s)" % (a["id"], "milestone" if c == "milestone" else "LOE/WBS summary"))
                continue
            if method == "cost_baseline" and not t_:
                values[_key(a)] = None
                missing.append("%s (not in baseline)" % a["id"])
                continue
            lst = per.get(t_, [])
            cost = sum(num(r.get("target_cost")) for r in lst) + exp.get(t_, 0.0)
            if not lst and t_ not in exp:
                values[_key(a)] = None
                missing.append("%s (no cost assignment)" % a["id"])
            else:
                values[_key(a)] = cost
        res["missing"] = missing
        res["notes"].append("Source: %s. Each assignment row is counted once." % src)
        return finish(values, "cost", src)

    # ---------------------------------------------------------------- resource based
    tids = {a["task_id"] for a in acts}
    per = assignments(tids, live_ids)
    values, missing = {}, []
    non_comparable = Counter()
    for a in acts:
        for r in per.get(a["task_id"], []):
            rt = rsrc.get(r.get("rsrc_id"), {}).get("rsrc_type", "")
            if rt == "RT_Mat" and num(r.get("target_qty")) > 0:
                un = unit_names.get(rsrc.get(r.get("rsrc_id"), {}).get("unit_id"), "")
                if un not in TIME_UNITS:
                    non_comparable[un or "unit not defined"] += 1
    if method == "res_total" and non_comparable:
        res["warnings"].append(
            "WEIGHTS NOT APPLIED: Total Resource Units cannot be summed - the XER has material resources with different units (%s) "
            "that are not comparable with hours. Use Man-Hours (Labor only) or Cost instead." % ", ".join(
                "%s x%d" % kv for kv in non_comparable.items()))
        return res
    for a in acts:
        c = classify(a)
        if c != "work":
            values[_key(a)] = 0
            res["zero_weight"].append("%s (%s)" % (a["id"], "milestone" if c == "milestone" else "LOE/WBS summary"))
            continue
        lst = per.get(a["task_id"], [])
        if method == "res_labor":
            sel = [r for r in lst if rsrc.get(r.get("rsrc_id"), {}).get("rsrc_type") == "RT_Labor"]
        else:
            sel = [r for r in lst if rsrc.get(r.get("rsrc_id"), {}).get("rsrc_type") in ("RT_Labor", "RT_Equip", "RT_Mat")]
        if not sel:
            values[_key(a)] = None
            missing.append("%s (%s)" % (a["id"], "no labor assignment" if method == "res_labor" else "no resource assignment"))
        else:
            values[_key(a)] = sum(num(r.get("target_qty")) for r in sel)
    res["missing"] = missing
    if method == "res_labor":
        res["notes"].append("Man-hours = planned (budgeted) quantity of LABOR resources only (TASKRSRC.target_qty, hours). Each assignment row counted once.")
        return finish(values, "man-hours", "TASKRSRC labor")
    res["notes"].append("Total units = hours of labor + equipment (+ materials only when their unit is hours). Each assignment row counted once.")
    return finish(values, "resource hours", "TASKRSRC all resources")
