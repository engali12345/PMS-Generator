# -*- coding: utf-8 -*-
"""
PMS GENERATOR - desktop window (PySide6).
The window only collects settings and shows results; all the work is done by p6_to_pms.generate().
"""
import os
import sys
import traceback
import json
import shutil
from datetime import datetime
from string import Template

from PySide6.QtCore import QDate, QRect, QSize, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import (QColor, QDesktopServices, QFont, QIcon, QLinearGradient, QPainter, QPainterPath, QPalette, QPen,
                           QPixmap)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDateEdit, QDialog, QFileDialog, QColorDialog,
                               QFrame, QGridLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QRadioButton,
                               QScrollArea, QSizePolicy, QSpinBox, QSplashScreen, QStyle, QTableWidget, QTableWidgetItem, QHeaderView, QToolButton, QVBoxLayout,
                               QWidget)

from pms_common import (APP_NAME, APP_SUBTITLE, APP_VERSION, COPYRIGHT, DEVELOPER, DEVELOPER_ORG, DEVELOPER_UPPER,
                        FOOTER, PmsChooseProject, PmsError, PmsExistsError, get_logger, log_path, resource_path)

P = None            # the engine module, imported after the splash screen is visible
log = get_logger()

# Default look: deep charcoal-navy with antique gold (taken from the brand logo). The three colours below are what the
# Appearance dialog edits; every other colour (cards, borders, text, hover ...) is derived from them in derive_palette().
DEFAULT_NAVY, DEFAULT_ACCENT, DEFAULT_BG = "#070A10", "#CFA84B", "#0B0E14"
TEXT, MUTED = "#EEE9DD", "#9AA3B5"          # refreshed by build_stylesheet()
OK, WARN, ERR = "#44D19B", "#F2B84B", "#FF7070"
PAL = {}


def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _mix(a, b, t):
    ra, rb = _rgb(a), _rgb(b)
    return "#%02X%02X%02X" % tuple(round(x + (y - x) * t) for x, y in zip(ra, rb))


def _lum(h):
    def f(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = _rgb(h)
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def contrast_text(color):
    """Readable text colour (dark or white) to print on top of `color`."""
    return "#14110A" if _lum(color) > 0.30 else "#FFFFFF"


def derive_palette(navy, accent, bg):
    dark = _lum(bg) < 0.30
    if dark:
        return dict(dark=True, bg=bg, navy=navy, accent=accent, header2=_mix(navy, "#FFFFFF", 0.10),
                    card=_mix(bg, "#FFFFFF", 0.05), card2=_mix(bg, "#FFFFFF", 0.09), border=_mix(bg, "#FFFFFF", 0.15),
                    border2=_mix(bg, "#FFFFFF", 0.36), input=_mix(bg, "#000000", 0.30), text="#EEE9DD", muted="#9AA3B5",
                    title=accent, sub=_mix(accent, "#FFFFFF", 0.45), accent_h=_mix(accent, "#FFFFFF", 0.20),
                    accent_p=_mix(accent, "#000000", 0.18), on_accent=contrast_text(accent), dis_bg=_mix(bg, "#FFFFFF", 0.07),
                    dis_fg="#6E7788", drop_bg=_mix(bg, "#FFFFFF", 0.025), drop_border=_mix(accent, bg, 0.55),
                    ok="#44D19B", ok_bg="#0F3228", warn="#F2B84B", warn_bg="#38290E", err="#FF7070", err_bg="#3A1A1F",
                    gray_bg=_mix(bg, "#FFFFFF", 0.11), prog_bg=_mix(bg, "#FFFFFF", 0.11), badge_fg=contrast_text(accent))
    return dict(dark=False, bg=bg, navy=navy, accent=accent, header2=_mix(navy, "#FFFFFF", 0.10), card="#FFFFFF", card2="#FFFFFF",
                border="#DDE5EF", border2="#C9D6E4", input="#FFFFFF", text="#1B2A41", muted="#6B7A90", title=navy, sub="#D6E4F0",
                accent_h=_mix(accent, "#000000", 0.12), accent_p=_mix(accent, "#000000", 0.25), on_accent=contrast_text(accent),
                dis_bg="#F1F4F8", dis_fg="#A8B3C2", drop_bg="#F7FAFD", drop_border="#9DB5CC", ok="#1E9E6A", ok_bg="#E3F6EE",
                warn="#D98A00", warn_bg="#FFF1D6", err="#D64545", err_bg="#FBE3E3", gray_bg="#E9EEF4", prog_bg="#DCE6F0",
                badge_fg="#FFFFFF")


def appearance_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "PMS_Generator")
    os.makedirs(path, exist_ok=True)
    return path


APPEARANCE_FILE = os.path.join(appearance_dir(), "appearance.json")

def load_appearance():
    try:
        with open(APPEARANCE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return {"navy": data.get("navy", DEFAULT_NAVY), "accent": data.get("accent", DEFAULT_ACCENT),
                "bg": data.get("bg", DEFAULT_BG), "logo": data.get("logo", "")}
    except Exception:
        return {"navy": DEFAULT_NAVY, "accent": DEFAULT_ACCENT, "bg": DEFAULT_BG, "logo": ""}


APPEARANCE = load_appearance()
NAVY, ACCENT, BG = APPEARANCE["navy"], APPEARANCE["accent"], APPEARANCE["bg"]

def app_logo_path():
    """Square logo for header / window icon: the user's custom logo, else the round emblem (pms_icon.png)."""
    p = APPEARANCE.get("logo", "")
    if p and os.path.isfile(p):
        return p
    return resource_path("pms_icon.png")


def app_banner_path():
    """Full brand banner (emblem + name + tagline) for the splash and About; None when the user chose a custom logo."""
    p = APPEARANCE.get("logo", "")
    if p and os.path.isfile(p):
        return None
    b = resource_path("pms_logo.png")
    return b if os.path.isfile(b) else None


def rounded(pm, radius):
    out = QPixmap(pm.size())
    out.fill(Qt.GlobalColor.transparent)
    pt = QPainter(out)
    pt.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(0, 0, pm.width(), pm.height(), radius, radius)
    pt.setClipPath(path)
    pt.drawPixmap(0, 0, pm)
    pt.end()
    return out


def save_appearance():
    with open(APPEARANCE_FILE, "w", encoding="utf-8") as f:
        json.dump(APPEARANCE, f, ensure_ascii=False, indent=2)


def build_stylesheet():
    """QSS generated from the 3 appearance colours (see derive_palette)."""
    global PAL, TEXT, MUTED, OK, WARN, ERR
    PAL = derive_palette(NAVY, ACCENT, BG)
    TEXT, MUTED, OK, WARN, ERR = PAL["text"], PAL["muted"], PAL["ok"], PAL["warn"], PAL["err"]
    return QSS_TEMPLATE.safe_substitute(PAL)


def apply_theme(app):
    """Fusion style + matching palette (so every widget, dialog and popup is readable) + the stylesheet."""
    css = build_stylesheet()
    app.setStyle("Fusion")
    c = QColor
    pal = QPalette()
    R = QPalette.ColorRole
    for role, col in ((R.Window, PAL["bg"]), (R.WindowText, PAL["text"]), (R.Base, PAL["input"]), (R.AlternateBase, PAL["card"]),
                      (R.Text, PAL["text"]), (R.Button, PAL["card2"]), (R.ButtonText, PAL["text"]), (R.ToolTipBase, PAL["card2"]),
                      (R.ToolTipText, PAL["text"]), (R.Highlight, PAL["accent"]), (R.HighlightedText, PAL["on_accent"]),
                      (R.PlaceholderText, PAL["muted"]), (R.Link, PAL["accent"]), (R.BrightText, "#FFFFFF")):
        pal.setColor(role, c(col))
    G = QPalette.ColorGroup
    for role in (R.WindowText, R.Text, R.ButtonText):
        pal.setColor(G.Disabled, role, c(PAL["dis_fg"]))
    app.setPalette(pal)
    app.setStyleSheet(css)


QSS_TEMPLATE = Template("""
* { font-family: 'Segoe UI', 'Segoe UI Variable', 'Arial'; font-size: 10.5pt; color: $text; }
QMainWindow, QScrollArea, #body, QDialog, QMessageBox { background: $bg; }
QLabel { background: transparent; }
#header { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $navy, stop:1 $header2); border-bottom: 2px solid $accent; }
#header QLabel { color: $text; background: transparent; }
#sidebar { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 $navy, stop:1 $bg); border-right: 1px solid $border; }
QPushButton#sidebarButton { text-align: left; padding: 9px 10px; border: 1px solid transparent; border-radius: 7px; background: transparent; color: $text; font-weight: 600; }
QPushButton#sidebarButton:hover { background: $card2; border-color: $border; color: $title; }
#title { font-size: 22pt; font-weight: 800; letter-spacing: 4px; color: $title; }
#subtitle { color: $sub; font-size: 10pt; letter-spacing: 1px; }
#card { background: $card; border: 1px solid $border; border-radius: 12px; }
#cardTitle { font-size: 12.5pt; font-weight: 700; color: $title; letter-spacing: 1px; }
#badge { background: $accent; color: $badge_fg; border-radius: 11px; min-width: 22px; max-width: 22px; min-height: 22px; max-height: 22px; font-weight: 800; }
#muted { color: $muted; }
#drop { background: $drop_bg; border: 2px dashed $drop_border; border-radius: 12px; color: $muted; font-size: 11.5pt; }
#drop[active="true"] { background: $card2; border-color: $accent; color: $text; }
QLineEdit, QComboBox, QSpinBox, QDateEdit { border: 1px solid $border2; border-radius: 7px; padding: 5px 9px; background: $input; color: $text; min-height: 24px; selection-background-color: $accent; selection-color: $on_accent; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDateEdit:focus { border: 1px solid $accent; }
QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QDateEdit:disabled { background: $dis_bg; color: $dis_fg; border-color: $border; }
QComboBox QAbstractItemView, QListWidget, QListView, QAbstractItemView { background: $input; color: $text; border: 1px solid $border2; outline: 0; selection-background-color: $accent; selection-color: $on_accent; }
QListWidget { border-radius: 7px; padding: 3px; }
QPushButton { border: 1px solid $border2; border-radius: 7px; padding: 7px 16px; background: $card2; color: $text; font-weight: 600; }
QPushButton:hover { border-color: $accent; color: $title; }
QPushButton:pressed { background: $border; }
QPushButton:disabled { color: $dis_fg; background: $dis_bg; border-color: $border; }
#primary { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 $accent_h, stop:1 $accent); border: 1px solid $accent_p; color: $on_accent; font-size: 12.5pt; font-weight: 800; padding: 13px 22px; border-radius: 9px; letter-spacing: 2px; }
#primary:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 $accent_h, stop:1 $accent_h); color: $on_accent; }
#primary:pressed { background: $accent_p; }
#primary:disabled { background: $dis_bg; color: $dis_fg; border: 1px solid $border; }
QProgressBar { border: none; background: $prog_bg; border-radius: 5px; height: 10px; text-align: center; color: transparent; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 $accent_p, stop:1 $accent_h); border-radius: 5px; }
QCheckBox, QRadioButton { spacing: 9px; background: transparent; }
QRadioButton { font-weight: 600; }
QCheckBox::indicator, QRadioButton::indicator, QListView::indicator { width: 15px; height: 15px; border: 2px solid $border2; background: $input; }
QCheckBox::indicator, QListView::indicator { border-radius: 4px; }
QRadioButton::indicator { border-radius: 9px; }
QCheckBox::indicator:checked, QListView::indicator:checked { background: $accent; border-color: $accent; }
QRadioButton::indicator:checked { background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 $accent, stop:0.5 $accent, stop:0.6 $input, stop:1 $input); border-color: $accent; }
QCheckBox::indicator:hover, QRadioButton::indicator:hover { border-color: $accent; }
QToolButton#adv { border: none; font-weight: 700; color: $title; padding: 4px; letter-spacing: 1px; }
QPlainTextEdit { background: $input; color: $text; border: 1px solid $border; border-radius: 8px; padding: 6px; selection-background-color: $accent; selection-color: $on_accent; }
QScrollBar:vertical { background: transparent; width: 12px; margin: 2px; }
QScrollBar::handle:vertical { background: $border2; border-radius: 5px; min-height: 32px; }
QScrollBar::handle:vertical:hover { background: $accent; }
QScrollBar:horizontal { background: transparent; height: 12px; margin: 2px; }
QScrollBar::handle:horizontal { background: $border2; border-radius: 5px; min-width: 32px; }
QScrollBar::handle:horizontal:hover { background: $accent; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QToolTip { background: $card2; color: $text; border: 1px solid $accent; padding: 4px 6px; }
QCalendarWidget QAbstractItemView { background: $input; color: $text; selection-background-color: $accent; selection-color: $on_accent; }
QCalendarWidget QWidget#qt_calendar_navigationbar { background: $navy; }
QCalendarWidget QToolButton { color: $text; background: transparent; border: none; padding: 4px 8px; }
#chipOK { background: $ok_bg; color: $ok; border: 1px solid $ok; border-radius: 11px; padding: 3px 11px; font-weight: 700; }
#chipWARN { background: $warn_bg; color: $warn; border: 1px solid $warn; border-radius: 11px; padding: 3px 11px; font-weight: 700; }
#chipERR { background: $err_bg; color: $err; border: 1px solid $err; border-radius: 11px; padding: 3px 11px; font-weight: 700; }
#chipGRAY { background: $gray_bg; color: $muted; border-radius: 11px; padding: 3px 11px; font-weight: 700; }
#footer { color: $muted; font-size: 9pt; letter-spacing: 1px; }
""")


# ------------------------------------------------------------------------------------------- drawing helpers
def app_icon():
    p = app_logo_path()
    if os.path.isfile(p):
        return QIcon(p)
    pm = QPixmap(256, 256)
    pm.fill(QColor(NAVY))
    return QIcon(pm)


def _classic_splash():
    w, h = 600, 340
    pm = QPixmap(w, h)
    pm.fill(QColor(NAVY))
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, w, h)
    g.setColorAt(0, QColor(PAL["navy"]))
    g.setColorAt(1, QColor(PAL["header2"]))
    p.fillRect(0, 0, w, h, g)
    p.setPen(QPen(QColor(ACCENT), 4))
    p.drawLine(0, h - 4, w, h - 4)
    ic = app_logo_path()
    if os.path.isfile(ic):
        p.drawPixmap(40, 70, QPixmap(ic).scaled(120, 120, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
    p.setPen(QColor(PAL["title"]))
    f = QFont("Segoe UI", 30, QFont.Weight.Bold)
    p.setFont(f)
    p.drawText(190, 120, "PMS GENERATOR")
    p.setPen(QColor(PAL["sub"]))
    p.setFont(QFont("Segoe UI", 11))
    p.drawText(192, 150, APP_SUBTITLE)
    p.setPen(QColor(PAL["text"]))
    p.setFont(QFont("Segoe UI", 12, QFont.Weight.DemiBold))
    p.drawText(192, 200, "Developed by %s" % DEVELOPER_UPPER)
    p.setPen(QColor(PAL["sub"]))
    p.setFont(QFont("Segoe UI", 10))
    p.drawText(192, 224, "%s  |  Version %s" % (DEVELOPER_ORG, APP_VERSION))
    p.setFont(QFont("Segoe UI", 8))
    p.drawText(40, h - 22, COPYRIGHT)
    p.end()
    return pm


def make_splash():
    """Splash = the brand banner (pms_logo.png) + a signature strip with developer, version and copyright."""
    banner = app_banner_path()
    if not banner:
        return _classic_splash()
    src = QPixmap(banner)
    if src.isNull():
        return _classic_splash()
    w = 720
    ih = int(src.height() * w / src.width())
    bar = 70
    edge = src.toImage().pixelColor(src.width() // 2, src.height() - 3)
    pm = QPixmap(w, ih + bar)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    p.drawPixmap(0, 0, src.scaled(w, ih, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation))
    p.fillRect(0, ih, w, bar, edge)
    p.setPen(QPen(QColor(PAL["accent"]), 2))
    p.drawLine(40, ih, w - 40, ih)
    p.setPen(QColor(PAL["title"]))
    p.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
    p.drawText(QRect(0, ih + 8, w, 26), Qt.AlignmentFlag.AlignCenter,
               "Developed by %s   |   %s   |   Version %s" % (DEVELOPER_UPPER, DEVELOPER_ORG, APP_VERSION))
    p.setPen(QColor(PAL["muted"]))
    p.setFont(QFont("Segoe UI", 8))
    p.drawText(QRect(0, ih + 36, w, 22), Qt.AlignmentFlag.AlignCenter, COPYRIGHT)
    p.end()
    return pm


def open_path(path):
    if path and os.path.exists(path):
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


def human_size(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return "%.1f %s" % (n, u) if u != "B" else "%d B" % n
        n /= 1024.0


def unique_path(path):
    base, ext = os.path.splitext(path)
    i = 2
    while os.path.exists("%s_%d%s" % (base, i, ext)) or os.path.exists("%s_%d_validation.txt" % (base, i)):
        i += 1
    return "%s_%d%s" % (base, i, ext)


# ------------------------------------------------------------------------------------------- worker threads
class InspectWorker(QThread):
    ok = Signal(object)
    failed = Signal(object)

    def __init__(self, path):
        super().__init__()
        self.path = path

    def run(self):
        try:
            self.ok.emit(P.inspect_xer(self.path))
        except Exception as e:  # noqa
            log.exception("inspect failed")
            self.failed.emit(e)


class GenWorker(QThread):
    progress = Signal(int, str)
    ok = Signal(object)
    failed = Signal(object)

    def __init__(self, xer, out, overwrite, opts):
        super().__init__()
        self.xer, self.out, self.overwrite, self.opts = xer, out, overwrite, opts

    def run(self):
        try:
            res = P.generate(self.xer, self.out, None, progress=lambda p, m: self.progress.emit(int(p), str(m)),
                             overwrite=self.overwrite, **self.opts)
            self.ok.emit(res)
        except Exception as e:  # noqa
            if not isinstance(e, PmsError):
                log.error("unexpected error\n%s", traceback.format_exc())
            self.failed.emit(e)


# ------------------------------------------------------------------------------------------- small widgets
class DropZone(QLabel):
    dropped = Signal(str)
    clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("drop")
        self.setAcceptDrops(True)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumHeight(96)
        self.setText("Drag && drop your Primavera P6 .xer file here\nor click to browse")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _set_active(self, v):
        self.setProperty("active", "true" if v else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, e):
        urls = e.mimeData().urls()
        if urls and urls[0].toLocalFile().lower().endswith(".xer"):
            self._set_active(True)
            e.acceptProposedAction()

    def dragLeaveEvent(self, e):
        self._set_active(False)

    def dropEvent(self, e):
        self._set_active(False)
        urls = e.mimeData().urls()
        if urls:
            self.dropped.emit(urls[0].toLocalFile())

    def mousePressEvent(self, e):
        self.clicked.emit()


def card(title, number):
    fr = QFrame()
    fr.setObjectName("card")
    lay = QVBoxLayout(fr)
    lay.setContentsMargins(18, 14, 18, 16)
    lay.setSpacing(10)
    head = QHBoxLayout()
    b = QLabel(str(number))
    b.setObjectName("badge")
    b.setAlignment(Qt.AlignmentFlag.AlignCenter)
    t = QLabel(title)
    t.setObjectName("cardTitle")
    head.addWidget(b)
    head.addWidget(t)
    head.addStretch(1)
    lay.addLayout(head)
    return fr, lay


def chip(text, kind):
    l = QLabel(text)
    l.setObjectName({"ok": "chipOK", "warn": "chipWARN", "err": "chipERR"}.get(kind, "chipGRAY"))
    l.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
    return l


class TextDialog(QDialog):
    def __init__(self, parent, title, path):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(900, 640)
        lay = QVBoxLayout(self)
        self.edit = QPlainTextEdit()
        self.edit.setReadOnly(True)
        self.edit.setFont(QFont("Consolas", 9))
        try:
            self.edit.setPlainText(open(path, encoding="utf-8-sig", errors="replace").read())
        except OSError as e:
            self.edit.setPlainText("Cannot read %s\n%s" % (path, e))
        lay.addWidget(self.edit)
        row = QHBoxLayout()
        b1 = QPushButton("Open in default app")
        b1.clicked.connect(lambda: open_path(path))
        b2 = QPushButton("Close")
        b2.clicked.connect(self.accept)
        row.addStretch(1)
        row.addWidget(b1)
        row.addWidget(b2)
        lay.addLayout(row)


class AboutDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("About %s" % APP_NAME)
        self.setFixedWidth(520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(6)
        ic = QLabel()
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        banner = app_banner_path()
        pm = QPixmap(banner) if banner else QPixmap(app_logo_path())
        if not pm.isNull():
            if banner:
                ic.setPixmap(rounded(pm.scaledToWidth(460, Qt.TransformationMode.SmoothTransformation), 14))
            else:
                ic.setPixmap(pm.scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        lay.addWidget(ic)
        lay.addSpacing(6)
        head_rows = [("Developed by %s" % DEVELOPER, "font-size:13pt;font-weight:700;color:%s" % PAL["title"]),
                     ("%s  |  Version %s" % (DEVELOPER_ORG, APP_VERSION), "color:%s" % PAL["muted"])]
        if not banner:           # the banner already carries the name and the tagline
            head_rows = [(APP_NAME, "font-size:20pt;font-weight:700;color:%s" % PAL["title"]), (APP_SUBTITLE, "color:%s" % PAL["muted"])] + head_rows
        for text, style in head_rows:
            l = QLabel(text)
            l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l.setStyleSheet(style)
            lay.addWidget(l)
        lay.addSpacing(8)
        c = QLabel(COPYRIGHT)
        c.setWordWrap(True)
        c.setAlignment(Qt.AlignmentFlag.AlignCenter)
        c.setStyleSheet("font-size:9pt")
        lay.addWidget(c)
        n = QLabel("Your project files stay on your computer: the program never sends data to the internet.\n"
                   "Third-party components and their licences: THIRD_PARTY_LICENSES.txt. See LICENSE.txt for the terms of use.")
        n.setWordWrap(True)
        n.setAlignment(Qt.AlignmentFlag.AlignCenter)
        n.setStyleSheet("color:%s;font-size:9pt" % PAL["muted"])
        lay.addWidget(n)
        row = QHBoxLayout()
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        row.addStretch(1)
        row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)


class AppearanceDialog(QDialog):
    """Simple persistent appearance editor. Changes are applied without rebuilding the app."""
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Appearance settings")
        self.draft = dict(APPEARANCE)
        self.setMinimumWidth(500)
        lay = QVBoxLayout(self)
        intro = QLabel("Choose a logo and interface colors. Your choices are saved on this computer.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        form = QFormLayout()
        self.logo_label = QLabel(os.path.basename(self.draft.get("logo") or "pms_icon.png"))
        self.logo_label.setWordWrap(True)
        browse = QPushButton("Choose logo…")
        browse.clicked.connect(self.choose_logo)
        lr = QHBoxLayout(); lr.addWidget(self.logo_label, 1); lr.addWidget(browse)
        form.addRow("Application logo", lr)
        self.navy_btn = QPushButton("Choose…"); self.accent_btn = QPushButton("Choose…"); self.bg_btn = QPushButton("Choose…")
        self.navy_btn.clicked.connect(lambda: self.choose_color("navy"))
        self.accent_btn.clicked.connect(lambda: self.choose_color("accent"))
        self.bg_btn.clicked.connect(lambda: self.choose_color("bg"))
        form.addRow("Header / primary color", self.navy_btn)
        form.addRow("Buttons / accent color", self.accent_btn)
        form.addRow("Window background", self.bg_btn)
        lay.addLayout(form)
        self.update_swatches()
        note = QLabel("Logo: PNG, JPG, or BMP. For best results use a square image with a transparent background.")
        note.setWordWrap(True); note.setObjectName("muted"); lay.addWidget(note)
        row = QHBoxLayout()
        reset = QPushButton("Reset defaults"); reset.clicked.connect(self.reset_defaults)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        apply_btn = QPushButton("Save and apply"); apply_btn.setObjectName("primary"); apply_btn.clicked.connect(self.apply_changes)
        row.addWidget(reset); row.addStretch(1); row.addWidget(cancel); row.addWidget(apply_btn)
        lay.addLayout(row)

    def update_swatches(self):
        for btn, key in ((self.navy_btn, "navy"), (self.accent_btn, "accent"), (self.bg_btn, "bg")):
            color = self.draft.get(key, "#FFFFFF")
            btn.setStyleSheet("background:%s; color:%s; padding:7px;" % (color, contrast_text(color)))
            btn.setText(color)
        self.logo_label.setText(os.path.basename(self.draft.get("logo") or "pms_icon.png"))

    def choose_color(self, key):
        color = QColorDialog.getColor(QColor(self.draft[key]), self, "Choose " + key + " color")
        if color.isValid():
            self.draft[key] = color.name().upper()
            self.update_swatches()

    def choose_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose application logo", "", "Image files (*.png *.jpg *.jpeg *.bmp)")
        if not path: return
        try:
            dest = os.path.join(appearance_dir(), "custom_logo" + os.path.splitext(path)[1].lower())
            shutil.copy2(path, dest)
            self.draft["logo"] = dest
            self.update_swatches()
        except Exception as e:
            QMessageBox.warning(self, "Logo not changed", str(e))

    def reset_defaults(self):
        self.draft.update({"navy": DEFAULT_NAVY, "accent": DEFAULT_ACCENT, "bg": DEFAULT_BG, "logo": ""})
        self.update_swatches()

    def apply_changes(self):
        try:
            APPEARANCE.update(self.draft)
            save_appearance()
            global NAVY, ACCENT, BG
            NAVY, ACCENT, BG = APPEARANCE["navy"], APPEARANCE["accent"], APPEARANCE["bg"]
            app = QApplication.instance()
            if app: apply_theme(app)
            if app: app.setWindowIcon(QIcon(app_logo_path()))
            self.accept()
            QMessageBox.information(self.parent(), "Appearance updated", "Settings saved. They will remain after restarting the program.")
            if self.parent():
                self.parent().refresh_branding()
        except Exception as e:
            QMessageBox.warning(self, "Could not save settings", str(e))


# ------------------------------------------------------------------------------------------- main window
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("%s  v%s" % (APP_NAME, APP_VERSION))
        self.setWindowIcon(app_icon())
        self.resize(900, 900)
        self.setMinimumSize(760, 640)
        self.setAcceptDrops(True)
        self.info = None
        self.xer = ""
        self.last = None
        self.worker = None
        self.inspector = None
        self.manual_colors = {}
        self._build()

    def refresh_branding(self):
        self.setWindowIcon(QIcon(app_logo_path()))
        # Refresh the visible logo in the header without rebuilding the whole interface.
        if hasattr(self, "header_logo"):
            pm = QPixmap(app_logo_path())
            if not pm.isNull():
                self.header_logo.setPixmap(pm.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    # ------------------------------------------------------------------ layout
    def _build(self):
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        # header
        head = QFrame()
        head.setObjectName("header")
        hl = QHBoxLayout(head)
        hl.setContentsMargins(24, 16, 24, 16)
        ic = QLabel()
        self.header_logo = ic
        pm = QPixmap(app_logo_path())
        if not pm.isNull():
            ic.setPixmap(pm.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        hl.addWidget(ic)
        tb = QVBoxLayout()
        tb.setSpacing(0)
        t = QLabel(APP_NAME)
        t.setObjectName("title")
        s = QLabel(APP_SUBTITLE)
        s.setObjectName("subtitle")
        tb.addWidget(t)
        tb.addWidget(s)
        hl.addLayout(tb)
        hl.addStretch(1)
        settings = QPushButton("Appearance")
        settings.clicked.connect(lambda: AppearanceDialog(self).exec())
        hl.addWidget(settings)
        about = QPushButton("About")
        about.clicked.connect(lambda: AboutDialog(self).exec())
        hl.addWidget(about)
        outer.addWidget(head)
        # Main workspace: persistent navigation rail + scrollable generation workspace.
        body = QWidget()
        body.setObjectName("body")
        body_row = QHBoxLayout(body)
        body_row.setContentsMargins(0, 0, 0, 0)
        body_row.setSpacing(0)
        nav = QFrame()
        nav.setObjectName("sidebar")
        nav.setFixedWidth(176)
        nav_layout = QVBoxLayout(nav)
        nav_layout.setContentsMargins(10, 14, 10, 14)
        nav_layout.setSpacing(7)
        nav_brand = QLabel("PMS  |  GENERATOR")
        nav_brand.setObjectName("title")
        nav_brand.setWordWrap(True)
        nav_layout.addWidget(nav_brand)
        nav_layout.addSpacing(10)
        self.nav_actions = {}
        for label in ("Home", "Generate PMS", "Validation Report", "Settings", "Appearance", "Help", "About"):
            bnav = QPushButton(label)
            bnav.setObjectName("sidebarButton")
            bnav.setMinimumHeight(38)
            bnav.setCursor(Qt.CursorShape.PointingHandCursor)
            nav_layout.addWidget(bnav)
            self.nav_actions[label] = bnav
        nav_layout.addStretch(1)
        nav_note = QLabel("From Primavera\nTo Excel\nWith Precision")
        nav_note.setObjectName("muted")
        nav_note.setWordWrap(True)
        nav_layout.addWidget(nav_note)
        body_row.addWidget(nav)
        content = QWidget()
        bl = QVBoxLayout(content)
        bl.setContentsMargins(18, 18, 18, 10)
        bl.setSpacing(14)
        body_row.addWidget(content, 1)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.Shape.NoFrame)
        sc.setWidget(body)
        outer.addWidget(sc, 1)

        st = self.style()
        # ---- 1. XER
        c1, l1 = card("Primavera P6 XER file", 1)
        self.drop = DropZone()
        self.drop.dropped.connect(self.set_xer)
        self.drop.clicked.connect(self.browse_xer)
        l1.addWidget(self.drop)
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        self.lb_name, self.lb_path, self.lb_size, self.lb_proj = QLabel("-"), QLabel("-"), QLabel("-"), QLabel("-")
        for r, (k, w) in enumerate((("File", self.lb_name), ("Path", self.lb_path), ("Size", self.lb_size), ("Project(s)", self.lb_proj))):
            kl = QLabel(k)
            kl.setObjectName("muted")
            g.addWidget(kl, r, 0)
            w.setWordWrap(True)
            w.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            g.addWidget(w, r, 1)
        g.setColumnStretch(1, 1)
        l1.addLayout(g)
        chips = QHBoxLayout()
        self.chip_bl = chip("Baseline: -", "gray")
        self.chip_res = chip("Resources: -", "gray")
        self.chip_col = chip("WBS colors: -", "gray")
        chips.addWidget(self.chip_bl)
        chips.addWidget(self.chip_res)
        chips.addWidget(self.chip_col)
        chips.addStretch(1)
        l1.addLayout(chips)
        self.bl_detail = QLabel("")
        self.bl_detail.setObjectName("muted")
        self.bl_detail.setWordWrap(True)
        l1.addWidget(self.bl_detail)
        self.col_detail = QLabel("")
        self.col_detail.setObjectName("muted")
        self.col_detail.setWordWrap(True)
        l1.addWidget(self.col_detail)

        # ---- WBS Color Mapping: verified automatic source or editable project-specific manual map
        self.wbs_card = QFrame()
        self.wbs_card.setObjectName("card")
        wbl = QVBoxLayout(self.wbs_card)
        wbl.setContentsMargins(14, 12, 14, 12)
        mode_head = QHBoxLayout()
        mode_title = QLabel("WBS Color Mapping")
        mode_title.setStyleSheet("font-size:15px;font-weight:700")
        mode_head.addWidget(mode_title)
        mode_head.addStretch(1)
        self.rb_auto_color = QRadioButton("Auto Color")
        self.rb_manual_color = QRadioButton("Manual Color")
        self.rb_auto_color.setChecked(True)
        mode_head.addWidget(self.rb_auto_color)
        mode_head.addWidget(self.rb_manual_color)
        wbl.addLayout(mode_head)
        self.lb_color_source = QLabel("Source status: waiting for XER inspection")
        self.lb_color_source.setObjectName("muted")
        self.lb_color_source.setWordWrap(True)
        wbl.addWidget(self.lb_color_source)
        self.wbs_editor = QFrame()
        wel = QVBoxLayout(self.wbs_editor)
        wel.setContentsMargins(0, 4, 0, 0)
        self.tbl_wbs_colors = QTableWidget(0, 3)
        self.tbl_wbs_colors.setHorizontalHeaderLabels(["WBS Level", "Color Preview", "HEX"])
        self.tbl_wbs_colors.verticalHeader().setVisible(False)
        self.tbl_wbs_colors.setMaximumHeight(230)
        self.tbl_wbs_colors.setMinimumHeight(100)
        self.tbl_wbs_colors.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.tbl_wbs_colors.setEditTriggers(QTableWidget.EditTrigger.DoubleClicked | QTableWidget.EditTrigger.EditKeyPressed)
        self.tbl_wbs_colors.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_wbs_colors.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_wbs_colors.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tbl_wbs_colors.cellDoubleClicked.connect(self._pick_wbs_color)
        self.tbl_wbs_colors.itemChanged.connect(self._wbs_hex_edited)
        wel.addWidget(self.tbl_wbs_colors)
        wbtn = QHBoxLayout()
        self.bt_apply_wbs = QPushButton("Apply Colors")
        self.bt_save_wbs = QPushButton("Save Project Mapping")
        self.bt_reset_wbs = QPushButton("Reset Colors")
        self.bt_import_wbs = QPushButton("Import Mapping")
        self.bt_export_wbs = QPushButton("Export Mapping")
        self.bt_apply_wbs.clicked.connect(self._apply_manual_colors)
        self.bt_save_wbs.clicked.connect(self._save_manual_mapping)
        self.bt_reset_wbs.clicked.connect(self._reset_manual_colors)
        self.bt_import_wbs.clicked.connect(self._import_manual_mapping)
        self.bt_export_wbs.clicked.connect(self._export_manual_mapping)
        for b in (self.bt_apply_wbs, self.bt_save_wbs, self.bt_reset_wbs, self.bt_import_wbs, self.bt_export_wbs):
            wbtn.addWidget(b)
        wel.addLayout(wbtn)
        self.wbs_editor.hide()
        wbl.addWidget(self.wbs_editor)
        self.rb_auto_color.toggled.connect(self._wbs_mode_changed)
        self.rb_manual_color.toggled.connect(self._wbs_mode_changed)
        try:
            with open(os.path.join(appearance_dir(), "wbs_color_mode.json"), "r", encoding="utf-8") as f:
                if json.load(f).get("mode") == "manual":
                    self.rb_manual_color.setChecked(True)
        except Exception:
            pass
        bl.addWidget(self.wbs_card)

        self.proj_box = QFrame()
        pbl = QVBoxLayout(self.proj_box)
        pbl.setContentsMargins(0, 0, 0, 0)
        pl = QLabel("This XER contains several projects. Tick the project(s) to convert:")
        pl.setStyleSheet("font-weight:600")
        pbl.addWidget(pl)
        self.proj_list = QListWidget()
        self.proj_list.setMaximumHeight(110)
        pbl.addWidget(self.proj_list)
        self.proj_box.hide()
        l1.addWidget(self.proj_box)
        bl.addWidget(c1)

        # ---- 2. output
        c2, l2 = card("Output", 2)
        row = QHBoxLayout()
        self.ed_out = QLineEdit()
        self.ed_out.setPlaceholderText("Folder for the PMS file and the validation report (default: next to the XER)")
        b = QPushButton("Browse")
        b.setIcon(st.standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon))
        b.clicked.connect(self.browse_out)
        row.addWidget(self.ed_out, 1)
        row.addWidget(b)
        l2.addLayout(row)
        self.lb_outname = QLabel("File name: PMS_<Project>_Rev00.xlsx")
        self.lb_outname.setObjectName("muted")
        l2.addWidget(self.lb_outname)
        bl.addWidget(c2)

        # ---- 3. report settings
        c3, l3 = card("Report settings", 3)
        g3 = QGridLayout()
        g3.setHorizontalSpacing(10)
        g3.setVerticalSpacing(8)
        self.ck_auto_rn = QCheckBox("Automatic (previous + 1, or 1)")
        self.ck_auto_rn.setChecked(True)
        self.sp_rn = QSpinBox()
        self.sp_rn.setRange(1, 999)
        self.sp_rn.setEnabled(False)
        self.ck_auto_rn.toggled.connect(lambda v: self.sp_rn.setEnabled(not v))
        g3.addWidget(QLabel("Report no."), 0, 0)
        g3.addWidget(self.sp_rn, 0, 1)
        g3.addWidget(self.ck_auto_rn, 0, 2)
        self.ck_dd = QCheckBox("Use the P6 Data Date")
        self.ck_dd.setChecked(True)
        self.de_fin = QDateEdit(QDate.currentDate())
        self.de_fin.setCalendarPopup(True)
        self.de_fin.setDisplayFormat("dd-MMM-yyyy")
        self.de_fin.setEnabled(False)
        self.ck_dd.toggled.connect(lambda v: self.de_fin.setEnabled(not v))
        g3.addWidget(QLabel("Period finish"), 1, 0)
        g3.addWidget(self.de_fin, 1, 1)
        g3.addWidget(self.ck_dd, 1, 2)
        self.ed_prev = QLineEdit()
        self.ed_prev.setPlaceholderText("Optional: previous PMS .xlsx to continue the next period")
        bp = QPushButton("Browse")
        bp.setIcon(st.standardIcon(QStyle.StandardPixmap.SP_FileIcon))
        bp.clicked.connect(self.browse_prev)
        bc = QPushButton("Clear")
        bc.clicked.connect(self.ed_prev.clear)
        pr = QHBoxLayout()
        pr.addWidget(self.ed_prev, 1)
        pr.addWidget(bp)
        pr.addWidget(bc)
        g3.addWidget(QLabel("Previous PMS"), 2, 0)
        g3.addLayout(pr, 2, 1, 1, 2)
        g3.setColumnStretch(2, 1)
        l3.addLayout(g3)
        hint = QLabel("A previous PMS keeps the manual inputs (weights, actual dates, cumulative progress, S-curve history) for activities "
                      "that can be matched reliably. Without it a new report starts from zero.")
        hint.setObjectName("muted")
        hint.setWordWrap(True)
        l3.addWidget(hint)
        bl.addWidget(c3)

        # ---- 4. weights
        c4, l4 = card("Weight Settings", 4)
        self.grp = QButtonGroup(self)
        self.rb, self.cb = {}, {}
        specs = (("A", "Cost-Based Weighting", ["Schedule Baseline Cost", "Current Budgeted Cost", "Manual Input / Custom Cost"]),
                 ("B", "Resource-Based Weighting", ["Man-Hours (Labor Only)", "Total Resource Units (Labor + Non-Labor)"]),
                 ("C", "Equal / Duration-Based", ["No Automatic Weighting", "Equal Weight per Activity", "Duration-Based Weight"]))
        for key, title, items in specs:
            r = QHBoxLayout()
            rb = QRadioButton(title)
            rb.setMinimumWidth(230)
            cbx = QComboBox()
            cbx.addItems(items)
            self.grp.addButton(rb)
            self.rb[key], self.cb[key] = rb, cbx
            rb.toggled.connect(self._weights_changed)
            cbx.currentIndexChanged.connect(self._weights_changed)
            r.addWidget(rb)
            r.addWidget(cbx, 1)
            l4.addLayout(r)
        self.rb["C"].setChecked(True)
        self.row_custom = QFrame()
        rc = QHBoxLayout(self.row_custom)
        rc.setContentsMargins(0, 0, 0, 0)
        self.ed_cost = QLineEdit()
        self.ed_cost.setPlaceholderText("Custom cost file (.csv / .xlsx) with columns: Activity ID, Cost")
        bcf = QPushButton("Browse")
        bcf.clicked.connect(self.browse_cost)
        rc.addWidget(self.ed_cost, 1)
        rc.addWidget(bcf)
        self.row_custom.hide()
        l4.addWidget(self.row_custom)
        self.lb_w = QLabel("")
        self.lb_w.setObjectName("muted")
        self.lb_w.setWordWrap(True)
        l4.addWidget(self.lb_w)
        note = QLabel("Default = no automatic weighting (enter BUDGETED UNIT by hand). Calculated weights come from schedule data and are not "
                      "contractual weights unless you confirm them. Activities without data are left empty and listed in the validation report.")
        note.setObjectName("muted")
        note.setWordWrap(True)
        l4.addWidget(note)
        bl.addWidget(c4)

        # ---- advanced (collapsible)
        self.btn_adv = QToolButton()
        self.btn_adv.setObjectName("adv")
        self.btn_adv.setText("Advanced settings")
        self.btn_adv.setCheckable(True)
        self.btn_adv.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn_adv.setArrowType(Qt.ArrowType.RightArrow)
        bl.addWidget(self.btn_adv)
        self.adv = QFrame()
        self.adv.setObjectName("card")
        ag = QGridLayout(self.adv)
        ag.setContentsMargins(18, 14, 18, 14)
        ag.setVerticalSpacing(8)
        self.ed_title, self.ed_company, self.ed_contractor = QLineEdit(), QLineEdit(), QLineEdit()
        self.ed_title.setPlaceholderText("Empty = root WBS name from the XER")
        self.ed_company.setPlaceholderText("Empty = as in the template (B2)")
        self.ed_contractor.setPlaceholderText("Empty = as in the template (B3)")
        self.cb_planned = QComboBox()
        self.cb_planned.addItems(["Auto: baseline dates when a baseline exists", "Current planned dates (P6 Planned Start/Finish)"])
        self.cb_baseline = QComboBox()
        self.cb_baseline.addItem("Automatic")
        self.ck_empty = QCheckBox("Also write WBS elements that have no activities")
        self.ed_colors = QLineEdit()
        self.ed_colors.setPlaceholderText("Optional: colour map for THIS project (.json / .csv Level,Color) or a PMS .xlsx to copy level colours from")
        self.bt_colors = QPushButton("Browse")
        self.bt_colors.clicked.connect(self.browse_colors)
        self.row_colors = QFrame()
        rcl = QHBoxLayout(self.row_colors)
        rcl.setContentsMargins(0, 0, 0, 0)
        rcl.addWidget(self.ed_colors, 1)
        rcl.addWidget(self.bt_colors)
        self.ck_remember = QCheckBox("Remember this colour map for this project only")
        self.ck_remember.setChecked(True)
        self.cb_fallback = QComboBox()
        self.cb_fallback.addItems(["Standard level palette (reported as FALLBACK)", "No colour (leave WBS rows uncoloured)"])
        for r, (k, w) in enumerate((("Report title", self.ed_title), ("Company line", self.ed_company), ("Contractor line", self.ed_contractor),
                                    ("Planned dates", self.cb_planned), ("Baseline project", self.cb_baseline),
                                    ("WBS colour map", self.row_colors), ("If no colour source", self.cb_fallback))):
            ag.addWidget(QLabel(k), r, 0)
            ag.addWidget(w, r, 1)
        ag.addWidget(self.ck_remember, 7, 1)
        ag.addWidget(self.ck_empty, 8, 1)
        ag.setColumnStretch(1, 1)
        self.adv.hide()
        bl.addWidget(self.adv)
        self.btn_adv.toggled.connect(self._toggle_adv)

        # ---- generate + progress + results
        self.btn_gen = QPushButton("GENERATE PMS")
        self.btn_gen.setObjectName("primary")
        self.btn_gen.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_gen.clicked.connect(self.generate)
        bl.addWidget(self.btn_gen)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.hide()
        bl.addWidget(self.bar)
        self.lb_status = QLabel("")
        self.lb_status.setObjectName("muted")
        bl.addWidget(self.lb_status)
        self.res_card = QFrame()
        self.res_card.setObjectName("card")
        rl = QVBoxLayout(self.res_card)
        rl.setContentsMargins(18, 14, 18, 16)
        self.res_chip_row = QHBoxLayout()
        rl.addLayout(self.res_chip_row)
        self.res_text = QPlainTextEdit()
        self.res_text.setReadOnly(True)
        self.res_text.setMaximumHeight(170)
        rl.addWidget(self.res_text)
        br = QHBoxLayout()
        self.b_open = QPushButton("Open PMS (Excel)")
        self.b_open.setIcon(st.standardIcon(QStyle.StandardPixmap.SP_FileIcon))
        self.b_folder = QPushButton("Open results folder")
        self.b_folder.setIcon(st.standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon))
        self.b_rep = QPushButton("Validation report")
        self.b_log = QPushButton("Log")
        self.b_open.clicked.connect(lambda: open_path(self.last and self.last["output"]))
        self.b_folder.clicked.connect(lambda: open_path(self.last and os.path.dirname(self.last["output"])))
        self.b_rep.clicked.connect(self.show_report)
        self.b_log.clicked.connect(lambda: TextDialog(self, "Log", log_path()).exec())
        for b in (self.b_open, self.b_folder, self.b_rep, self.b_log):
            br.addWidget(b)
        br.addStretch(1)
        rl.addLayout(br)
        self.res_card.hide()
        bl.addWidget(self.res_card)
        bl.addStretch(1)
        foot = QLabel(FOOTER)
        foot.setObjectName("footer")
        foot.setAlignment(Qt.AlignmentFlag.AlignCenter)
        foot.setContentsMargins(0, 6, 0, 8)
        outer.addWidget(foot)
        self.nav_actions["Home"].clicked.connect(lambda: sc.verticalScrollBar().setValue(0))
        self.nav_actions["Generate PMS"].clicked.connect(lambda: sc.ensureWidgetVisible(c1))
        self.nav_actions["Validation Report"].clicked.connect(self.show_report)
        self.nav_actions["Settings"].clicked.connect(lambda: self.btn_adv.setChecked(not self.btn_adv.isChecked()))
        self.nav_actions["Appearance"].clicked.connect(lambda: AppearanceDialog(self).exec())
        self.nav_actions["Help"].clicked.connect(lambda: TextDialog(self, "User Guide", resource_path("README_PMS.txt")).exec())
        self.nav_actions["About"].clicked.connect(lambda: AboutDialog(self).exec())
        self._weights_changed()

    # ------------------------------------------------------------------ WBS colour editor
    def _wbs_mode_changed(self, *_):
        manual = self.rb_manual_color.isChecked()
        try:
            with open(os.path.join(appearance_dir(), "wbs_color_mode.json"), "w", encoding="utf-8") as f:
                json.dump({"mode": "manual" if manual else "auto"}, f)
        except OSError:
            pass
        self.wbs_editor.setVisible(manual)
        if manual and self.info:
            self._populate_wbs_color_table()
        elif self.info:
            self._refresh_color_source_status()

    def _refresh_color_source_status(self):
        if not self.info:
            self.lb_color_source.setText("Source status: waiting for XER inspection")
            return
        c = self.info.get("colors", {})
        if c.get("xer_nodes", 0):
            status = "Verified P6 Source — %d WBS node(s) have explicit color values in this XER." % c["xer_nodes"]
        elif c.get("stored"):
            status = "Source Colors Unavailable in XER — a previously saved project mapping is available. P6 layout colors are not embedded in ordinary XER exports."
        else:
            status = "Source Colors Unavailable — XER contains no verified WBS display colors. Use Manual Color or supply a verified layout/map; fallback colors are never labelled as original P6 colors."
        self.lb_color_source.setText(status)

    def _populate_wbs_color_table(self):
        levels = (self.info or {}).get("wbs_levels", [])
        if not levels:
            self.tbl_wbs_colors.setRowCount(0)
            return
        self.tbl_wbs_colors.blockSignals(True)
        self.tbl_wbs_colors.setRowCount(len(levels))
        from pms_colors import fallback_hex, parse_color
        for row, level in enumerate(levels):
            level_item = QTableWidgetItem("Level %d" % level)
            level_item.setFlags(level_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            level_item.setData(Qt.ItemDataRole.UserRole, level)
            self.tbl_wbs_colors.setItem(row, 0, level_item)
            c = parse_color(self.manual_colors.get(str(level))) or fallback_hex(level)
            swatch = QTableWidgetItem("     ")
            swatch.setFlags(swatch.flags() & ~Qt.ItemFlag.ItemIsEditable)
            swatch.setBackground(QColor("#" + c))
            self.tbl_wbs_colors.setItem(row, 1, swatch)
            self.tbl_wbs_colors.setItem(row, 2, QTableWidgetItem("#" + c))
        self.tbl_wbs_colors.blockSignals(False)

    def _pick_wbs_color(self, row, column):
        if column not in (1, 2):
            return
        item = self.tbl_wbs_colors.item(row, 2)
        initial = QColor(item.text()) if item else QColor("#CFA84B")
        chosen = QColorDialog.getColor(initial, self, "Choose WBS Level Color")
        if chosen.isValid():
            self._set_wbs_row_color(row, chosen.name().upper())

    def _set_wbs_row_color(self, row, hex_color):
        self.tbl_wbs_colors.blockSignals(True)
        swatch = self.tbl_wbs_colors.item(row, 1)
        if swatch:
            swatch.setBackground(QColor(hex_color))
        item = self.tbl_wbs_colors.item(row, 2)
        if item:
            item.setText(hex_color.upper())
        self.tbl_wbs_colors.blockSignals(False)

    def _wbs_hex_edited(self, item):
        if item.column() != 2:
            return
        from pms_colors import parse_color
        c = parse_color(item.text())
        if c:
            self._set_wbs_row_color(item.row(), "#" + c)
        else:
            QMessageBox.warning(self, APP_NAME, "Enter a valid HEX color, for example #1F4E79.")
            self._populate_wbs_color_table()

    def _manual_mapping_data(self):
        from pms_colors import parse_color
        levels = {}
        for row in range(self.tbl_wbs_colors.rowCount()):
            level = self.tbl_wbs_colors.item(row, 0).data(Qt.ItemDataRole.UserRole)
            c = parse_color(self.tbl_wbs_colors.item(row, 2).text())
            if c:
                levels[str(level)] = "#" + c
        return {"levels": levels, "nodes": {}}

    def _apply_manual_colors(self):
        if not self.info:
            QMessageBox.information(self, APP_NAME, "Import an XER file first.")
            return
        self.manual_colors = self._manual_mapping_data()["levels"]
        self._save_manual_mapping(silent=True)
        self.lb_color_source.setText("User-supplied colors — manual preview applied to WBS levels only. These are not represented as original P6 colors.")
        QMessageBox.information(self, APP_NAME, "Manual colors are ready for this project. They will be used for the next PMS generation.")

    def _project_mapping_path(self):
        from pms_colors import color_map_dir, project_key
        projects = (self.info or {}).get("projects", [])
        if len(projects) != 1:
            raise ValueError("Manual project mappings require exactly one selected/imported project. Import a single-project XER to avoid mixing project colors.")
        pid = projects[0].get("id", "")
        short = projects[0].get("short", "project")
        os.makedirs(color_map_dir(), exist_ok=True)
        return os.path.join(color_map_dir(), project_key(short, pid) + "_manual.json")

    def _save_manual_mapping(self, silent=False):
        if not self.info:
            return
        try:
            path = self._project_mapping_path()
            data = self._manual_mapping_data()
            data.update(project=self.info["projects"][0].get("short", "project"), project_id=self.info["projects"][0].get("id", ""),
                        saved=datetime.now().isoformat(timespec="seconds"), source="USER_SUPPLIED")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            self.manual_colors = data["levels"]
            self.ed_colors.setText(path)
            if not silent:
                QMessageBox.information(self, APP_NAME, "Project-specific color mapping saved:\n%s" % path)
        except Exception as e:
            if not silent:
                QMessageBox.warning(self, APP_NAME, str(e))

    def _reset_manual_colors(self):
        from pms_colors import fallback_hex
        self.manual_colors = {str(lv): "#" + fallback_hex(lv) for lv in (self.info or {}).get("wbs_levels", [])}
        self._populate_wbs_color_table()

    def _import_manual_mapping(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import WBS color mapping", "", "Mapping files (*.json *.csv)")
        if not path:
            return
        try:
            from pms_colors import _read_map_file
            levels, nodes, notes = _read_map_file(path)
            self.manual_colors = {str(k): "#" + v for k, v in levels.items()}
            self._populate_wbs_color_table()
            self.lb_color_source.setText("Imported user-supplied mapping: %s" % os.path.basename(path))
        except Exception as e:
            QMessageBox.warning(self, APP_NAME, "Could not import mapping: %s" % e)

    def _export_manual_mapping(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export WBS color mapping", "wbs_color_mapping.json", "JSON (*.json)")
        if not path:
            return
        if not path.lower().endswith(".json"):
            path += ".json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._manual_mapping_data(), f, indent=2)
        QMessageBox.information(self, APP_NAME, "Mapping exported to:\n%s" % path)

    # ------------------------------------------------------------------ small slots
    def _toggle_adv(self, v):
        self.adv.setVisible(v)
        self.btn_adv.setArrowType(Qt.ArrowType.DownArrow if v else Qt.ArrowType.RightArrow)

    def _weights_changed(self, *_):
        for k in self.cb:
            self.cb[k].setEnabled(self.rb[k].isChecked())
        self.row_custom.setVisible(self.rb["A"].isChecked() and self.cb["A"].currentIndex() == 2)
        self.lb_w.setText("Selected: " + self._method_label())

    def weight_method(self):
        if self.rb["A"].isChecked():
            return ("cost_baseline", "cost_current", "cost_custom")[self.cb["A"].currentIndex()]
        if self.rb["B"].isChecked():
            return ("res_labor", "res_total")[self.cb["B"].currentIndex()]
        return ("none", "equal", "duration")[self.cb["C"].currentIndex()]

    def _method_label(self):
        from pms_weights import METHODS
        return METHODS[self.weight_method()]

    def dragEnterEvent(self, e):
        urls = e.mimeData().urls()
        if urls and urls[0].toLocalFile().lower().endswith(".xer"):
            e.acceptProposedAction()

    def dropEvent(self, e):
        urls = e.mimeData().urls()
        if urls:
            self.set_xer(urls[0].toLocalFile())

    def browse_xer(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select the Primavera P6 XER file", "", "Primavera XER (*.xer);;All files (*.*)")
        if p:
            self.set_xer(p)

    def browse_out(self):
        p = QFileDialog.getExistingDirectory(self, "Select the output folder", self.ed_out.text() or os.path.dirname(self.xer or ""))
        if p:
            self.ed_out.setText(p)

    def browse_prev(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select the previous PMS", "", "Excel (*.xlsx *.xlsm)")
        if p:
            self.ed_prev.setText(p)

    def browse_colors(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select the WBS colour map for this project", "",
                                           "Colour map or PMS (*.json *.csv *.xlsx *.xlsm)")
        if p:
            self.ed_colors.setText(p)

    def browse_cost(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select the custom cost file", "", "Cost files (*.csv *.xlsx *.xlsm)")
        if p:
            self.ed_cost.setText(p)

    # ------------------------------------------------------------------ XER inspection
    def set_xer(self, path):
        if not path or not os.path.isfile(path):
            QMessageBox.warning(self, APP_NAME, "The file was not found:\n%s" % path)
            return
        if not path.lower().endswith(".xer"):
            QMessageBox.warning(self, APP_NAME, "Please select a Primavera P6 .xer file.")
            return
        self._reset_project_state()
        self.xer, self.info = path, None
        self.lb_name.setText(os.path.basename(path))
        self.lb_path.setText(os.path.dirname(path))
        self.lb_size.setText(human_size(os.path.getsize(path)))
        self.lb_proj.setText("reading ...")
        self.drop.setText("Selected: %s\n(drop another file to replace it)" % os.path.basename(path))
        if not self.ed_out.text():
            self.ed_out.setText(os.path.dirname(path))
        self.res_card.hide()
        self.lb_status.setText("Reading the XER ...")
        self.inspector = InspectWorker(path)
        self.inspector.ok.connect(self._inspected)
        self.inspector.failed.connect(self._inspect_failed)
        self.inspector.start()

    def _reset_project_state(self):
        """Everything that belongs to the PREVIOUS schedule is dropped when another XER is loaded: project list, baseline
        choice, status chips, results, and the project-specific files (colour map, custom cost file). The previous-PMS path is
        kept because it is normally reused week after week; the engine checks that it matches the XER."""
        cleared = []
        for ed, label in ((self.ed_colors, "WBS colour map"), (self.ed_cost, "custom cost file")):
            if ed.text().strip():
                cleared.append(label)
            ed.clear()
        self.info, self.last = None, None
        self.manual_colors = {}
        self.tbl_wbs_colors.setRowCount(0)
        self.lb_color_source.setText("Source status: waiting for XER inspection")
        self.proj_list.clear()
        self.proj_box.hide()
        self.cb_baseline.clear()
        self.cb_baseline.addItem("Automatic")
        self.bl_detail.setText("")
        self.col_detail.setText("")
        self._replace_chip("bl", "Baseline: -", "gray")
        self._replace_chip("res", "Resources: -", "gray")
        self._replace_chip("col", "WBS colors: -", "gray")
        self.res_card.hide()
        if cleared:
            self.lb_status.setText("Cleared (they belong to the previous schedule): " + ", ".join(cleared))

    def _inspect_failed(self, e):
        self.lb_proj.setText("-")
        self.lb_status.setText("")
        msg = str(e) if isinstance(e, PmsError) else "The file could not be read as a P6 XER. Details are in the log."
        QMessageBox.critical(self, APP_NAME, msg)

    def _inspected(self, info):
        self.info = info
        self.lb_status.setText("")
        self._refresh_color_source_status()
        self._populate_wbs_color_table()
        try:
            if len(info.get("projects", [])) == 1:
                mp = self._project_mapping_path()
                if os.path.isfile(mp):
                    with open(mp, "r", encoding="utf-8") as f:
                        self.manual_colors = json.load(f).get("levels", {})
                    self._populate_wbs_color_table()
        except Exception:
            pass
        projs = info["projects"]
        self.lb_proj.setText("; ".join("%s (%d activities)" % (p["short"], p["tasks"]) for p in projs) or "-")
        # project selector
        self.proj_list.clear()
        if len(projs) > 1:
            for p in projs:
                it = QListWidgetItem("%s  -  %s  [%d activities]" % (p["short"], p["root"], p["tasks"]))
                it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                it.setCheckState(Qt.CheckState.Unchecked)
                it.setData(Qt.ItemDataRole.UserRole, p["id"])
                self.proj_list.addItem(it)
            self.proj_box.show()
        else:
            self.proj_box.hide()
        # baseline chip
        st = info["baseline_state"]
        txt, kind = {"FOUND": ("Baseline: found", "ok"), "NOT_IN_FILE": ("Baseline: not in file", "warn"),
                     "PARTIAL": ("Baseline: partial / not linkable", "warn"), "NOT_EXPORTED": ("Baseline: not exported", "err")}.get(st, (st, "gray"))
        self._replace_chip("bl", txt, kind)
        self.bl_detail.setText(" | ".join(l for l in info["baseline_lines"] if l.startswith("[")))
        r = info["resources"]
        if r["taskrsrc"]:
            self._replace_chip("res", "Resources: %d assignments" % r["taskrsrc"], "ok")
        else:
            self._replace_chip("res", "Resources: none in file", "warn")
        col = info["colors"]
        ctxt, ckind = {"xer": ("WBS colors: from the XER", "ok"), "stored": ("WBS colors: saved map for this project", "ok"),
                       "none": ("WBS colors: not in the XER", "warn")}[col["kind"]]
        self._replace_chip("col", ctxt, ckind)
        self.col_detail.setText("WBS colours: " + col["summary"] + ("" if col["kind"] != "none" else
                                " - to use your P6 level colours: Advanced settings > WBS colour map."))
        self.cb_baseline.clear()
        self.cb_baseline.addItem("Automatic")
        for b in info["baselines"]:
            self.cb_baseline.addItem("%s [id %s]" % (b["name"], b["id"]), b["id"])
        short = projs[0]["short"] if len(projs) == 1 else "<Project>"
        self.lb_outname.setText("File name: PMS_%s_Rev00.xlsx  (Rev = report no. - 1)" % short)

    def _replace_chip(self, which, text, kind):
        old = {"bl": self.chip_bl, "res": self.chip_res, "col": self.chip_col}[which]
        new = chip(text, kind)
        lay = old.parentWidget().layout()
        # the chip row is the 5th..7th layout item of card 1: find the layout that holds the chip
        for i in range(lay.count()):
            it = lay.itemAt(i)
            sub = it.layout()
            if sub is not None and sub.indexOf(old) >= 0:
                sub.replaceWidget(old, new)
                break
        old.deleteLater()
        if which == "bl":
            self.chip_bl = new
        elif which == "res":
            self.chip_res = new
        else:
            self.chip_col = new

    # ------------------------------------------------------------------ generate
    def _options(self):
        o = dict(weight_method=self.weight_method(), include_empty_wbs=self.ck_empty.isChecked())
        if self.ed_out.text().strip():
            o["out_dir"] = self.ed_out.text().strip()
        if not self.ck_auto_rn.isChecked():
            o["report_no"] = self.sp_rn.value()
        if not self.ck_dd.isChecked():
            d = self.de_fin.date()
            o["period_finish"] = datetime(d.year(), d.month(), d.day())
        if self.ed_prev.text().strip():
            o["previous"] = self.ed_prev.text().strip()
        if o["weight_method"] == "cost_custom" and self.ed_cost.text().strip():
            o["custom_cost_file"] = self.ed_cost.text().strip()
        for key, ed in (("title", self.ed_title), ("company", self.ed_company), ("contractor", self.ed_contractor)):
            if ed.text().strip():
                o[key] = ed.text().strip()
        o["planned_source"] = "auto" if self.cb_planned.currentIndex() == 0 else "current"
        if self.rb_manual_color.isChecked():
            self._save_manual_mapping(silent=True)
            if self.ed_colors.text().strip():
                o["wbs_colors"] = self.ed_colors.text().strip()
                o["remember_colors"] = self.ck_remember.isChecked()
                o["use_saved_colors"] = True
        else:
            o["wbs_colors"] = ""
            o["remember_colors"] = False
            o["use_saved_colors"] = False
        o["fallback_colors"] = "standard" if self.cb_fallback.currentIndex() == 0 else "none"
        if self.cb_baseline.currentIndex() > 0:
            o["baseline"] = self.cb_baseline.currentData()
        if self.info and len(self.info["projects"]) > 1:
            chosen = [self.proj_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.proj_list.count())
                      if self.proj_list.item(i).checkState() == Qt.CheckState.Checked]
            o["projects"] = chosen
        return o

    def generate(self):
        if not self.xer:
            QMessageBox.information(self, APP_NAME, "Select a Primavera P6 XER file first.")
            return
        if self.info is None:
            QMessageBox.information(self, APP_NAME, "The XER is still being read - try again in a moment.")
            return
        opts = self._options()
        if self.info and len(self.info["projects"]) > 1 and not opts.get("projects"):
            QMessageBox.warning(self, APP_NAME, "This XER contains several projects. Tick the project(s) you want to convert.")
            return
        if self.rb_manual_color.isChecked() and len(self.info.get("projects", [])) != 1:
            QMessageBox.warning(self, APP_NAME, "Manual color mappings are project-specific. Import a single-project XER to edit and save a mapping without mixing projects.")
            return
        self._start(None, False, opts)

    def _start(self, out, overwrite, opts):
        self.btn_gen.setEnabled(False)
        self.res_card.hide()
        self.bar.setValue(0)
        self.bar.show()
        self.lb_status.setText("Starting ...")
        self._last_args = (out, opts)
        self.worker = GenWorker(self.xer, out, overwrite, opts)
        self.worker.progress.connect(lambda p, m: (self.bar.setValue(p), self.lb_status.setText(m)))
        self.worker.ok.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _failed(self, e):
        self.btn_gen.setEnabled(True)
        self.bar.hide()
        self.lb_status.setText("")
        if isinstance(e, PmsExistsError):
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Question)
            box.setWindowTitle(APP_NAME)
            box.setText("The output file already exists:\n%s" % e.path)
            box.setInformativeText("Replace it, or keep both and save the new one with a different name?")
            b_rep = box.addButton("Replace", QMessageBox.ButtonRole.DestructiveRole)
            b_both = box.addButton("Keep both", QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            clicked = box.clickedButton()
            _, opts = self._last_args
            if clicked is b_rep:
                self._start(self._last_args[0], True, opts)
            elif clicked is b_both:
                self._start(unique_path(e.path), False, opts)
            return
        if isinstance(e, PmsChooseProject):
            QMessageBox.warning(self, APP_NAME, "Tick the project(s) to convert.")
            return
        if isinstance(e, PmsError):
            QMessageBox.critical(self, APP_NAME, str(e))
        else:
            QMessageBox.critical(self, APP_NAME, "An unexpected problem stopped the conversion.\nNo file was reported as successful.\n"
                                                 "Open the Log (button after a run, or %s) and send it for support." % log_path())

    def _done(self, res):
        self.btn_gen.setEnabled(True)
        self.bar.setValue(100)
        self.lb_status.setText("")
        self.last = res
        while self.res_chip_row.count():
            it = self.res_chip_row.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        ne, nw = len(res["errors"]), len(res["warnings"])
        if ne:
            self.res_chip_row.addWidget(chip("File created with %d ERROR(S) - do not use before review" % ne, "err"))
        elif nw:
            self.res_chip_row.addWidget(chip("PMS created - %d warning(s) to review" % nw, "warn"))
        else:
            self.res_chip_row.addWidget(chip("PMS created successfully", "ok"))
        self.res_chip_row.addStretch(1)
        lines = ["%s" % res["output"], "Project: %s | %d rows | %d activities | %d weekly columns | report no. %s" % (
            res["project"], res["rows"], res["activities"], res["weeks"], res["report_no"]),
            "Baseline: %s | Weights: %s (%s)" % (res["baseline_state"], res["weights_state"], res["weight_label"]),
            "WBS colours: %s%s" % (", ".join("%s %d" % kv for kv in sorted(res["colors"]["counts"].items())) or "-",
                                   "" if res["colors"]["exact_possible"] else "  (exact match with P6 colours NOT verified)")]
        if res.get("matches"):
            m = res["matches"]
            lines.append("Previous PMS: matched %d of %d activities (new %d, suspect %d, removed %d)" % (m["matched"], m["total"], m["new"], m["suspect"], m["removed"]))
        lines += ["", "ERRORS:"] + ["  - " + x for x in res["errors"]] if ne else []
        if nw:
            lines += ["", "WARNINGS:"] + ["  - " + x[:260] for x in res["warnings"]]
        self.res_text.setPlainText("\n".join(lines))
        self.res_card.show()
        self.bar.hide()

    def show_report(self):
        if self.last:
            TextDialog(self, "Validation report", self.last["report"]).exec()


# ------------------------------------------------------------------------------------------- entry
def run(preload=None):
    global P
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setWindowIcon(QIcon(app_logo_path()))
    apply_theme(app)
    app.setFont(QFont("Segoe UI", 10))
    splash = QSplashScreen(make_splash())
    splash.show()
    app.processEvents()
    import p6_to_pms as engine           # heavy import (openpyxl) happens while the splash is visible
    P = engine
    win = MainWindow()
    if preload:
        QTimer.singleShot(0, lambda: win.set_xer(preload))

    def finish():
        splash.finish(win)
        win.show()
    QTimer.singleShot(1500, finish)
    return app.exec()


if __name__ == "__main__":
    sys.exit(run(sys.argv[1] if len(sys.argv) > 1 else None))
