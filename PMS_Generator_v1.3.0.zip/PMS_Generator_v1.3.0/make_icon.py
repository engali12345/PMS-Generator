# -*- coding: utf-8 -*-
"""Builds the application icon files from the brand logo (pms_logo.png): the round gear-and-arrow emblem is cut out
of the banner and saved as pms_icon.png (square, transparent corners) and pms_icon.ico (multi-size). Needs Pillow."""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
# emblem circle inside pms_logo.png (1024 x 559): centre (257, 278), radius ~127; a few px of margin are kept
CX, CY, R = 257, 278, 133


def build():
    src = Image.open(os.path.join(HERE, "pms_logo.png")).convert("RGB")
    box = (CX - R, CY - R, CX + R, CY + R)
    emblem = src.crop(box).resize((1024, 1024), Image.LANCZOS)
    mask = Image.new("L", (4096, 4096), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, 4095, 4095), fill=255)
    mask = mask.resize((1024, 1024), Image.LANCZOS)
    emblem = emblem.convert("RGBA")
    emblem.putalpha(mask)
    emblem.resize((512, 512), Image.LANCZOS).save(os.path.join(HERE, "pms_icon.png"))
    emblem.save(os.path.join(HERE, "pms_icon.ico"), sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("icon files written from pms_logo.png")


if __name__ == "__main__":
    build()
