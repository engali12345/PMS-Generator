"""Continuation test on SIMULATED data: period 1 -> user fills actuals -> period 2 XER with renamed/moved/new/removed/suspect activities."""
import sys, os, shutil, subprocess, copy
from datetime import datetime, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openpyxl
import p6_to_pms as P
import make_test_xers as m

base = os.path.join(os.path.dirname(os.path.abspath(__file__)))
out = "/tmp/cont"; shutil.rmtree(out, ignore_errors=True); os.makedirs(out)
tpl = os.path.join(os.path.dirname(base), "PMS_Master_Template.xlsx")
x1 = os.path.join(out, "p1.xer"); m.from_template(tpl, x1, data_date=datetime(2026, 10, 22))
r1 = P.generate(x1, os.path.join(out, "PMS_Rev00.xlsx"), None, weight_method="equal", report_no=1)
# ---- user work on period 1: actual inputs
wb = openpyxl.load_workbook(r1["output"]); ws = wb["PMS"]
acts = [r for r in range(8, ws.max_row + 1) if ws.cell(r, 3).value == "YES" and ws.cell(r, 8).value and ws.cell(r, 9).value]
fill = {}
for i, r in enumerate(acts[:40]):
    v = round(0.1 + 0.02 * i, 2) if i < 35 else 1.0
    ws.cell(r, 18, v); ws.cell(r, 10, datetime(2026, 6, 10) + timedelta(days=i)); fill[ws.cell(r, 4).value] = (v, ws.cell(r, 5).value)
    if v == 1.0: ws.cell(r, 11, datetime(2026, 9, 1))
ws.cell(acts[50], 7, 7)    # a manual weight (will be overwritten by 'equal' in test A, carried in test B)
wb.save(os.path.join(out, "PMS_Rev00_filled.xlsx"))
recalc = "/mnt/skills/public/xlsx/scripts/recalc.py"
if os.path.isfile(recalc):
    subprocess.run([sys.executable, recalc, os.path.join(out, "PMS_Rev00_filled.xlsx"), "120"], capture_output=True, cwd=os.path.dirname(os.path.dirname(recalc)))
prevf = os.path.join(out, "PMS_Rev00_filled.xlsx")
# ---- period 2 XER: edit the XER tables
T, enc = P.parse_xer(x1)
tasks = T["TASK"]; wbs = T["PROJWBS"]
ids = list(fill)
renamed, moved, removed, suspect = ids[1], ids[2], ids[3], ids[4]
for t in tasks:
    if t["task_code"] == renamed: t["task_name"] = "RENAMED " + t["task_name"]
    if t["task_code"] == moved:
        other = next(w for w in wbs if w["wbs_id"] != t["wbs_id"] and w.get("proj_node_flag") != "Y")
        t["wbs_id"] = other["wbs_id"]
    if t["task_code"] == suspect:
        other = next(w for w in wbs if w["wbs_id"] != t["wbs_id"] and w.get("proj_node_flag") != "Y")
        t["wbs_id"] = other["wbs_id"]; t["task_name"] = "COMPLETELY DIFFERENT WORK"
tasks[:] = [t for t in tasks if t["task_code"] != removed]
new = copy.deepcopy(tasks[10]); new["task_code"] = "NEW-9999"; new["task_name"] = "Brand new activity"; new["task_id"] = "999999"; tasks.append(new)
for p in T["PROJECT"]: p["last_recalc_date"] = "2026-10-29 00:00"
x2 = os.path.join(out, "p2.xer")
txt = ["ERMHDR\t8.0\t2026-10-27\tProject\tADMIN\tx\tdb\tProject Management\tUSD", m.table("CALENDAR", m.CF, T["CALENDAR"]),
       m.table("PROJECT", m.PF, T["PROJECT"]), m.table("PROJWBS", m.WF, wbs), m.table("TASK", m.TF, tasks), "%E"]
open(x2, "w", encoding="cp1252", newline="").write("\r\n".join(txt) + "\r\n")

def report(tag, **kw):
    r = P.generate(x2, os.path.join(out, "PMS_Rev01_%s.xlsx" % tag), None, previous=prevf, **kw)
    ws = openpyxl.load_workbook(r["output"])["PMS"]; sc = openpyxl.load_workbook(r["output"])["S-CURVE"]
    byid = {ws.cell(r_, 4).value: r_ for r_ in range(8, ws.max_row + 1) if ws.cell(r_, 3).value == "YES"}
    print("--- test", tag, "| matches:", r["matches"], "| errors:", len(r["errors"]))
    print("report no / period:", ws["X4"].value, ws["X2"].value.date(), ws["X3"].value.date())
    ok = 0; bad = []
    for k, (v, nm) in fill.items():
        if k in (removed, suspect): 
            if k in byid and (ws.cell(byid[k], 18).value not in (None, "")): bad.append(("must NOT carry", k))
            continue
        row = byid.get(k)
        if row is None: bad.append(("missing", k)); continue
        if abs((ws.cell(row, 18).value or -1) - v) > 1e-9 or abs((ws.cell(row, 16).value or -1) - v) > 1e-9 or not ws.cell(row, 10).value: bad.append(("value", k))
        else: ok += 1
    print("carried correctly: %d of %d expected | problems: %s" % (ok, len(fill) - 2, bad[:5]))
    row = byid[acts_manual]; print("manual weight G of one activity:", ws.cell(row, 7).value)
    print("new activity row empty:", ws.cell(byid["NEW-9999"], 18).value, ws.cell(byid["NEW-9999"], 7).value)
    print("S-CURVE row 11 sample:", [sc.cell(11, c).value for c in range(3, 8)], "...")
    return r
acts_manual = ws.cell(acts[50], 4).value
report("A_equal", weight_method="equal")
r = report("B_manual", weight_method="none")
print(open(r["report"], encoding="utf-8-sig").read().split("--- PREVIOUS PMS")[1].split("--- CHECKS")[0][:1800])
