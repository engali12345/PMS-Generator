# -*- coding: utf-8 -*-
"""
Regression tests for the WBS colour fix and project independence.   Run:  python tests/test_wbs_colors.py [real.xer]

Honesty note: only ONE real P6 export is available (MWP-CB38). Every other XER used here is SYNTHETIC (built by this file or
by make_test_xers.py). Synthetic XERs prove the logic; they can NOT prove fidelity to colours displayed in a real P6 layout.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
WORK = tempfile.mkdtemp(prefix="pms_color_tests_")
os.environ["PMS_GENERATOR_HOME"] = os.path.join(WORK, "home")        # colour maps of the tests never touch the real profile
import openpyxl                      # noqa: E402
import make_test_xers as mk          # noqa: E402
import p6_to_pms as P                # noqa: E402
import pms_colors as C               # noqa: E402

REAL = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/MWP-CB38-MI-SCH_.xer"
OLD_DIR = os.environ.get("PMS_OLD_ENGINE", "/tmp/old/PMS_Generator_v1.0.0")     # pristine copy of the previous version
# expected fallback palette, written out here on purpose (not imported) so the test does not depend on the code under test
EXPECTED = ["7030A0", "7F6000", "00B050", "FFFF00", "0070C0", "FF0000", "FF9900", "00B0F0", "92D050", "FF66CC", "996633", "7F7F7F"]
RESULTS = []


def record(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  -  " + detail) if detail else ""))


# ----------------------------------------------------------------------------------------------- synthetic XER builder
def build_xer(path, short, max_level, prefix, groups=2, udf_colors=None, color_field=None, bad_udf=None):
    """Tree whose PMS levels run 2..max_level (root = level 2). Returns the expected structure from the XER side."""
    wbs, tasks, exp_level, parent_name, task_parent = [], [], {}, {}, {}
    nid, tid = [100], [1000]
    by_level = {}

    def node(parent, level, name):
        nid[0] += 1
        row = dict(wbs_id=nid[0], proj_id=1, proj_node_flag="Y" if level == 2 else "N", parent_wbs_id=parent["wbs_id"] if parent else "",
                   wbs_name=name, wbs_short_name="%s.%d" % (prefix, nid[0]), seq_num=nid[0])
        wbs.append(row)
        exp_level[name] = level
        parent_name[name] = parent["wbs_name"] if parent else None
        by_level.setdefault(level, []).append(row)
        return row

    def act(w, k):
        tid[0] += 1
        s = datetime(2026, 3, 1) + timedelta(days=7 * (tid[0] % 40))
        f = s + timedelta(days=10)
        code = "%s-A%d" % (prefix, tid[0])
        tasks.append(dict(task_id=tid[0], proj_id=1, wbs_id=w["wbs_id"], task_code=code, task_name="%s work %d" % (prefix, tid[0]),
                          task_type="TT_Task", status_code="TK_NotStart", target_start_date=mk.fmt(s), target_end_date=mk.fmt(f),
                          early_start_date=mk.fmt(s), early_end_date=mk.fmt(f), target_drtn_hr_cnt=88, remain_drtn_hr_cnt=88, clndr_id=1))
        task_parent[code] = w["wbs_name"]

    root = node(None, 2, "%s-ROOT" % prefix)
    for L in range(3, max_level + 1):
        for pi, par in enumerate(by_level[L - 1]):
            n_children = groups if (L <= 5 or pi < 2) else 1
            for g in range(n_children):
                node(par, L, "%s-L%d-%d-%d" % (prefix, L, pi, g))
    for L, nodes in by_level.items():
        for w in nodes:
            if L == max_level or L % 3 == 0:                 # activities at the leaves and at some middle nodes
                for k in range(2):
                    act(w, k)
    extra = []
    if color_field:
        for w in wbs:
            w[color_field[0]] = color_field[1].get(w["wbs_name"], "")
    if udf_colors is not None:
        types = [dict(udf_type_id=77, table_name="PROJWBS", udf_type_name="wbs_color", udf_type_label="WBS Color", logical_data_type="FT_TEXT")]
        vals = [dict(udf_type_id=77, fk_id=next(w["wbs_id"] for w in wbs if w["wbs_name"] == n), proj_id=1, udf_text=v) for n, v in udf_colors.items()]
        extra = [mk.table("UDFTYPE", ["udf_type_id", "table_name", "udf_type_name", "udf_type_label", "logical_data_type"], types),
                 mk.table("UDFVALUE", ["udf_type_id", "fk_id", "proj_id", "udf_text"], vals)]
    wf = list(mk.WF) + ([color_field[0]] if color_field else [])
    txt = ["ERMHDR\t8.0\t2026-10-27\tProject\tADMIN\tx\tdb\tProject Management\tUSD", mk.table("CALENDAR", mk.CF, [dict(clndr_id=1, clndr_name="Std")]),
           mk.table("PROJECT", mk.PF, [dict(proj_id=1, proj_short_name=short, project_flag="Y", last_recalc_date="2026-10-25 00:00")]),
           mk.table("PROJWBS", wf, wbs), mk.table("TASK", mk.TF, tasks)] + extra + ["%E"]
    open(path, "w", encoding="cp1252", newline="").write("\r\n".join(txt) + "\r\n")
    return dict(exp_level=exp_level, parent_name=parent_name, task_parent=task_parent, wbs=wbs, n_tasks=len(tasks), max_level=max_level)


def gen(xer, tag, **kw):
    out = os.path.join(WORK, tag)
    os.makedirs(out, exist_ok=True)
    return P.generate(xer, None, None, overwrite=True, out_dir=out, **kw)


def read_rows(path):
    """Output side of the structure: [(row, key, level, kind, name_or_id, fill_hex)]"""
    ws = openpyxl.load_workbook(path)["PMS"]
    out = []
    for r in range(8, ws.max_row + 1):
        lv, yn, key = ws.cell(r, 2).value, ws.cell(r, 3).value, ws.cell(r, 1).value
        if isinstance(lv, int) and key and yn in ("YES", "NO"):
            c = ws.cell(r, 5)
            fill = c.fill.fgColor.rgb[-6:].upper() if c.fill.fill_type and c.fill.fgColor.type == "rgb" else None
            nm = str(ws.cell(r, 4).value).strip()
            out.append((r, key, lv, yn, nm, fill, ws.cell(r, 5).value))
    return out


def structure_ok(rows, ex):
    """names, levels, parent/child relations of the OUTPUT equal those of the XER; returns list of problems"""
    bad = []
    by_key = {k: (lv, yn, nm) for (_, k, lv, yn, nm, _, _) in rows}
    for (_, k, lv, yn, nm, fill, e) in rows:
        if yn == "NO" and lv >= 2:
            if ex["exp_level"].get(nm) != lv:
                bad.append("level of %s: file %s, XER %s" % (nm, lv, ex["exp_level"].get(nm)))
            par = ".".join(k.split(".")[:-1])
            pn = by_key[par][2] if par in by_key and by_key[par][0] >= 2 else None
            if pn != ex["parent_name"].get(nm):
                bad.append("parent of %s: file %s, XER %s" % (nm, pn, ex["parent_name"].get(nm)))
        if yn == "YES":
            par = ".".join(k.split(".")[:-1])
            if by_key[par][1] != "NO" or by_key[par][2] != ex["task_parent"].get(nm):
                bad.append("activity %s sits under %s, XER says %s" % (nm, by_key[par][2], ex["task_parent"].get(nm)))
            if lv != by_key[par][0] + 1:
                bad.append("activity %s level %s" % (nm, lv))
    return bad


def dump_workbook(path):
    """Everything that defines how a workbook looks/behaves, for cell-by-cell comparison."""
    wb = openpyxl.load_workbook(path)
    d = {}
    for ws in wb:
        cells = {}
        for row in ws.iter_rows():
            for c in row:
                fl = c.fill.fgColor.rgb if (c.fill.fill_type and c.fill.fgColor.type == "rgb") else (
                    ("theme", c.fill.fgColor.theme, round(c.fill.fgColor.tint, 3)) if c.fill.fill_type else None)
                ft = c.font.color.rgb if (c.font.color is not None and c.font.color.type == "rgb") else None
                if c.value is not None or fl or c.border.left.style:
                    cells[c.coordinate] = (c.value, fl, ft, c.font.b, c.number_format)
        d[ws.title] = (cells, sorted(str(m) for m in ws.merged_cells.ranges), ws.sheet_state)
    return d


def all_strings(path):
    out = set()
    for ws in openpyxl.load_workbook(path):
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    out.add(c.value.strip())
    return out


def recalc_unexpected_errors(path, tag):
    tmp = os.path.join(WORK, tag + "_recalc.xlsx")
    shutil.copy(path, tmp)
    recalc = "/mnt/skills/public/xlsx/scripts/recalc.py"
    if not os.path.isfile(recalc):
        return None, "recalc not available in this environment"
    rc = subprocess.run([sys.executable, recalc, tmp, "200"], capture_output=True, text=True, cwd=os.path.dirname(os.path.dirname(recalc)))
    try:
        res = json.loads(rc.stdout[rc.stdout.index("{"):])
    except Exception:  # noqa
        return None, "recalc not available"
    bad = {}
    for k, v in res.get("error_summary", {}).items():
        locs = [x for x in v["locations"] if not (k == "#N/A" and x.startswith("S-CURVE!") and re.sub(r"[A-Z]+", "", x.split("!")[1]) in ("8", "9"))]
        if locs:
            bad[k] = locs[:3]
    return bad, "formulas=%s" % res.get("total_formulas")


# =================================================================================================== TEST A / B / D
deep_x = os.path.join(WORK, "deep11.xer")
ex11 = build_xer(deep_x, "DEEP-11", 11, "D11", groups=2)
r11 = gen(deep_x, "deep11")
rows11 = read_rows(r11["output"])
lv_seen = sorted({lv for (_, _, lv, yn, *_r) in rows11 if yn == "NO"})
record("A1 deep hierarchy: levels 1..11 all present", lv_seen == list(range(1, 12)), "levels in the file: %s" % lv_seen)
bad = structure_ok(rows11, ex11)
record("A2 each WBS level equals the depth computed from the XER parent chain (no code-separator counting)", not bad, "; ".join(bad[:3]))
by_level = {}
for (_, k, lv, yn, nm, fill, e) in rows11:
    if yn == "NO":
        by_level.setdefault(lv, set()).add(fill)
ok = all(by_level[l] == {EXPECTED[l - 1]} for l in range(1, 12) if l - 1 < len(EXPECTED))
record("A3 every level has its own palette colour (levels 7-11 are not red / not level 6)", ok,
       ", ".join("L%d=%s" % (l, sorted(by_level[l])[0]) for l in sorted(by_level)))
record("A4 levels 7-11 do not inherit level 6's colour", all(by_level[l] != by_level[6] for l in range(7, 12)))
record("A5 activities carry no WBS fill and keep their parent relation", not any(f for (_, _, _, yn, _, f, _) in rows11 if yn == "YES") and not [b for b in bad if b.startswith("activity")])
cnt = Counter(lv for (_, _, lv, yn, *_r) in rows11 if yn == "NO")
record("B1 several WBS groups per level (levels 3-5 have 2, 4, 8 groups) with consistent colour per level", cnt[3] == 2 and cnt[4] == 4 and cnt[5] == 8 and all(len(by_level[l]) == 1 for l in by_level), "rows per level: %s" % dict(sorted(cnt.items())))
record("B2 names / parent-child relations of the output equal the XER", not bad, "%d WBS + %d activities compared" % (sum(cnt.values()), ex11["n_tasks"]))
# colours do not depend on row position: shuffle the order in which the XER lists the WBS nodes / tasks
shuf_x = os.path.join(WORK, "deep11_shuffled.xer")
txt = open(deep_x, encoding="cp1252").read().split("\r\n")
cur, out_l = None, []
import random  # noqa: E402
random.seed(5)
buf = []
for ln in txt + ["%T\tEND"]:
    if ln.startswith("%T") or ln == "%E":
        if cur in ("PROJWBS", "TASK") and buf:
            random.shuffle(buf)
        out_l += buf
        buf = []
        cur = ln.split("\t")[1] if ln.startswith("%T") and "\t" in ln else cur
    if ln.startswith("%R") and cur in ("PROJWBS", "TASK"):
        buf.append(ln)
    elif ln != "%T\tEND":
        out_l.append(ln)
open(shuf_x, "w", encoding="cp1252", newline="").write("\r\n".join(out_l))
rs = gen(shuf_x, "deep11_shuffled")
rows_s = read_rows(rs["output"])
bl_s = {}
for (_, k, lv, yn, nm, fill, e) in rows_s:
    if yn == "NO":
        bl_s.setdefault(lv, set()).add(fill)
record("B3 colours depend on the level only (XER rows listed in a shuffled order give the same colour per level)", bl_s == by_level)

# D: three levels vs eleven levels
shallow_x = os.path.join(WORK, "shallow3.xer")
ex3 = build_xer(shallow_x, "SHALLOW-3", 4, "S3", groups=3)
r3 = gen(shallow_x, "shallow3")
rows3 = read_rows(r3["output"])
bad3 = structure_ok(rows3, ex3)
lv3 = sorted({lv for (_, _, lv, yn, *_r) in rows3 if yn == "NO"})
record("D1 three-WBS-level schedule (levels 2-4 + overall) is structured correctly", not bad3 and lv3 == [1, 2, 3, 4] and r3["activities"] == ex3["n_tasks"], "levels %s, %d activities" % (lv3, r3["activities"]))
record("D2 eleven-level schedule is structured correctly", not bad and r11["activities"] == ex11["n_tasks"], "%d activities" % r11["activities"])
for tag, r in (("deep11", r11), ("shallow3", r3)):
    bad_f, info = recalc_unexpected_errors(r["output"], tag)
    record("D3 formulas of %s calculate without errors (LibreOffice recalculation)" % tag, True if bad_f is None else bad_f == {}, ("SKIPPED: " if bad_f is None else "") + (info if bad_f in ({}, None) else str(bad_f)))
sc = openpyxl.load_workbook(r3["output"])["PMS"]
record("D4 no template activity/WBS leaked into the 3-level workbook", not any(("Mishrif" in s or "132kV" in s or "Qurainat" in s) for s in all_strings(r3["output"])))

# =================================================================================================== TEST C
if os.path.isfile(REAL):
    ra = gen(REAL, "projA")
    a_strings = {s for s in all_strings(ra["output"])}
    xa, _enc = P.parse_xer(REAL)
    a_names = {w["wbs_name"].strip() for w in xa["PROJWBS"] if w["wbs_name"].strip()} | {t["task_code"] for t in xa["TASK"]} | {t["task_name"].strip() for t in xa["TASK"] if len(t["task_name"].strip()) > 6}
    rb1 = gen(deep_x, "projB_after_A")
    b_strings = all_strings(rb1["output"])
    leak = sorted(s for s in b_strings if any(n and n in s for n in a_names if len(n) > 6))
    record("C1 second project (after project A in the same process) contains none of A's WBS names, activities or project name", not leak and "MWP-CB38-MI-01" not in " ".join(b_strings), "A-strings tested: %d" % len(a_names))
    fresh_out = os.path.join(WORK, "fresh")
    os.makedirs(fresh_out, exist_ok=True)
    env = dict(os.environ)
    subprocess.run([sys.executable, os.path.join(ROOT, "p6_to_pms.py"), deep_x, "--out-dir", fresh_out, "--overwrite"], env=env, capture_output=True)
    d1, d2 = dump_workbook(rb1["output"]), dump_workbook(os.path.join(fresh_out, os.path.basename(rb1["output"])))
    diffs = [(sh, k) for sh in d1 for k in set(d1[sh][0]) | set(d2[sh][0]) if d1[sh][0].get(k) != d2[sh][0].get(k)]
    record("C2 B processed after A is identical, cell by cell (values, formulas, fills, fonts), to B processed alone in a fresh process", not diffs, "%d cells compared, %d differences" % (sum(len(v[0]) for v in d1.values()), len(diffs)))
    # user colour map saved for project A must not touch project B
    cmap = os.path.join(WORK, "a_colors.csv")
    open(cmap, "w").write("Level,Color\n1,#111111\n2,#222222\n3,#333333\n4,#444444\n5,#555555\n6,#666666\n7,#777777\n")
    ra2 = gen(REAL, "projA_map", wbs_colors=cmap)
    rb2 = gen(deep_x, "projB_after_map")
    dB = dump_workbook(rb2["output"])
    same = all(dB[sh][0] == d1[sh][0] for sh in d1)
    record("C3 colour map saved for project A is NOT applied to project B (B identical to its earlier output; 0 USER rows)",
           same and rb2["colors"]["counts"].get(C.USER, 0) == 0 and ra2["colors"]["counts"].get(C.USER) == ra2["colors"]["rows"],
           "A: %s | B: %s" % (ra2["colors"]["counts"], rb2["colors"]["counts"]))
    ra3 = gen(REAL, "projA_again")                                    # no map given: A's own saved map is found again
    record("C4 project A finds ITS OWN saved map again (and only A)", ra3["colors"]["counts"].get(C.USER) == ra3["colors"]["rows"],
           "stored file: %s" % os.path.basename(C.stored_map_path("MWP-CB38-MI-01") or "-"))
    dA = dump_workbook(ra3["output"])
    record("C5 A with its saved map shows the user colours", {c[1] for k, c in dA["PMS"][0].items() if k.startswith("E") and isinstance(c[1], str)} >= {"FF555555", "FF666666", "FF777777"})
else:
    record("C* tests with the real XER", True, "SKIPPED: real XER not supplied: %s" % REAL)

# =================================================================================================== TEST E / G (colour sources)
rE = gen(REAL if os.path.isfile(REAL) else deep_x, "missing_colors", wbs_colors=None) if False else None
shutil.rmtree(os.path.join(WORK, "home"), ignore_errors=True)         # make sure no saved map exists
src_x = REAL if os.path.isfile(REAL) else deep_x
rE = gen(src_x, "E_missing")
rep = open(rE["report"], encoding="utf-8-sig").read()
sec = rep[rep.index("WBS COLOR VALIDATION"):rep.index("--- WEIGHTS")]
nfb = rE["colors"]["counts"].get(C.FALLBACK, 0)
record("E1 no colour data in the XER: limitation reported (warning + report), nothing claimed as exact",
       any("WBS COLORS" in w and "FALLBACK" in w for w in rE["warnings"]) and "NOT VERIFIED" in sec and "colours come from explicit data" not in sec
       and ("Rows using FALLBACK colours (standard palette, not P6's): %d" % nfb) in sec and nfb == rE["colors"]["rows"], "fallback rows: %d" % nfb)
rE2 = gen(src_x, "E_none", fallback_colors="none")
rows_e2 = read_rows(rE2["output"])
record("E2 fallback switched off: WBS rows stay uncoloured and are reported as UNAVAILABLE (no invented colour)",
       all(f is None for (_, _, lv, yn, nm, f, e) in rows_e2 if yn == "NO") and rE2["colors"]["counts"].get(C.UNAVAILABLE) == rE2["colors"]["rows"] and not rE2["colors"]["counts"].get(C.FALLBACK))
open(os.path.join(WORK, "partial.csv"), "w").write("Level;Colour\n1;#123456\n2;#234567\n3;#345678\n")
rE3 = gen(deep_x, "E_partial", wbs_colors=os.path.join(WORK, "partial.csv"))
nu, nf = rE3["colors"]["counts"].get(C.USER, 0), rE3["colors"]["counts"].get(C.FALLBACK, 0)
record("E3 partial colour map: mapped levels = USER, the other levels = FALLBACK, both counted", nu + nf == rE3["colors"]["rows"] and nu > 0 and nf > 0, "USER %d, FALLBACK %d" % (nu, nf))

# G: explicit colours inside the XER (synthetic: WBS user-defined field) -> VERIFIED
names = [n for n in ex11["exp_level"]]
udf_all = {n: "#%02X%02X%02X" % ((i * 37) % 256, (i * 91) % 256, (i * 53) % 256) for i, n in enumerate(names)}
ux = os.path.join(WORK, "udf_all.xer")
build_xer(ux, "UDF-ALL", 11, "D11", groups=2, udf_colors=udf_all)
rG = gen(ux, "G_udf_all")
rowsG = read_rows(rG["output"])
okG = all(f == udf_all[nm].lstrip("#").upper() for (_, _, lv, yn, nm, f, e) in rowsG if yn == "NO" and lv >= 2)
repG = open(rG["report"], encoding="utf-8-sig").read()
record("G1 XER with a WBS colour UDF on every node: rows are VERIFIED, colours taken from the XER, exactness statement allowed",
       okG and rG["colors"]["counts"].get(C.VERIFIED) == rG["colors"]["rows"] and "EXACT COLOR FIDELITY: colours come from explicit data" in repG, str(rG["colors"]["counts"]))
ux2 = os.path.join(WORK, "udf_some.xer")
some = {n: v for i, (n, v) in enumerate(udf_all.items()) if i % 3 == 0}
some[names[5]] = "16744448"                                            # an integer: must be ignored, not guessed
build_xer(ux2, "UDF-SOME", 11, "D11", groups=2, udf_colors=some)
rG2 = gen(ux2, "G_udf_some")
repG2 = open(rG2["report"], encoding="utf-8-sig").read()
record("G2 colours on only some nodes: those are VERIFIED, the rest FALLBACK; unreadable integer ignored and reported; exactness NOT claimed",
       rG2["colors"]["counts"].get(C.VERIFIED, 0) > 0 and rG2["colors"]["counts"].get(C.FALLBACK, 0) > 0 and "NOT VERIFIED" in repG2 and "could not be read" in repG2, str(rG2["colors"]["counts"]))
fx = os.path.join(WORK, "field.xer")
_probe = build_xer(os.path.join(WORK, "probe.xer"), "FIELD-COL", 6, "F6", groups=2)
build_xer(fx, "FIELD-COL", 6, "F6", groups=2, color_field=("wbs_color", {n: "#0A0B0C" for n in _probe["exp_level"]}))
rG3 = gen(fx, "G_field")
record("G3 a colour-named PROJWBS field is read as VERIFIED data", rG3["colors"]["counts"].get(C.VERIFIED, 0) > 0, str(rG3["colors"]["counts"]))
open(os.path.join(WORK, "lv.json"), "w").write(json.dumps({"levels": {"1": "#101010", "5": "#AA5500"}, "nodes": {"D11-L3-0-0": "#00FF7F"}}))
rG4 = gen(deep_x, "G_json", wbs_colors=os.path.join(WORK, "lv.json"), remember_colors=False)
rowsG4 = {nm: f for (_, _, lv, yn, nm, f, e) in read_rows(rG4["output"]) if yn == "NO"}
record("G4 JSON map: level colour + node override applied as USER; unmapped levels FALLBACK", rowsG4["D11-L3-0-0"] == "00FF7F" and rowsG4["D11-L5-0-0"] == "AA5500" and rG4["colors"]["counts"].get(C.FALLBACK, 0) > 0)
tpl = os.path.join(ROOT, "PMS_Master_Template.xlsx")
rG5 = gen(deep_x, "G_pmsfile", wbs_colors=tpl, remember_colors=False)
lv_cols = {lv: sorted(d["colors"]) for lv, d in rG5["colors"].items() if False} or None
cc = C._read_pms_levels(tpl)[0]
close = lambda a, b: all(abs(int(a[i:i + 2], 16) - int(b[i:i + 2], 16)) <= 1 for i in (0, 2, 4))     # theme tints are resolved to within 1/255
record("G5 colours read from a PMS workbook incl. a theme colour (level 2, tint) resolve to RGB (+-1/255)", cc.get(1) == "7030A0" and cc.get(3) == "00B050" and close(cc.get(2, "000000"), "7F6000") and cc.get(6) == "FF0000", str(cc))

# =================================================================================================== TEST F  (old engine vs new engine)
def run_cli(engine_dir, xer, out_dir, extra=()):
    env = dict(os.environ)
    env["PMS_GENERATOR_HOME"] = os.path.join(WORK, "home_f")
    return subprocess.run([sys.executable, os.path.join(engine_dir, "p6_to_pms.py"), xer, "--out-dir", out_dir, "--overwrite"] + list(extra), capture_output=True, text=True, env=env, cwd=engine_dir)


if os.path.isdir(OLD_DIR):
    sims = []
    tpl_x = os.path.join(WORK, "sim_template.xer")
    mk.from_template(tpl, tpl_x)
    sims.append(("real MWP-CB38", REAL, ()))
    sims.append(("simulated 132kV (from template)", tpl_x, ()))
    base_x = os.path.join(WORK, "sim_baseline.xer")
    mk.add_baseline(REAL, base_x, shift_days=-14, drop_every=17)
    sims.append(("simulated MWP + baseline", base_x, ()))
    for label, xer, extra in sims:
        if not os.path.isfile(xer):
            continue
        o_old, o_new = os.path.join(WORK, "f_old"), os.path.join(WORK, "f_new")
        for d in (o_old, o_new):
            shutil.rmtree(d, ignore_errors=True)
        run_cli(OLD_DIR, xer, o_old, extra)
        run_cli(ROOT, xer, o_new, extra)
        fo, fn = [os.path.join(d, f) for d, f in ((o_old, os.listdir(o_old)[0] if os.path.isdir(o_old) and [x for x in os.listdir(o_old) if x.endswith('.xlsx')] else None),
                                                   (o_new, None))] if False else (None, None)
        fo = next((os.path.join(o_old, x) for x in os.listdir(o_old) if x.endswith(".xlsx")), None)
        fn = next((os.path.join(o_new, x) for x in os.listdir(o_new) if x.endswith(".xlsx")), None)
        if not fo or not fn:
            record("F0 both engines produced a workbook for %s" % label, False, "old=%s new=%s" % (fo, fn))
            continue
        a, b = dump_workbook(fo), dump_workbook(fn)
        val_diff, fill_diff_act, fill_diff_sum = [], 0, []
        for sh in a:
            if sh not in b:
                val_diff.append(sh)
                continue
            ca, cb = a[sh][0], b[sh][0]
            for k in set(ca) | set(cb):
                if ca.get(k, (None,))[0] != cb.get(k, (None,))[0]:
                    val_diff.append("%s!%s" % (sh, k))
        record("F1 [%s] all cell values and formulas identical to the previous version (all sheets)" % label, not val_diff and list(a) == list(b), "%d differences %s" % (len(val_diff), val_diff[:4]))
        wo, wn = openpyxl.load_workbook(fo)["PMS"], openpyxl.load_workbook(fn)["PMS"]
        hdr_same = [wo.cell(5, c).value for c in range(1, 40)] == [wn.cell(5, c).value for c in range(1, 40)]
        t_hdr = [openpyxl.load_workbook(tpl).worksheets[0].cell(5, c).value for c in range(1, 40)] == [wn.cell(5, c).value for c in range(1, 40)]
        record("F2 [%s] column order and names unchanged (identical to the template header)" % label, hdr_same and t_hdr)
        lvl_diff = []
        for r in range(8, wo.max_row + 1):
            if wo.cell(r, 3).value not in ("YES", "NO"):
                continue
            fo_, fn_ = wo.cell(r, 5).fill, wn.cell(r, 5).fill
            lvl = wo.cell(r, 2).value
            if wo.cell(r, 3).value == "YES":
                if bool(fo_.fill_type) != bool(fn_.fill_type):
                    fill_diff_act += 1
            else:
                new = fn_.fgColor.rgb[-6:] if fn_.fill_type else None
                old = fo_.fgColor.rgb[-6:] if (fo_.fill_type and fo_.fgColor.type == "rgb") else "theme"
                lvl_diff.append((lvl, old, new))
        deep_new = {n for (l, o, n) in lvl_diff if l >= 7}
        same_low = all(o == n for (l, o, n) in lvl_diff if l in (1, 3, 4, 5, 6))
        old_deep_red = {o for (l, o, n) in lvl_diff if l >= 7} <= {"FF0000"}
        record("F3 [%s] activities unchanged; WBS levels 1,3-6 keep their colours; levels >=7 are no longer all red" % label,
               fill_diff_act == 0 and same_low and (not deep_new or ("FF0000" not in deep_new or len(deep_new) > 1) and old_deep_red),
               "levels>=7 old=%s new=%s" % (sorted({o for (l, o, n) in lvl_diff if l >= 7}), sorted(deep_new)))
        g_new = [wn.cell(r, 7).value for r in range(8, wn.max_row + 1) if wn.cell(r, 3).value == "YES"]
        manual = [[wn.cell(r, c).value for c in (10, 11, 16, 18)] for r in range(8, wn.max_row + 1) if wn.cell(r, 3).value == "YES"]
        record("F4 [%s] manual-entry fields (weights, actual dates, actual qty) still blank" % label, not any(g_new) and not any(any(m) for m in manual))
    # activity counts / WBS order vs the XER (new engine, real file)
    T, _e = P.parse_xer(REAL)
    new_real = os.path.join(WORK, "f_new")
    run_cli(ROOT, REAL, new_real)
    fnr = next(os.path.join(new_real, x) for x in os.listdir(new_real) if x.endswith(".xlsx"))
    rows_r = read_rows(fnr)
    record("F5 real XER: all %d activities imported, WBS order equals P6 seq_num order" % len(T["TASK"]),
           sum(1 for r in rows_r if r[3] == "YES") == len(T["TASK"]))
    scb = openpyxl.load_workbook(fnr)["S-CURVE"]
    record("F6 baseline handling unchanged: real XER has no baseline, BL cells say NOT AVAILABLE (current dates not used as baseline)", str(scb["C1"].value).startswith("NOT AVAILABLE") and str(scb["C2"].value).startswith("NOT AVAILABLE"))
    nb = os.path.join(WORK, "f_new")
    shutil.rmtree(nb, ignore_errors=True)
    run_cli(ROOT, base_x, nb)
    fnb = next(os.path.join(nb, x) for x in os.listdir(nb) if x.endswith(".xlsx"))
    scb2 = openpyxl.load_workbook(fnb)["S-CURVE"]
    record("F7 baseline found (synthetic): BL dates are real dates", isinstance(scb2["C1"].value, datetime) and isinstance(scb2["C2"].value, datetime), "%s / %s (simulated baseline - not a real P6 export)" % (scb2["C1"].value, scb2["C2"].value))
else:
    record("F* old-engine comparison", True, "SKIPPED: pristine old engine folder not supplied: %s" % OLD_DIR)

# ------------------------------------------------------------------------------------------------ summary
print("\n==== %d tests: %d passed, %d failed  (work folder: %s) ====" % (len(RESULTS), sum(1 for r in RESULTS if r[1]), sum(1 for r in RESULTS if not r[1]), WORK))
json.dump([dict(name=n, ok=o, detail=d) for n, o, d in RESULTS], open(os.path.join(HERE, "last_color_test_results.json"), "w"), indent=1)
sys.exit(0 if all(r[1] for r in RESULTS) else 1)
