# -*- coding: utf-8 -*-
"""Builds SIMULATED XER files for testing (they are NOT real P6 exports)."""
import sys, os, re, random
from datetime import datetime, timedelta
from collections import defaultdict
import openpyxl

def table(name, fields, rows):
    out = ["%T\t" + name, "%F\t" + "\t".join(fields)]
    for r in rows:
        out.append("%R\t" + "\t".join("" if r.get(f) is None else str(r.get(f)) for f in fields))
    return "\r\n".join(out)

PF = ["proj_id","proj_short_name","project_flag","orig_proj_id","base_type_id","sum_base_proj_id","last_recalc_date"]
WF = ["wbs_id","proj_id","proj_node_flag","parent_wbs_id","wbs_name","wbs_short_name","seq_num"]
TF = ["task_id","proj_id","wbs_id","task_code","task_name","task_type","status_code","target_start_date","target_end_date",
      "early_start_date","early_end_date","act_start_date","act_end_date","target_drtn_hr_cnt","remain_drtn_hr_cnt",
      "clndr_id","complete_pct_type","phys_complete_pct","target_work_qty","remain_work_qty"]
CF = ["clndr_id","clndr_name"]

def fmt(d): return d.strftime("%Y-%m-%d %H:%M") if d else ""

def write_xer(path, projects, wbs, tasks):
    txt = ["ERMHDR\t8.0\t2026-10-27\tProject\tADMIN\tx\tdb\tProject Management\tUSD",
           table("CALENDAR", CF, [dict(clndr_id=1, clndr_name="Std 5d")]),
           table("PROJECT", PF, projects), table("PROJWBS", WF, wbs), table("TASK", TF, tasks), "%E"]
    open(path, "w", encoding="cp1252", errors="replace", newline="").write("\r\n".join(txt) + "\r\n")

def from_template(template, path, short="CN103904", data_date=datetime(2026,10,22)):
    """Rebuild a project (WBS tree, IDs, dates) from the 132kV PMS template rows -> SIMULATED XER."""
    ws = openpyxl.load_workbook(template).worksheets[0]
    last = max(r for r in range(8, ws.max_row+1) if isinstance(ws.cell(r,2).value, int) and ws.cell(r,1).value)
    wbs, tasks, stack = [], [], {}
    wid = 100; tid = 1000
    for r in range(9, last+1):                    # skip overall row 8
        lvl, isact = ws.cell(r,2).value, ws.cell(r,3).value
        if isact == "NO":
            wid += 1
            parent = stack.get(lvl-1)
            wbs.append(dict(wbs_id=wid, proj_id=1, proj_node_flag="Y" if lvl==2 else "N", parent_wbs_id=parent or "",
                            wbs_name=str(ws.cell(r,4).value).strip(), wbs_short_name=str(wid), seq_num=len(wbs)*10))
            stack[lvl] = wid
        else:
            tid += 1
            code = str(ws.cell(r,4).value).strip(); h, i = ws.cell(r,8).value, ws.cell(r,9).value
            typ = "TT_Task"
            if h and not i: typ = "TT_Mile"
            if i and not h: typ = "TT_FinMile"
            s = h or i; f = i or h
            tasks.append(dict(task_id=tid, proj_id=1, wbs_id=stack[lvl-1], task_code=code, task_name=ws.cell(r,5).value,
                              task_type=typ, status_code="TK_NotStart", target_start_date=fmt(s), target_end_date=fmt(f),
                              early_start_date=fmt(s), early_end_date=fmt(f), target_drtn_hr_cnt=((f-s).days+1)*8 if s and f else 0,
                              remain_drtn_hr_cnt=((f-s).days+1)*8 if s and f else 0, clndr_id=1))
    proj = [dict(proj_id=1, proj_short_name=short, project_flag="Y", last_recalc_date=fmt(data_date))]
    write_xer(path, proj, wbs, tasks)
    return len(tasks), len(wbs)

def add_baseline(src_xer, dst_xer, shift_days=-14, drop_every=17, link=True):
    """Copy a real XER and add a baseline project (dates shifted, some tasks missing) -> SIMULATED baseline."""
    t = open(src_xer, "rb").read().decode("cp1252", errors="replace").split("\r\n")
    cur, hdr, out = None, None, []
    tasks_rows = []
    for ln in t:
        if ln.startswith("%T"): cur = ln.split("\t")[1]
        elif ln.startswith("%F"): hdr = ln.split("\t")[1:]
        if cur == "TASK" and ln.startswith("%R"): tasks_rows.append(dict(zip(hdr, ln.split("\t")[1:])))
    new_out, cur = [], None
    for ln in t:
        if ln.startswith("%T"): cur = ln.split("\t")[1]
        if cur == "PROJECT" and ln.startswith("%F"):
            new_out.append(ln); h = ln.split("\t")[1:]; continue
        if cur == "PROJECT" and ln.startswith("%R"):
            v = ln.split("\t")[1:]; d = dict(zip(h, v))
            if link: d["sum_base_proj_id"] = "9001"
            new_out.append("%R\t" + "\t".join(d.get(k, "") for k in h))
            b = dict(d); b.update(proj_id="9001", project_flag="N", orig_proj_id=d["proj_id"], base_type_id="77", sum_base_proj_id="",
                                  proj_short_name=d["proj_short_name"] + "-BL1")
            new_out.append("%R\t" + "\t".join(b.get(k, "") for k in h)); continue
        if cur == "TASK" and ln.startswith("%F"):
            new_out.append(ln); th = ln.split("\t")[1:]; continue
        if cur == "TASK" and ln.startswith("%R"):
            new_out.append(ln); continue
        if cur == "TASK" and ln.startswith("%T"): pass
        new_out.append(ln)
    # append baseline task rows right after the last live TASK row
    idx = max(i for i, l in enumerate(new_out) if l.startswith("%R")) if False else None
    res, cur = [], None
    last_task_i = None
    for i, ln in enumerate(new_out):
        if ln.startswith("%T"): cur = ln.split("\t")[1]
        if cur == "TASK" and ln.startswith("%R"): last_task_i = i
    bl = []
    for n, r in enumerate(tasks_rows):
        if drop_every and n % drop_every == 0: continue
        b = dict(r); b["proj_id"] = "9001"; b["task_id"] = str(int(r["task_id"]) + 500000)
        for k in ("target_start_date", "target_end_date"):
            if r.get(k):
                d = datetime.strptime(r[k], "%Y-%m-%d %H:%M") + timedelta(days=shift_days)
                b[k] = d.strftime("%Y-%m-%d %H:%M")
        bl.append("%R\t" + "\t".join(b.get(k, "") for k in th))
    new_out[last_task_i+1:last_task_i+1] = bl
    open(dst_xer, "wb").write("\r\n".join(new_out).encode("cp1252", errors="replace"))
    return len(tasks_rows), len(bl)

def stress(path, n_acts=1800, depth=9, seed=3):
    """Deep WBS (depth levels), many activities, long duration, mixed types, empty WBS, odd IDs."""
    random.seed(seed)
    wbs, tasks = [], []
    wid, tid = 0, 0
    start0 = datetime(2026, 1, 4)
    def node(parent, level, name, proj_node=False):
        nonlocal wid
        wid += 1
        wbs.append(dict(wbs_id=wid, proj_id=1, proj_node_flag="Y" if proj_node else "N", parent_wbs_id=parent or "",
                        wbs_name=name, wbs_short_name=str(wid), seq_num=wid))
        return wid
    root = node(None, 1, "STRESS-PROJECT Gas Plant", True)
    leaves = []
    def grow(parent, level):
        if level > depth: leaves.append(parent); return
        for k in range(3 if level < 4 else 2):
            if len(leaves) > 80: leaves.append(parent); return
            c = node(parent, level, "Level%d-%d Pipe/Gas/Civil" % (level, k))
            grow(c, level+1)
    grow(root, 2)
    node(root, 2, "Empty placeholder WBS")             # empty WBS
    per = n_acts // len(leaves) + 1
    for lf in leaves:
        for k in range(per):
            if tid >= n_acts: break
            tid += 1
            s = start0 + timedelta(days=random.randint(0, 900)); d = random.randint(1, 120)
            typ = "TT_Task"; st = s; fi = s + timedelta(days=d)
            if tid % 97 == 0: typ = "TT_Mile"
            if tid % 89 == 0: typ = "TT_FinMile"
            if tid % 211 == 0: typ = "TT_LOE"
            tasks.append(dict(task_id=tid, proj_id=1, wbs_id=lf, task_code="X-%s%d" % (random.choice("ABC"), 1000 + tid * 10),
                              task_name="Install & test item %d (مادة)" % tid, task_type=typ, status_code="TK_NotStart",
                              target_start_date=fmt(st), target_end_date=fmt(fi), early_start_date=fmt(st), early_end_date=fmt(fi),
                              target_drtn_hr_cnt=d*8, remain_drtn_hr_cnt=d*8, clndr_id=1))
    proj = [dict(proj_id=1, proj_short_name="STRESS-01", project_flag="Y", last_recalc_date=fmt(datetime(2026, 10, 25)))]
    write_xer(path, proj, wbs, tasks)
    return len(tasks), len(wbs)

def multi(path):
    """Two live projects in one XER (like the 132kV file that also had a GIS project)."""
    wbs, tasks = [], []
    w = 0; t = 0
    for pid, name in ((1, "Plant A Civil Works"), (2, "Plant B Electrical")):
        w += 1; root = w
        wbs.append(dict(wbs_id=w, proj_id=pid, proj_node_flag="Y", parent_wbs_id="", wbs_name=name, wbs_short_name=name[:5], seq_num=w))
        for k in range(2):
            w += 1
            wbs.append(dict(wbs_id=w, proj_id=pid, proj_node_flag="N", parent_wbs_id=root, wbs_name="Area %d" % k, wbs_short_name=str(w), seq_num=k))
            for j in range(5):
                t += 1
                s = datetime(2026, 5, 3) + timedelta(days=j*9 + k*30 + pid*3); f = s + timedelta(days=12)
                tasks.append(dict(task_id=t, proj_id=pid, wbs_id=w, task_code="A%d" % (1000 + (k*5 + j)*10), task_name="Work %d.%d.%d" % (pid, k, j),
                                  task_type="TT_Task", status_code="TK_NotStart", target_start_date=fmt(s), target_end_date=fmt(f),
                                  early_start_date=fmt(s), early_end_date=fmt(f), target_drtn_hr_cnt=104, remain_drtn_hr_cnt=104, clndr_id=1))
    proj = [dict(proj_id=1, proj_short_name="PA-01", project_flag="Y", last_recalc_date="2026-10-20 00:00"),
            dict(proj_id=2, proj_short_name="PB-02", project_flag="Y", last_recalc_date="2026-10-22 00:00")]
    write_xer(path, proj, wbs, tasks)

if __name__ == "__main__":
    out = sys.argv[1]; tpl = sys.argv[2]; real = sys.argv[3]
    os.makedirs(out, exist_ok=True)
    print("from_template", from_template(tpl, os.path.join(out, "SIM_132kV_from_template.xer")))
    print("baseline", add_baseline(real, os.path.join(out, "SIM_MWP_with_baseline.xer")))
    print("baseline-not-linked", add_baseline(real, os.path.join(out, "SIM_MWP_baseline_by_orig.xer"), link=False))
    print("stress", stress(os.path.join(out, "SIM_stress.xer")))
    multi(os.path.join(out, "SIM_two_projects.xer"))


# ---------------------------------------------------------------------------------------------------
# SIMULATED resources / cost / baseline XER (NOT a real P6 export) used to test the Weight Settings
def with_resources(src_xer, dst_xer, with_baseline=True, materials=False):
    """Copy a real XER and add RSRC, TASKRSRC, PROJCOST (+ a baseline project with different costs)."""
    t = open(src_xer, "rb").read().decode("cp1252", errors="replace").split("\r\n")
    cur, th, tasks = None, None, []
    for ln in t:
        if ln.startswith("%T"): cur = ln.split("\t")[1]
        elif ln.startswith("%F") and cur == "TASK": th = ln.split("\t")[1:]
        elif ln.startswith("%R") and cur == "TASK": tasks.append(dict(zip(th, ln.split("\t")[1:])))
    RF = ["rsrc_id", "rsrc_name", "rsrc_type", "unit_id", "curr_id"]
    TRF = ["taskrsrc_id", "task_id", "proj_id", "rsrc_id", "target_qty", "target_cost"]
    CFF = ["cost_item_id", "task_id", "proj_id", "target_cost"]
    UF = ["unit_id", "unit_abbrev_name"]
    rs = [dict(rsrc_id=1, rsrc_name="Engineer", rsrc_type="RT_Labor", curr_id=1), dict(rsrc_id=2, rsrc_name="Crane", rsrc_type="RT_Equip", curr_id=1)]
    if materials:
        rs.append(dict(rsrc_id=3, rsrc_name="Cable", rsrc_type="RT_Mat", unit_id=7, curr_id=1))
    tr, pc, n = [], [], 0
    for i, r in enumerate(tasks):
        if r["task_type"] != "TT_Task" or i % 9 == 0:        # milestones and every 9th task: no assignments (missing data)
            continue
        n += 1
        tr.append(dict(taskrsrc_id=n, task_id=r["task_id"], proj_id=r["proj_id"], rsrc_id=1, target_qty=8 * (1 + i % 5), target_cost=100 * (1 + i % 5)))
        if i % 4 == 0:
            n += 1
            tr.append(dict(taskrsrc_id=n, task_id=r["task_id"], proj_id=r["proj_id"], rsrc_id=2, target_qty=4, target_cost=900))
        if materials and i % 6 == 0:
            n += 1
            tr.append(dict(taskrsrc_id=n, task_id=r["task_id"], proj_id=r["proj_id"], rsrc_id=3, target_qty=50, target_cost=300))
        if i % 11 == 0:
            pc.append(dict(cost_item_id=i, task_id=r["task_id"], proj_id=r["proj_id"], target_cost=250))
    if tr: tr.append(dict(tr[0]))                              # a duplicated row (same taskrsrc_id) to prove no double counting
    extra = [table("RSRC", RF, rs), table("UNIT", UF, [dict(unit_id=7, unit_abbrev_name="m")]), table("TASKRSRC", TRF, tr), table("PROJCOST", CFF, pc)]
    body = "\r\n".join(t)
    body = body.replace("%E", "\r\n".join(extra) + "\r\n%E")
    open(dst_xer, "wb").write(body.encode("cp1252", errors="replace"))
    if with_baseline:
        add_baseline(dst_xer, dst_xer, shift_days=-14, drop_every=17)
        # baseline assignments: same tasks (+500000 ids) with 2x cost
        t2 = open(dst_xer, "rb").read().decode("cp1252", errors="replace")
        rows = []
        for r in tr[:-1]:
            if int(r["task_id"]) + 500000 in {int(x["task_id"]) + 500000 for x in tasks}:
                rows.append(dict(taskrsrc_id=100000 + int(r["taskrsrc_id"]), task_id=int(r["task_id"]) + 500000, proj_id=9001,
                                 rsrc_id=r["rsrc_id"], target_qty=r["target_qty"], target_cost=float(r["target_cost"]) * 2))
        lines = t2.split("\r\n")
        for i, l in enumerate(lines):
            if l.startswith("%T\tTASKRSRC"):
                j = i + 2
                while lines[j].startswith("%R"): j += 1
                lines[j:j] = ["%R\t" + "\t".join(str(x.get(f, "")) for f in TRF) for x in rows]
                break
        open(dst_xer, "wb").write("\r\n".join(lines).encode("cp1252", errors="replace"))
    return len(tasks), len(tr)

if __name__ == "__main__" and len(sys.argv) > 3:
    out = sys.argv[1]; real = sys.argv[3]
    print("resources", with_resources(real, os.path.join(out, "SIM_MWP_resources_baseline.xer")))
    print("resources+materials", with_resources(real, os.path.join(out, "SIM_MWP_resources_materials.xer"), with_baseline=False, materials=True))
