"""Smoke test of pms_gui.py logic WITHOUT Qt: a permissive stub replaces PySide6 (threads run synchronously).
It catches NameErrors / wrong attribute use / logic errors in OUR code. It does NOT test how the window looks or Qt behaviour."""
import sys, types, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class Any:
    def __init__(self, *a, **k): self._v = None; self._items = []; self._checked = False; self._text = ""; self._data = {}
    def __getattr__(self, n):
        if n.startswith("__"): raise AttributeError(n)
        return Any()
    def __call__(self, *a, **k): return Any()
    def __or__(self, o): return self
    def __ror__(self, o): return self
    def __iter__(self): return iter(())
    def __bool__(self): return True
    def __int__(self): return 0
    def __index__(self): return 0
    def count(self): return 0
    def indexOf(self, x): return -1
    def itemAt(self, i): return None
    def connect(self, f): self._cb = f
    def emit(self, *a):
        getattr(self, "_cb", lambda *x: None)(*a)

class Sig:
    def __init__(self, *a): pass
    def __set_name__(self, owner, name): self.name = name
    def __get__(self, obj, typ=None):
        if obj is None: return self
        return obj.__dict__.setdefault("_sig_" + self.name, Any())

class QThread(Any):
    def start(self): self.run()
class Meta(type):
    def __getattr__(cls, n):
        if n.startswith('__'): raise AttributeError(n)
        return Any()
class QWidgetStub(Any, metaclass=Meta): pass

def mk_mod(name, **extra):
    m = types.ModuleType(name)
    m.__getattr__ = lambda n: Meta(n, (QWidgetStub,), {}) if n[0].isupper() else Any()
    for k, v in extra.items(): setattr(m, k, v)
    sys.modules[name] = m
    return m
class Qt(Any): pass
mk_mod("PySide6"); core = mk_mod("PySide6.QtCore", Signal=Sig, QThread=QThread, Qt=Any(), QDate=Meta("QDate", (QWidgetStub,), {}), QSize=Any, QTimer=Any(), QUrl=Any)
mk_mod("PySide6.QtGui"); mk_mod("PySide6.QtWidgets")

# state-carrying fake widgets for the few widgets whose values the logic reads
class FakeEdit(QWidgetStub):
    def text(self): return self._text
    def setText(self, t): self._text = t
    def clear(self): self._text = ""
class FakeCheck(QWidgetStub):
    def isChecked(self): return self._checked
    def setChecked(self, v): self._checked = v
class FakeCombo(QWidgetStub):
    def __init__(self, *a, **k): super().__init__(); self._idx = 0; self._items = []
    def currentIndex(self): return self._idx
    def setCurrentIndex(self, i): self._idx = i
    def addItems(self, l): self._items += list(l)
    def addItem(self, t, d=None): self._items.append(t); self._data[len(self._items) - 1] = d
    def clear(self): self._items = []; self._data = {}
    def currentData(self): return self._data.get(self._idx)
class FakeSpin(QWidgetStub):
    def value(self): return 5
sys.modules["PySide6.QtWidgets"].QLineEdit = FakeEdit
sys.modules["PySide6.QtWidgets"].QCheckBox = FakeCheck
sys.modules["PySide6.QtWidgets"].QRadioButton = FakeCheck
sys.modules["PySide6.QtWidgets"].QComboBox = FakeCombo
sys.modules["PySide6.QtWidgets"].QSpinBox = FakeSpin
class FakeDate(QWidgetStub):
    def date(self): return types.SimpleNamespace(year=lambda: 2026, month=lambda: 10, day=lambda: 29)
sys.modules["PySide6.QtWidgets"].QDateEdit = FakeDate
class FakeMsg(metaclass=Meta):
    shown = []
    def __init__(self, *a): self._btns = []
    def setIcon(self, *a): pass
    def setWindowTitle(self, *a): pass
    def setText(self, t): FakeMsg.shown.append(('box', t))
    def setInformativeText(self, *a): pass
    def addButton(self, t, r): b = object(); self._btns.append(b); return b
    def exec(self): pass
    def clickedButton(self): return self._btns[-1]   # user presses Cancel
    class Icon: Question = 1
    class ButtonRole: DestructiveRole = 1; AcceptRole = 2; RejectRole = 3
    @staticmethod
    def warning(*a): FakeMsg.shown.append(("warning", a[-1])); 
    @staticmethod
    def critical(*a): FakeMsg.shown.append(("critical", a[-1]))
    @staticmethod
    def information(*a): FakeMsg.shown.append(("info", a[-1]))
sys.modules["PySide6.QtWidgets"].QMessageBox = FakeMsg

import pms_gui as G
import p6_to_pms as engine
G.P = engine
w = G.MainWindow()
real = "/mnt/user-data/uploads/MWP-CB38-MI-SCH_.xer"
w.set_xer(real)
assert w.info and w.info["baseline_state"] == "NOT_IN_FILE", w.info
print("inspect ok:", w.lb_name.text() if hasattr(w.lb_name, "text") else "", w.info["baseline_state"])
# weights mapping
for key, idx, expect in (("A", 0, "cost_baseline"), ("A", 1, "cost_current"), ("A", 2, "cost_custom"), ("B", 0, "res_labor"), ("B", 1, "res_total"), ("C", 0, "none"), ("C", 1, "equal"), ("C", 2, "duration")):
    for k in w.rb: w.rb[k].setChecked(k == key)
    w.cb[key].setCurrentIndex(idx)
    assert w.weight_method() == expect, (key, idx, w.weight_method())
print("weight method mapping ok")
w.rb["C"].setChecked(True); w.rb["A"].setChecked(False); w.rb["B"].setChecked(False)
w.cb["C"].setCurrentIndex(1)
w.ed_out.setText("/tmp/gui_out")
opts = w._options(); print("options:", opts)
assert opts["weight_method"] == "equal" and opts["out_dir"] == "/tmp/gui_out" and opts["planned_source"] == "auto"
# run generate synchronously (first time) then the overwrite path
import shutil; shutil.rmtree("/tmp/gui_out", ignore_errors=True)
w.generate()
assert w.last and os.path.isfile(w.last["output"]), "no result"
print("generated:", w.last["output"], "| errors", len(w.last["errors"]))
first = w.last
w.last = None
w.generate()              # file exists -> PmsExistsError -> the (stub) message box returns an Any; must not crash
print("second run handled; last is", "None (waiting for user choice)" if w.last is None else "set")
print("unique_path:", G.unique_path(first["output"]))
# multi project: must refuse until a project is ticked
w.set_xer("/home/claude/pms/tests/xer/SIM_two_projects.xer")
w.generate(); print("multi-project warning:", FakeMsg.shown[-1])
print("GUI stub test finished")

# ---- theme / branding additions (v1.1.x dark-gold theme): exercised through the stub, so only NameErrors/logic are checked
import re as _re
css = G.build_stylesheet()
assert not _re.findall(r"\$[a-z_0-9]+", css), "unresolved placeholders in the stylesheet"
G.apply_theme(Any())
assert G.PAL["dark"] and G.PAL["accent"] == "#CFA84B", G.PAL.get("accent")
G.make_splash(); G.AboutDialog(w); G.AppearanceDialog(w)
print("theme/splash/about/appearance constructed; palette dark =", G.PAL["dark"], "| accent", G.PAL["accent"], "| banner:", bool(G.app_banner_path()))

# ---- v1.2 colour settings (stub: logic only)
w.set_xer(real)
assert w.info["colors"]["kind"] in ("none", "stored"), w.info["colors"]
w.ed_colors.setText("/tmp/some_map.csv"); w.ck_remember.setChecked(True); w.cb_fallback.setCurrentIndex(1)
o = w._options()
assert o["wbs_colors"] == "/tmp/some_map.csv" and o["remember_colors"] is True and o["fallback_colors"] == "none", o
w.set_xer("/home/claude/pms/tests/xer/SIM_two_projects.xer")        # another schedule: project-specific inputs are dropped
assert w.ed_colors.text() == "" and w.info is not None, "colour map path must be cleared when another XER is loaded"
o2 = w._options()
assert "wbs_colors" not in o2, o2
print("colour settings OK: options carried, project-specific inputs cleared on a new XER")
