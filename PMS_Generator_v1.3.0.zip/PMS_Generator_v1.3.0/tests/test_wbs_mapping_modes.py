"""Focused regression tests for project-specific WBS mapping and auto/manual source behavior."""
import json
import os
import tempfile
from pathlib import Path
import sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import pms_colors as C


def test_project_keys_include_project_id():
    assert C.project_key("Shared Name", "P100") != C.project_key("Shared Name", "P200")
    assert C.project_key("Shared Name", "P100") == C.project_key("Shared Name", "P100")


def test_same_project_name_different_ids_do_not_share_mapping_file():
    with tempfile.TemporaryDirectory() as d:
        os.environ["PMS_GENERATOR_HOME"] = d
        C.data_dir  # ensure module stays usable with a runtime-specific data directory
        first = C.project_key("Shared Name", "P100")
        second = C.project_key("Shared Name", "P200")
        mapping_dir = Path(C.color_map_dir())
        mapping_dir.mkdir(parents=True, exist_ok=True)
        (mapping_dir / (first + ".json")).write_text('{"project":"Shared Name","levels":{"1":"#1F4E79"}}', encoding="utf-8")
        assert (mapping_dir / (first + ".json")).exists()
        assert not (mapping_dir / (second + ".json")).exists()


def test_hex_parser_accepts_arbitrary_rgb_hex():
    assert C.parse_color("#1F4E79") == "1F4E79"
    assert C.parse_color("#00FF00") == "00FF00"
    assert C.parse_color("not-a-color") is None


def test_palette_supports_eleven_levels_without_collapsing_deep_levels():
    colors = [C.fallback_hex(i) for i in range(1, 12)]
    assert len(colors) == 11
    assert len(set(colors)) == 11


def test_manual_mapping_roundtrip_json():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "mapping.json"
        p.write_text(json.dumps({"levels": {"1": "#1F4E79", "11": "#996633"}, "nodes": {}}), encoding="utf-8")
        levels, nodes, notes = C._read_map_file(str(p))
        assert levels[1] == "1F4E79" and levels[11] == "996633"
        assert nodes == {}
