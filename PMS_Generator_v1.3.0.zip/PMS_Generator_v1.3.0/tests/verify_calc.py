"""Fill random weights/actuals into a generated PMS, recalc with LibreOffice and compare with an independent Python calculation."""
import sys, random, shutil, subprocess, json, os
from datetime import datetime, timedelta
import openpyxl
from openpyxl.utils import get_column_letter as L

src, tag = sys.argv[1], sys.argv[2]
random.seed(11)
tmp = "/tmp/verify_%s.xlsx" % tag
wb = openpyxl.load_workbook(src)
ws = wb["PMS"]
acts = [r for r in range(8, ws.max_row + 1) if ws.cell(r, 3).value == "YES"]
W = {}
for r in acts:
    h, i = ws.cell(r, 8).value, ws.cell(r, 9).value
    w = 0 if not (h and i) else random.choice([1, 2, 3, 5, 8])
    W[r] = w
    ws.cell(r, 7, w)
    if w and random.random() < 0.35:
        ws.cell(r, 18, round(random.uniform(0.1, 1.0), 2))     # CUM. ACTUAL QTY (BUG QTY = 1 -> fraction)
        ws.cell(r, 16, 0)
wb.save(tmp)
rc = subprocess.run([sys.executable, "/mnt/skills/public/xlsx/scripts/recalc.py", tmp, "180"], capture_output=True, text=True, cwd="/mnt/skills/public/xlsx")
res = json.loads(rc.stdout[rc.stdout.index("{"):])
errs = res.get("error_summary", {})
bad = {k: v for k, v in errs.items() if not (k == "#N/A" and all(x.startswith("S-CURVE!") and x[8:].rstrip("0123456789") and x.split("!")[1].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ") in ("8", "9") for x in v["locations"]))}
print("recalc:", res.get("status"), "formulas:", res.get("total_formulas"), "| unexpected errors:", bad if bad else "none",
      "| expected NA() cells (S-CURVE rows 8-9 after report date):", errs.get("#N/A", {}).get("count", 0))
v = openpyxl.load_workbook(tmp, data_only=True); wv = v["PMS"]; sc = v["S-CURVE"]
X3 = wv["X3"].value
totw = sum(W.values())
# independent calc ------------------------------------------------------------
H8 = wv["H8"].value
last = max(r for r in range(8, wv.max_row + 1) if wv.cell(r, 3).value in ("YES", "NO") and wv.cell(r, 1).value)
k = ((X3 - H8).days) // 7
D = H8 + timedelta(days=7 * k)                     # last weekly date <= X3 (HLOOKUP approx match)
def frac(r, d):
    h, i = wv.cell(r, 8).value, wv.cell(r, 9).value
    dur = (i - h).days + 1 if (h and i) else 1
    if h and i and d >= h and d < i: return ((d - h).days + 1) / dur
    if i and d >= i: return 1.0
    return 0.0
plan_week = sum(W[r] * frac(r, D) for r in acts) / totw
act = sum(W[r] * (wv.cell(r, 18).value or 0) for r in acts) / totw
print("G8 (sum of weights): %s expected %s" % (wv["G8"].value, totw))
print("PMS S8 planned @ last weekly date <= report date: %.6f expected %.6f" % (wv["S8"].value, plan_week))
print("PMS Y8 cumulative actual: %.6f expected %.6f" % (wv["Y8"].value, act))
# S-CURVE at the report date column
col = next((c for c in range(3, sc.max_column + 1) if sc.cell(3, c).value == X3), None)
if col:
    def daily(r, d):
        h, i = wv.cell(r, 8).value, wv.cell(r, 9).value
        if not (h and i): return 0.0
        dur = (i - h).days + 1
        x = ((d - h).days + 1) / dur
        return 1.0 if x >= 1 else (x if x > 0 else 0.0)
    cum = sum(W[r] * daily(r, X3) for r in acts) / totw
    print("S-CURVE cum plan @ report date: %.6f expected %.6f | cum actual %.6f expected %.6f" % (sc.cell(5, col).value, cum, sc.cell(9, col).value, act))
else:
    print("report date is not one of the S-CURVE dates!")
# roll-up consistency: each summary G == sum of direct children G
keys = {wv.cell(r, 1).value: r for r in range(8, last + 1)}
bad_roll = 0
for key, r in keys.items():
    kids = [rr for kk, rr in keys.items() if kk.startswith(key + ".") and kk.count(".") == key.count(".") + 1]
    if kids and abs((wv.cell(r, 7).value or 0) - sum(wv.cell(x, 7).value or 0 for x in kids)) > 1e-9: bad_roll += 1
print("roll-up mismatches:", bad_roll)
