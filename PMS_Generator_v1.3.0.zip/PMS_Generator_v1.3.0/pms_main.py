# -*- coding: utf-8 -*-
"""Entry point of PMS GENERATOR (used by PyInstaller too). Developed by Eng. Ali Ahmed | IGCC"""
import os
import sys

if sys.stdout is None:            # windowed .exe has no console
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

from p6_to_pms import main      # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
