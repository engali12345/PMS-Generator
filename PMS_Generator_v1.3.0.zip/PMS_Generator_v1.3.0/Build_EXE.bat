@echo off
setlocal
cd /d "%~dp0"
title PMS Generator - Build EXE

echo ============================================================
echo   PMS Generator v1.0.0 - Windows EXE Builder
echo ============================================================
echo.

rem Find a supported Python launcher. Python 3.10+ is required.
where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python 3.10 or newer was not found.
        echo Install Python from https://www.python.org/downloads/windows/
        echo During installation, enable "Add python.exe to PATH".
        echo Then reopen this file.
        goto :fail
    )
    set "PY=python"
)

%PY% -c "import sys; print('Using Python', sys.version)" || goto :fail

rem Create a fresh build environment only if it does not exist.
if not exist ".venv_build\Scripts\python.exe" (
    echo Creating clean build environment...
    %PY% -m venv .venv_build || goto :fail
)

set "VPY=%CD%\.venv_build\Scripts\python.exe"

echo.
echo Installing/updating required packages...
"%VPY%" -m ensurepip --upgrade
if errorlevel 1 (
    echo ERROR: Could not initialize pip in the build environment.
    goto :fail
)
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

if not exist "pms_icon.ico" (
    echo Creating application icon...
    "%VPY%" make_icon.py
    if errorlevel 1 goto :fail
)

echo.
echo Building PMS_Generator.exe...
"%VPY%" -m PyInstaller --noconfirm --clean --windowed --name PMS_Generator ^
  --icon pms_icon.ico ^
  --add-data "PMS_Master_Template.xlsx;." ^
  --add-data "pms_icon.png;." --add-data "pms_icon.ico;." --add-data "pms_logo.png;." ^
  --add-data "LICENSE.txt;." --add-data "THIRD_PARTY_LICENSES.txt;." ^
  --exclude-module tkinter ^
  pms_main.py
if errorlevel 1 goto :fail

if exist "README_PMS.txt" copy /Y "README_PMS.txt" "dist\PMS_Generator\" >nul

echo.
echo ===== BUILD OK =====
echo EXE: %CD%\dist\PMS_Generator\PMS_Generator.exe
echo Copy the entire dist\PMS_Generator folder when moving it to another PC.
echo.
pause
exit /b 0

:fail
echo.
echo ===== BUILD FAILED =====
echo Check the error messages above. If package download failed, check internet access.
echo Log path, if the app has started: %%LOCALAPPDATA%%\PMS_Generator\logs\pms_generator.log
echo.
pause
exit /b 1
