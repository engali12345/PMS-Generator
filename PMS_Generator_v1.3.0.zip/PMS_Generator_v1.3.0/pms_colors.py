# -*- coding: utf-8 -*-
"""
WBS row colours for the PMS - project independent, with the PROVENANCE of every colour.

Why this module exists
  The colours you see for WBS levels in Primavera P6 come from the P6 *layout* (Group & Sort bands). An XER export does
  not carry layouts, so the XER normally holds NO colour information. The old engine therefore copied the colours of the
  Mishrif-Qurainat template (levels 1-6) and re-used level 6 (red) for every deeper level.

Colour sources, in priority order (every WBS row gets exactly one, and the validation report counts them):
  VERIFIED     explicit colour data inside the CURRENT project's XER: a colour-named PROJWBS field, or a WBS user-defined
               field (UDF) whose name contains "color"/"colour" holding a hex value such as #FFC000.
  USER         a colour map supplied for this project: JSON / CSV file, or the level colours read from a PMS .xlsx the
               user points to; it is remembered per project (never applied to another project).
  FALLBACK     a documented level palette (STANDARD_PALETTE) - reported as a fallback, it does NOT reproduce P6.
  UNAVAILABLE  no colour (plain row) when the user chose fallback = 'none'.

Colours are decided per WBS LEVEL (the number shown in column B of the PMS) or per WBS node - never per Excel row.
"""
import colorsys
import csv
import json
import os
import re
import hashlib
from collections import Counter, defaultdict
from datetime import datetime

from pms_common import PmsError, safe_filename

VERIFIED, USER, FALLBACK, UNAVAILABLE = "VERIFIED", "USER", "FALLBACK", "UNAVAILABLE"

# Level 1-6 follow the PMS house convention (purple, dark gold, green, yellow, blue, red); 7+ are distinct on purpose.
STANDARD_PALETTE = ["7030A0", "7F6000", "00B050", "FFFF00", "0070C0", "FF0000",
                    "FF9900", "00B0F0", "92D050", "FF66CC", "996633", "7F7F7F", "FFD966", "C00000", "002060"]

COLOR_FIELD_RE = re.compile(r"colou?r|rgb", re.I)


def data_dir():
    base = os.environ.get("PMS_GENERATOR_HOME")
    if not base:
        base = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share"), "PMS_Generator")
    return base


def color_map_dir():
    return os.path.join(data_dir(), "color_maps")


def project_key(short_name, project_id=None):
    """Stable per-project key. Include P6 project ID where available to avoid name collisions."""
    identity = (str(project_id).strip() + "::" if project_id not in (None, "") else "") + str(short_name or "project")
    stem = safe_filename(short_name or "project", "project")[:48]
    digest = hashlib.sha256(identity.encode("utf-8", "replace")).hexdigest()[:12]
    return "%s_%s" % (stem, digest)


# ------------------------------------------------------------------------------------------------ colour maths
def parse_color(v):
    """'#RRGGBB' | '0xRRGGBB' | 'RRGGBB' (must contain a letter A-F) | '#AARRGGBB' | 'rgb(r,g,b)'  ->  'RRGGBB' or None.
    Plain integers are NOT interpreted: RGB-vs-BGR order would be a guess."""
    if v is None:
        return None
    s = str(v).strip()
    m = re.fullmatch(r"rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)", s, re.I)
    if m:
        r, g, b = (int(x) for x in m.groups())
        return "%02X%02X%02X" % (r, g, b) if max(r, g, b) <= 255 else None
    prefixed = bool(re.match(r"^(#|0x)", s, re.I))
    s2 = re.sub(r"^(#|0x)", "", s, flags=re.I)
    if prefixed and re.fullmatch(r"[0-9A-Fa-f]{8}", s2):
        s2 = s2[2:]
    if re.fullmatch(r"[0-9A-Fa-f]{6}", s2) and (prefixed or not s2.isdigit()):
        return s2.upper()
    return None


def luminance(hex6):
    def f(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hex6[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def font_for(hex6):
    """White text when it has contrast >= 3:1 on the fill, otherwise black."""
    return "FFFFFF" if 1.05 / (luminance(hex6) + 0.05) >= 3.0 else "000000"


def _lighten(hex6, t):
    r, g, b = (int(hex6[i:i + 2], 16) for i in (0, 2, 4))
    return "%02X%02X%02X" % tuple(round(x + (255 - x) * t) for x in (r, g, b))


def fallback_hex(level):
    """Palette colour for a level (levels beyond the palette cycle with a lighter tint, so they stay distinct)."""
    i = max(1, int(level)) - 1
    n = len(STANDARD_PALETTE)
    return _lighten(STANDARD_PALETTE[i % n], 0.35 * (i // n)) if i >= n else STANDARD_PALETTE[i]


def theme_rgb(theme_xml, idx, tint):
    """Office theme colour index + tint -> RRGGBB (needed to read level colours from a PMS workbook).
    Resolved in floating point: can differ from Excel's own rounding by 1/255 on a channel."""
    order = ["lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink"]
    try:
        name = order[idx]
        m = re.search(r"<a:%s>(.*?)</a:%s>" % (name, name), theme_xml, re.S)
        c = re.findall(r'(?:val|lastClr)="([0-9A-Fa-f]{6})"', m.group(1))
        base = c[-1].upper() if name in ("lt1", "dk1") and c else c[0].upper()
    except (IndexError, AttributeError, TypeError):
        return None
    if not tint:
        return base
    r, g, b = (int(base[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    l = l * (1 + tint) if tint < 0 else l * (1 - tint) + (1 - (1 - tint))
    r, g, b = colorsys.hls_to_rgb(h, max(0, min(1, l)), s)
    return "%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))


# ------------------------------------------------------------------------------------------------ source 1: the XER itself
def xer_wbs_colors(T, node_ids):
    """Explicit WBS colours stored in the XER -> ({wbs_id: (hex, where)}, info_lines). Nothing is guessed."""
    found, info = {}, []
    wbs = T.get("PROJWBS", [])
    fields = [f for f in (wbs[0].keys() if wbs else []) if COLOR_FIELD_RE.search(f)]
    info.append("PROJWBS fields with a colour-like name: %s" % (", ".join(fields) if fields else "none"))
    bad = 0
    for f in fields:
        for w in wbs:
            if w.get("wbs_id") in node_ids and (w.get(f) or "").strip():
                c = parse_color(w[f])
                if c:
                    found[w["wbs_id"]] = (c, "PROJWBS.%s" % f)
                else:
                    bad += 1
    types = {}
    for u in T.get("UDFTYPE", []):
        label = "%s %s" % (u.get("udf_type_label", ""), u.get("udf_type_name", ""))
        if (u.get("table_name", "") or "").upper() == "PROJWBS" and COLOR_FIELD_RE.search(label):
            types[u.get("udf_type_id")] = (u.get("udf_type_label") or u.get("udf_type_name") or "").strip()
    info.append("WBS user-defined fields named like a colour: %s" % (", ".join(sorted(types.values())) if types else "none"))
    for v in T.get("UDFVALUE", []):
        if v.get("udf_type_id") in types and v.get("fk_id") in node_ids:
            raw = (v.get("udf_text") or "").strip()
            if not raw:
                continue
            c = parse_color(raw)
            if c:
                found.setdefault(v["fk_id"], (c, "WBS UDF '%s'" % types[v["udf_type_id"]]))
            else:
                bad += 1
    if bad:
        info.append("%d colour value(s) in the XER could not be read (only hex values like #FFC000 are accepted) and were ignored." % bad)
    info.append("WBS nodes with a readable colour in the XER: %d of %d" % (len(found), len(node_ids)))
    return found, info


# ------------------------------------------------------------------------------------------------ source 2: user supplied maps
def _read_pms_levels(path):
    """Level colours of the SUMMARY rows of a PMS workbook (fill of column E). Theme colours are resolved with the file's theme."""
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = next((s for s in wb if (s.cell(5, 1).value or "").strip().upper() == "VLOOKUP KEY"), None)
    if ws is None:
        raise PmsError("The colour source %s is not a PMS workbook (no sheet with 'VLOOKUP KEY' in A5)." % os.path.basename(path))
    theme = getattr(wb, "loaded_theme", None)
    theme = theme.decode("utf8", "ignore") if isinstance(theme, (bytes, bytearray)) else (theme or "")
    per, unreadable = defaultdict(Counter), Counter()
    for r in range(8, ws.max_row + 1):
        lv, yn = ws.cell(r, 2).value, ws.cell(r, 3).value
        if not isinstance(lv, int) or yn != "NO":
            continue
        f = ws.cell(r, 5).fill
        if not f.fill_type:
            unreadable[lv] += 1
            continue
        col = f.fgColor
        if col.type == "rgb" and isinstance(col.rgb, str):
            per[lv][col.rgb[-6:].upper()] += 1
        elif col.type == "theme":
            c = theme_rgb(theme, col.theme, col.tint)
            if c:
                per[lv][c] += 1
            else:
                unreadable[lv] += 1
        else:
            unreadable[lv] += 1
    notes, levels = [], {}
    for lv, cnt in sorted(per.items()):
        levels[lv] = cnt.most_common(1)[0][0]
        if len(cnt) > 1:
            notes.append("level %d has %d different fills in %s - the most common one (%s) was used." % (lv, len(cnt), os.path.basename(path), levels[lv]))
    for lv in sorted(set(unreadable) - set(levels)):
        notes.append("level %d: no readable fill in %s." % (lv, os.path.basename(path)))
    if not levels:
        raise PmsError("No readable level colours were found in %s." % os.path.basename(path))
    return levels, {}, notes


def _read_map_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return _read_pms_levels(path)
    raw = open(path, "rb").read()
    text = None
    for enc in ("utf-8-sig", "cp1256", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    levels, nodes, notes = {}, {}, []
    if ext == ".json" or text.lstrip().startswith("{"):
        try:
            d = json.loads(text)
        except ValueError as e:
            raise PmsError("The colour map is not valid JSON: %s" % e)
        lv = d.get("levels", d if all(str(k).isdigit() for k in d) else {})
        for k, v in lv.items():
            c = parse_color(v)
            if str(k).isdigit() and c:
                levels[int(k)] = c
            else:
                notes.append("ignored colour entry level %r = %r (not a level number / hex colour)" % (k, v))
        for k, v in (d.get("nodes") or {}).items():
            c = parse_color(v)
            if c:
                nodes[str(k).strip()] = c
            else:
                notes.append("ignored node colour %r = %r" % (k, v))
    else:
        dialect = csv.Sniffer().sniff(text[:2000], delimiters=",;\t") if text.strip() else csv.excel
        rows = list(csv.reader(text.splitlines(), dialect))
        if not rows:
            raise PmsError("The colour map file is empty.")
        head = [h.strip().lower() for h in rows[0]]
        ci = next((i for i, h in enumerate(head) if h in ("color", "colour", "hex", "fill")), None)
        li = next((i for i, h in enumerate(head) if h in ("level", "wbs level", "lvl")), None)
        ni = next((i for i, h in enumerate(head) if h in ("wbs", "wbs code", "code", "wbs name", "name", "wbs_short_name")), None)
        if ci is None or (li is None and ni is None):
            raise PmsError("CSV colour map needs a 'Level' (or 'WBS code') column and a 'Color' column.")
        for r in rows[1:]:
            if len(r) <= ci or not r[ci].strip():
                continue
            c = parse_color(r[ci])
            if not c:
                notes.append("ignored colour %r" % r[ci])
                continue
            if li is not None and len(r) > li and r[li].strip().isdigit():
                levels[int(r[li].strip())] = c
            elif ni is not None and len(r) > ni and r[ni].strip():
                nodes[r[ni].strip()] = c
    if not levels and not nodes:
        raise PmsError("The colour map %s holds no usable colours." % os.path.basename(path))
    return levels, nodes, notes


def load_user_map(path, key, short_name, remember=True):
    """Explicit file (and remember it for this project) or the map saved earlier for THIS project key."""
    d = color_map_dir()
    stored = os.path.join(d, key + ".json")
    if path:
        if not os.path.isfile(path):
            raise PmsError("The WBS colour map file was not found: %s" % path)
        levels, nodes, notes = _read_map_file(path)
        origin = "file %s" % os.path.basename(path)
        if remember:
            try:
                os.makedirs(d, exist_ok=True)
                with open(stored, "w", encoding="utf-8") as f:
                    json.dump(dict(project=short_name, saved=datetime.now().strftime("%Y-%m-%d %H:%M"), origin=origin,
                                   levels={str(k): "#" + v for k, v in levels.items()},
                                   nodes={k: "#" + v for k, v in nodes.items()}), f, indent=1)   # '#' keeps digit-only colours readable
                notes.append("saved as the colour map of project '%s' (%s)." % (short_name, stored))
            except OSError as e:
                notes.append("could not save the map for this project: %s" % e)
        return dict(levels=levels, nodes=nodes, origin=origin, kind="file", notes=notes)
    if os.path.isfile(stored):
        try:
            data = json.load(open(stored, encoding="utf-8"))
            if (data.get("project") or "") == short_name:       # a key collision between two projects is refused
                lv = {int(k): parse_color(c) for k, c in (data.get("levels") or {}).items() if parse_color(c)}
                nd = {k: parse_color(c) for k, c in (data.get("nodes") or {}).items() if parse_color(c)}
                if lv or nd:
                    return dict(levels=lv, nodes=nd, kind="stored", notes=[],
                                origin="map saved for project '%s' on %s (from %s)" % (short_name, data.get("saved", "?"), data.get("origin", "?")))
        except (ValueError, OSError):
            pass
    return None


def stored_map_path(short_name, project_id=None):
    p = os.path.join(color_map_dir(), project_key(short_name, project_id) + ".json")
    return p if os.path.isfile(p) else None


# ------------------------------------------------------------------------------------------------ the plan
def resolve_colors(T, model, opts):
    """Colour of every summary (WBS) row of the model, with provenance. Sets rw['color'] = (hex6|None, source, detail)."""
    rows = [r for r in model["rows"] if r["kind"] == "sum"]
    short = model["short"]
    project_id = ",".join(str(p.get("proj_id", "")) for p in model.get("live", []))
    key = project_key(short, project_id)
    node_ids = {r["wbs"]["wbs_id"] for r in rows if r.get("wbs")}
    xer_cols, xer_info = xer_wbs_colors(T, node_ids)
    user = (load_user_map(opts.get("wbs_colors"), key, short, remember=opts.get("remember_colors", True))
            if opts.get("use_saved_colors", True) else
            (load_user_map(opts.get("wbs_colors"), key, short, remember=opts.get("remember_colors", True)) if opts.get("wbs_colors") else None))
    fb_mode = (opts.get("fallback_colors") or "standard").lower()
    msgs, infos = [], []
    for r in rows:
        w, lv = r.get("wbs"), r["level"]
        code = (w.get("wbs_short_name") or "").strip() if w else ""
        name = (w.get("wbs_name") or "").strip() if w else ""
        if w and w["wbs_id"] in xer_cols:
            c, where = xer_cols[w["wbs_id"]]
            r["color"] = (c, VERIFIED, where)
        elif user and w and (code in user["nodes"] or name in user["nodes"]):
            r["color"] = (user["nodes"].get(code) or user["nodes"][name], USER, user["origin"] + " (node)")
        elif user and lv in user["levels"]:
            r["color"] = (user["levels"][lv], USER, user["origin"])
        elif fb_mode == "none":
            r["color"] = (None, UNAVAILABLE, "no colour source and fallback colours switched off")
        else:
            r["color"] = (fallback_hex(lv), FALLBACK, "standard palette, level %d" % lv)
    p6 = [r for r in rows if r.get("wbs")]                     # real P6 WBS nodes (the overall row is a PMS construct)
    cnt = Counter(r["color"][1] for r in p6)
    overall = next((r["color"][1] for r in rows if not r.get("wbs")), None)
    levels = {}
    for r in rows:
        d = levels.setdefault(r["level"], dict(rows=0, colors=Counter(), sources=Counter()))
        d["rows"] += 1
        d["colors"][r["color"][0] or "-"] += 1
        d["sources"][r["color"][1]] += 1
    # ---- messages (limitations are always stated)
    if user:
        infos.append("User-supplied colours: %s." % user["origin"])
        infos += ["colour map: " + n for n in user["notes"]]
        infos.append("The program cannot compare user-supplied colours with P6 - they are only as exact as the map you supplied.")
    if cnt.get(FALLBACK):
        lv_fb = sorted(lv for lv, d in levels.items() if d["sources"].get(FALLBACK))
        msgs.append("WBS COLORS: %d of %d WBS rows use the FALLBACK palette (levels %s). The XER holds no usable colour information "
                    "(P6 keeps the displayed band colours in the layout, which XER does not export), so these colours are NOT the colours "
                    "shown in your P6 schedule. Supply a colour map (Advanced > WBS colour map) or a PMS file with the right level colours."
                    % (cnt[FALLBACK], len(p6), ", ".join(str(x) for x in lv_fb)))
    if cnt.get(UNAVAILABLE):
        msgs.append("WBS COLORS: %d WBS rows have NO colour (no colour source and fallback colours are off)." % cnt[UNAVAILABLE])
    exact = bool(p6) and cnt.get(VERIFIED, 0) == len(p6)
    return dict(rows=len(p6), overall_source=overall, levels=levels, counts=dict(cnt), key=key, user=user, xer_info=xer_info, xer_nodes=len(xer_cols),
                warnings=msgs, infos=infos, exact_possible=exact, fallback_mode=fb_mode,
                project=short, project_id=project_id, max_level=max(levels) if levels else 0)
