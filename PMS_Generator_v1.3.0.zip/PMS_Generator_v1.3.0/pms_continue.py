# -*- coding: utf-8 -*-
"""
Continue a periodic PMS: read the previous PMS workbook, match its activities with the new XER ONLY when the
match is reliable, and hand back the manual inputs that must survive (weights, actual dates, cumulative progress,
S-curve history, report number and period).

Matching rules (nothing is ever transferred between different activities):
  exact     Activity ID + name + WBS path equal
  renamed   Activity ID + WBS path equal, name changed                -> transferred
  moved     Activity ID + name equal, WBS path changed                -> transferred
  suspect   same Activity ID but different name AND different WBS      -> NOT transferred (listed)
  ambiguous the same ID occurs several times and cannot be told apart  -> NOT transferred (listed)
  new       no such Activity ID in the previous PMS
"""
import re
from collections import defaultdict
from datetime import datetime, timedelta

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter as L

from pms_common import PmsError


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def _date(v):
    return datetime(v.year, v.month, v.day) if isinstance(v, datetime) else None


def read_previous_pms(path):
    try:
        wf = load_workbook(path)                       # formulas
        wv = load_workbook(path, data_only=True)       # cached values (present when the file was saved by Excel)
    except Exception as e:  # noqa
        raise PmsError("Cannot open the previous PMS: %s" % e)
    name = next((s.title for s in wf if (wf[s.title].cell(5, 1).value or "").strip().upper() == "VLOOKUP KEY"), None)
    if not name:
        raise PmsError("The previous PMS does not look like a PMS workbook (no sheet with 'VLOOKUP KEY' in A5).")
    f, v = wf[name], wv[name]
    out = dict(sheet=name, warnings=[], acts=[], uncached=0, title=f["B1"].value)
    out["report_no"] = _num(v["X4"].value) or _num(f["X4"].value)
    out["period_start"], out["period_finish"] = _date(v["X2"].value), _date(v["X3"].value)
    if out["period_finish"] is None and isinstance(f["X3"].value, datetime):
        out["period_finish"] = _date(f["X3"].value)
    names = {}
    last = max(r for r in range(8, f.max_row + 1) if isinstance(f.cell(r, 2).value, int) and f.cell(r, 1).value)
    for r in range(8, last + 1):
        key, lvl, yn = f.cell(r, 1).value, f.cell(r, 2).value, f.cell(r, 3).value
        if not key:
            continue
        if yn == "NO":
            names[key] = (str(f.cell(r, 4).value or "")).strip()
            continue
        parts = str(key).split(".")
        path_names = tuple(_norm(names.get(".".join(parts[:n]), "")) for n in range(2, len(parts)))
        # path of ancestors from level 2 down (level-1 'overall' row excluded)
        raw_r = v.cell(r, 18).value
        if raw_r is None and isinstance(f.cell(r, 18).value, str) and str(f.cell(r, 18).value).startswith("="):
            out["uncached"] += 1
        out["acts"].append(dict(
            row=r, id=str(f.cell(r, 4).value or "").strip(), name=str(f.cell(r, 5).value or "").strip(), path=path_names,
            G=_num(v.cell(r, 7).value) if _num(v.cell(r, 7).value) is not None else _num(f.cell(r, 7).value),
            J=_date(v.cell(r, 10).value) or _date(f.cell(r, 10).value), K=_date(v.cell(r, 11).value) or _date(f.cell(r, 11).value),
            N=_num(v.cell(r, 14).value) if _num(v.cell(r, 14).value) is not None else _num(f.cell(r, 14).value),
            R=_num(raw_r), P=_num(v.cell(r, 16).value),
            H=_date(v.cell(r, 8).value) or _date(f.cell(r, 8).value), I=_date(v.cell(r, 9).value) or _date(f.cell(r, 9).value)))
    if out["uncached"]:
        out["warnings"].append("%d cumulative-quantity cells in the previous PMS are formulas without a stored value. "
                               "Open the previous PMS in Excel, save it, and run again - their progress cannot be carried." % out["uncached"])
    # ---- S-curve history (actual cumulative per date)
    out["hist"] = {}
    sc = next((wf[s.title] for s in wf if s.title.upper().startswith("S-CURVE")), None)
    if sc is not None:
        scv = wv[sc.title]
        tc = max(c for c in range(3, sc.max_column + 1) if sc.cell(3, c).value is not None)
        d0 = _date(sc.cell(3, 3).value) or _date(scv.cell(3, 3).value)
        dates = {}
        if d0:
            m = re.match(r"^=\s*C3\s*\+\s*(\d+)\s*$", str(sc.cell(3, 4).value or ""))
            cur = d0
            for c in range(3, tc + 1):
                dv = _date(scv.cell(3, c).value)
                if dv is None:
                    if c == 3:
                        dv = d0
                    elif c == 4 and m:
                        dv = d0 + timedelta(days=int(m.group(1)))
                    else:
                        dv = cur + timedelta(days=7)
                cur = dv
                dates[c] = dv
        for c, dv in dates.items():
            a9, a11 = _num(scv.cell(9, c).value), _num(sc.cell(11, c).value)
            val = a9 if a9 is not None else a11
            if val is not None and dv <= (out["period_finish"] or dv):
                out["hist"][dv] = val
        y8 = _num(v["Y8"].value)
        if out["period_finish"] and y8 is not None:
            out["hist"][out["period_finish"]] = y8
    return out


def match_activities(model, prev):
    """Returns dict(carry{(proj,id): data}, stats, lists). Pure matching, no side effects."""
    by_id = defaultdict(list)
    for p in prev["acts"]:
        by_id[p["id"]].append(p)
    carry, lists = {}, defaultdict(list)
    used = set()
    for a in model["acts"]:
        cands = by_id.get(a["id"], [])
        npath = tuple(_norm(x) for x in a.get("path", ())[1:]) if False else None
        # the new path starts at the project root (level 2); the previous path from the WBS below the root as written in the PMS
        newp = tuple(_norm(x) for x in a.get("path", ()))
        if not cands:
            lists["new"].append(a["id"])
            continue

        def kind(p):
            nm = _norm(p["name"]) == _norm(a["name"])
            pe = p["path"] == newp
            return "exact" if nm and pe else "renamed" if pe else "moved" if nm else "suspect"
        kinds = [(kind(p), p) for p in cands]
        good = [(k, p) for k, p in kinds if k != "suspect"]
        if len(cands) == 1:
            k, p = kinds[0]
        elif len(good) == 1:
            k, p = good[0]
        else:
            ex = [(k, p) for k, p in kinds if k == "exact"]
            if len(ex) == 1:
                k, p = ex[0]
            else:
                lists["ambiguous"].append(a["id"])
                continue
        if k == "suspect":
            lists["suspect"].append("%s (was '%s', now '%s')" % (a["id"], p["name"], a["name"]))
            continue
        used.add(id(p))
        # cumulative progress as a FRACTION: R / BUG QTY (the new PMS uses BUG QTY = 100 %)
        frac = None
        if p["R"] is not None:
            if p["N"] in (None, 0):
                lists["no_bugqty"].append(a["id"])
            else:
                frac = p["R"] / p["N"]
                if frac > 1.0000001 or frac < 0:
                    lists["out_of_range"].append("%s (%.4g)" % (a["id"], frac))
                if abs((p["N"] or 1) - 1) > 1e-9:
                    lists["converted"].append(a["id"])
        carry[(a["proj"], a["id"])] = dict(kind=k, G=p["G"], J=p["J"], K=p["K"], frac=frac, prev_name=p["name"])
        if k in ("renamed", "moved"):
            lists[k].append("%s ('%s' -> '%s')" % (a["id"], p["name"], a["name"]) if k == "renamed" else "%s (WBS path changed)" % a["id"])
    removed = [p["id"] for p in prev["acts"] if id(p) not in used]
    stats = dict(total=len(model["acts"]), matched=len(carry), exact=sum(1 for c in carry.values() if c["kind"] == "exact"),
                 renamed=len(lists["renamed"]), moved=len(lists["moved"]), new=len(lists["new"]),
                 suspect=len(lists["suspect"]), ambiguous=len(lists["ambiguous"]), removed=len(removed))
    return dict(carry=carry, stats=stats, lists=dict(lists), removed=removed)
