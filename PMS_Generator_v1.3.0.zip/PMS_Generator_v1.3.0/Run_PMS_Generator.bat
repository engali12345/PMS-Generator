@echo off
rem Opens PMS GENERATOR from the Python files (needs: pip install -r requirements.txt).
rem You can also drag an .xer file onto this file.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 pms_main.py %*
) else (
  python pms_main.py %*
)
if errorlevel 1 pause
