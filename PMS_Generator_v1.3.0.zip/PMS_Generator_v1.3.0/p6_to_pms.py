#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p6_to_pms.py  -  PMS GENERATOR engine: Primavera P6 (XER) -> PMS Excel   (v1.0.0)
Developed by Eng. Ali Ahmed | IGCC

One engine for ANY project: the XER decides the WBS, activities, IDs and dates; the Excel template
(PMS_Master_Template.xlsx) is only a model for layout, styles, formulas and the S-CURVE sheet.

Modules: pms_common (branding, errors, helpers) | pms_weights (Weight Settings) | pms_continue (previous PMS)
         pms_gui (PySide6 window) | pms_main (entry point)

  Window:   python pms_main.py                    (or the .exe)
  CLI:      python pms_main.py schedule.xer --weights equal --previous PMS_old.xlsx
            python pms_main.py --inspect schedule.xer      (projects / baseline / resources found)
"""
import argparse
import copy
import os
import re
import shutil
import sys
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.formula.translate import Translator
from openpyxl.styles import Alignment, Color, Font, PatternFill
from openpyxl.utils import column_index_from_string as CI
from openpyxl.utils import get_column_letter as L

from pms_colors import (FALLBACK, UNAVAILABLE, USER, VERIFIED, font_for, parse_color, project_key, resolve_colors,
                        stored_map_path, xer_wbs_colors)
from pms_weights import METHODS, compute_weights
from pms_continue import match_activities, read_previous_pms
from pms_common import (APP_NAME, APP_VERSION, COPYRIGHT, DEVELOPER, FOOTER, PmsChooseProject, PmsError,
                        PmsExistsError, app_dir, dt, get_logger, log_path, mn, mx, natkey, num, resource_path,
                        safe_filename)

TEMPLATE_NAME = "PMS_Master_Template.xlsx"
FIRST = 8                    # first data row of the PMS sheet
WK0 = CI("AH")               # first weekly column
LASTCOL_FIX = CI("AA")       # last fixed column (signature block is copied up to here)
BL_MISSING_TEXT = "NOT AVAILABLE (no baseline in XER)"
log = get_logger()


def find_template(user_path=None):
    if user_path:
        if not os.path.isfile(user_path):
            raise PmsError(f"Template not found: {user_path}")
        return user_path
    cands = [os.path.join(app_dir(), TEMPLATE_NAME), os.path.join(os.getcwd(), TEMPLATE_NAME)]
    if getattr(sys, "frozen", False):
        cands.append(os.path.join(os.path.dirname(sys.executable), TEMPLATE_NAME))
    for c in cands:
        if os.path.isfile(c):
            return c
    raise PmsError(f"{TEMPLATE_NAME} not found next to the program. Keep it in the same folder.")


# =============================================================== XER parsing
def decode_xer(raw):
    try:
        return raw.decode("utf-8-sig"), "utf-8"
    except UnicodeDecodeError:
        pass
    t1256 = raw.decode("cp1256", errors="replace")
    hi = sum(1 for b in raw if b >= 0x80)
    ar = sum(1 for ch in t1256 if "\u0600" <= ch <= "\u06ff")
    if hi and ar / hi > 0.3:
        return t1256, "cp1256"
    return raw.decode("cp1252", errors="replace"), "cp1252"


def parse_xer(path):
    try:
        raw = open(path, "rb").read()
    except OSError as e:
        raise PmsError(f"Cannot read the XER file: {e}")
    text, enc = decode_xer(raw)
    T, cur, flds = {}, None, []
    for ln in text.splitlines():
        if ln.startswith("%T"):
            cur = ln.split("\t")[1].strip()
            T[cur] = []
            flds = []
        elif ln.startswith("%F"):
            flds = [x.strip() for x in ln.split("\t")[1:]]
        elif ln.startswith("%R") and cur is not None:
            v = ln.split("\t")[1:]
            if len(v) < len(flds):
                v += [""] * (len(flds) - len(v))
            T[cur].append(dict(zip(flds, v)))
    for need in ("PROJECT", "PROJWBS", "TASK"):
        if not T.get(need):
            raise PmsError(f"The file does not contain table {need}. Is it a Primavera P6 XER export?")
    return T, enc


# =============================================================== projects & baseline analysis
def pname(p):
    return (p.get("proj_short_name", "") or "").strip() or p["proj_id"]


def classify_projects(T):
    projs = T["PROJECT"]
    ids = {p["proj_id"] for p in projs}
    referenced = {p.get("sum_base_proj_id", "").strip() for p in projs} - {""}

    def is_baseline(p):
        return (p["proj_id"] in referenced or p.get("project_flag", "Y").strip() == "N"
                or bool(p.get("base_type_id", "").strip()))

    live = [p for p in projs if not is_baseline(p)]
    baselines = [p for p in projs if is_baseline(p)]
    return ids, live, baselines


def project_summaries(T, live):
    roots = {}
    for w in T["PROJWBS"]:
        if w.get("proj_node_flag") == "Y":
            roots.setdefault(w["proj_id"], (w.get("wbs_name", "") or "").strip())
    cnt = Counter(t["proj_id"] for t in T["TASK"])
    return [dict(id=p["proj_id"], short=pname(p), root=roots.get(p["proj_id"], ""), tasks=cnt.get(p["proj_id"], 0),
                 data_date=dt(p.get("last_recalc_date"))) for p in live]


def select_projects(T, live, choice):
    """choice: None/'' (only valid when the XER has one live project), 'all', ids or name parts."""
    summ = project_summaries(T, live)
    if choice is None or choice == "" or choice == []:
        if len(live) == 1:
            return live
        raise PmsChooseProject(summ)
    keys = choice if isinstance(choice, (list, tuple)) else str(choice).split(",")
    keys = [str(k).strip().lower() for k in keys if str(k).strip()]
    if "all" in keys:
        return live
    sel = [p for p in live if any(k == p["proj_id"].lower() or k in pname(p).lower() for k in keys)]
    if not sel:
        raise PmsError("The chosen project was not found in the XER. Projects found: " + ", ".join(
            "%s [id %s]" % (s["short"], s["id"]) for s in summ))
    return sel


BL_FIELDS = ("proj_id", "proj_short_name", "project_flag", "orig_proj_id", "base_type_id", "sum_base_proj_id",
             "last_baseline_update_date", "baselines_to_export", "baseline_names_to_export", "use_project_baseline_flag")


def analyze_baselines(T, live, baselines, ids, choice=""):
    """Decide, from the PROJECT table, which baseline project (if any) belongs to each live project.
    States: FOUND | NOT_IN_FILE | PARTIAL | NOT_EXPORTED  (activity matching refines FOUND later)."""
    bt = {b.get("base_type_id", ""): (b.get("base_type", "") or "").strip() for b in T.get("BASETYPE", [])}
    byid = {p["proj_id"]: p for p in T["PROJECT"]}
    choice = (choice or "").strip().lower()
    bl_of, per, lines = {}, [], []
    lines.append("PROJECT rows in the file: %d (live: %d, baseline-type: %d)." % (len(T["PROJECT"]), len(live), len(baselines)))
    if baselines:
        lines.append("Baseline-type projects: " + "; ".join("%s [id %s%s]" % (
            pname(b), b["proj_id"], (", type '%s'" % bt[b["base_type_id"]]) if bt.get(b.get("base_type_id", "")) else "")
            for b in baselines))
    for p in live:
        pid = p["proj_id"]
        link = p.get("sum_base_proj_id", "").strip()
        cands = {b["proj_id"]: b for b in baselines if b.get("orig_proj_id", "").strip() == pid}
        if link and link in byid and link != pid:
            cands.setdefault(link, byid[link])
        chosen, how = None, ""
        pool = list(cands.values()) or baselines
        if choice:
            sel = [b for b in pool if choice == b["proj_id"].lower()
                   or choice in (pname(b) + " " + bt.get(b.get("base_type_id", ""), "")).lower()]
            if len(sel) == 1:
                chosen, how = sel[0], "selected by the user"
        if chosen is None and link and link in byid and link != pid:
            chosen, how = byid[link], "assigned in P6 as the project baseline (sum_base_proj_id)"
        if chosen is None and len(cands) == 1:
            chosen, how = next(iter(cands.values())), "the only baseline copy of this project (orig_proj_id)"
        if chosen is not None:
            state, why = "FOUND", "baseline project '%s' [id %s] %s." % (pname(chosen), chosen["proj_id"], how)
            bl_of[pid] = chosen
        elif len(cands) > 1:
            state, why = "PARTIAL", ("%d baseline copies of this project exist (%s) and none is assigned as the project "
                                     "baseline - choose one in Advanced settings." % (len(cands), ", ".join(pname(c) for c in cands.values())))
        elif baselines:
            state, why = "PARTIAL", ("the file contains baseline project(s) (%s) but none can be linked to this project "
                                     "reliably." % ", ".join(pname(b) for b in baselines))
        else:
            hints = []
            if link:
                hints.append("the project points to baseline id %s (sum_base_proj_id) but that baseline is not in the file" % link)
            for f in ("baselines_to_export", "baseline_names_to_export", "last_baseline_update_date"):
                if (p.get(f) or "").strip():
                    hints.append("%s = '%s'" % (f, p[f].strip()))
            if hints:
                state, why = "NOT_EXPORTED", "P6 shows signs of a baseline but it was NOT included in the exported file: " + "; ".join(hints) + "."
            else:
                state, why = "NOT_IN_FILE", "no baseline project, no baseline link (sum_base_proj_id) and no baseline hints in the PROJECT table."
        per.append(dict(id=pid, name=pname(p), state=state, why=why, baseline=chosen))
        lines.append("[%s] %s: %s" % (state, pname(p), why))
        lines.append("   fields: " + ", ".join("%s=%r" % (f, (p.get(f) or "").strip()) for f in BL_FIELDS if f in p))
    states = [x["state"] for x in per]
    if all(s == "FOUND" for s in states):
        overall = "FOUND"
    elif any(s == "FOUND" for s in states):
        overall = "PARTIAL"
    elif "NOT_EXPORTED" in states:
        overall = "NOT_EXPORTED"
    elif "PARTIAL" in states:
        overall = "PARTIAL"
    else:
        overall = "NOT_IN_FILE"
    return bl_of, dict(state=overall, per=per, lines=lines)


def bl_task_dates(t):
    """P6 'Start' / 'Finish' of an activity (actual if started/finished, else early/planned)."""
    s = dt(t.get("act_start_date")) or dt(t.get("early_start_date")) or dt(t.get("restart_date")) or dt(t.get("target_start_date"))
    f = dt(t.get("act_end_date")) or dt(t.get("early_end_date")) or dt(t.get("reend_date")) or dt(t.get("target_end_date"))
    return s, f


def resource_summary(T, live_ids):
    tr = [r for r in T.get("TASKRSRC", []) if r.get("proj_id") in live_ids]
    rs = {r["rsrc_id"]: r for r in T.get("RSRC", [])}
    types = Counter((rs.get(r.get("rsrc_id"), {}).get("rsrc_type") or "?") for r in tr)
    return dict(taskrsrc=len(tr), rsrc=len(T.get("RSRC", [])), projcost=len([c for c in T.get("PROJCOST", []) if c.get("proj_id") in live_ids]),
                types=dict(types), cost=sum(num(r.get("target_cost")) for r in tr))


def inspect_xer(path):
    """Light-weight look at an XER (used by the GUI before generating)."""
    T, enc = parse_xer(path)
    ids, live, baselines = classify_projects(T)
    bl_of, diag = analyze_baselines(T, live, baselines, ids)
    first = open(path, "rb").readline().decode("cp1252", errors="replace").strip().split("\t")
    wbs_ids = {w["wbs_id"] for w in T["PROJWBS"] if w["proj_id"] in {p["proj_id"] for p in live}}
    xc, xinfo = xer_wbs_colors(T, wbs_ids)
    stored = stored_map_path(pname(live[0]), live[0].get("proj_id")) if live else None
    # Hierarchy depth comes from the XER's parent-child links, never spreadsheet row positions.
    selected_ids = {p["proj_id"] for p in live}
    wbs_rows = [w for w in T.get("PROJWBS", []) if w.get("proj_id") in selected_ids]
    by_id = {w.get("wbs_id"): w for w in wbs_rows}
    level_by_id = {}
    def _depth(wid, trail=None):
        if wid in level_by_id:
            return level_by_id[wid]
        trail = set() if trail is None else trail
        if wid in trail or wid not in by_id:
            return 1
        trail.add(wid)
        parent = by_id[wid].get("parent_wbs_id")
        # PMS reserves level 1 for its synthetic overall row, so the P6 project/root WBS starts at level 2.
        level = 2 if not parent or parent not in by_id else _depth(parent, trail) + 1
        trail.discard(wid)
        level_by_id[wid] = level
        return level
    for _wid in by_id:
        _depth(_wid)
    csum = ("%d of %d WBS nodes have a colour in the XER" % (len(xc), len(wbs_ids))) if xc else (
        "saved colour map found for this project" if stored else "no colour data in the XER (fallback palette will be used and reported)")
    return dict(path=path, size=os.path.getsize(path), encoding=enc, header=first, projects=project_summaries(T, live),
                baselines=[dict(id=b["proj_id"], name=pname(b), orig=b.get("orig_proj_id", "")) for b in baselines],
                baseline_state=diag["state"], baseline_lines=diag["lines"],
                resources=resource_summary(T, {p["proj_id"] for p in live}), tasks=len(T["TASK"]),
                colors=dict(xer_nodes=len(xc), xer_info=xinfo, stored=stored, summary=csum,
                            kind="xer" if xc else ("stored" if stored else "none")),
                wbs_levels=sorted(set(level_by_id.values())), wbs_rows=len(wbs_rows),
                project_ids=[dict(id=p.get("proj_id"), short=p.get("short"), root=p.get("root")) for p in project_summaries(T, live)])


# =============================================================== model (everything comes from the XER)
def build_model(T, opts):
    W, INFO = [], []
    ids, live_all, baselines = classify_projects(T)
    if not live_all:
        raise PmsError("The XER contains only baseline projects, no live project.")
    live = select_projects(T, live_all, opts.get("projects"))
    pids = {p["proj_id"] for p in live}
    if len(live) > 1:
        INFO.append("Several projects were imported into one PMS: %s" % ", ".join(pname(p) for p in live))

    bl_of, bdiag = analyze_baselines(T, live, baselines, ids, opts.get("baseline", ""))
    bl_index = defaultdict(list)
    if bl_of:
        wanted = {b["proj_id"] for b in bl_of.values()}
        for t in T["TASK"]:
            if t["proj_id"] in wanted:
                s_, f_ = bl_task_dates(t)
                bl_index[(t["proj_id"], t.get("task_code", "").strip())].append((s_, f_, t.get("task_id", "")))

    # ---- WBS tree
    wbs = {w["wbs_id"]: w for w in T["PROJWBS"] if w["proj_id"] in pids}
    order = {p["proj_id"]: i for i, p in enumerate(live)}
    roots = sorted([w for w in wbs.values() if w.get("proj_node_flag") == "Y"], key=lambda w: order.get(w["proj_id"], 0))
    if not roots:
        raise PmsError("No root WBS node (project node) was found in the XER.")
    kids = defaultdict(list)
    for w in wbs.values():
        if w.get("proj_node_flag") != "Y":
            kids[w.get("parent_wbs_id", "")].append(w)
    for k in kids:
        kids[k].sort(key=lambda w: int(num(w.get("seq_num"), 0)))
    cal = {c["clndr_id"]: c.get("clndr_name", "") for c in T.get("CALENDAR", [])}
    planned_source = opts.get("planned_source") or "auto"

    # ---- tasks
    tasks = defaultdict(list)
    n_tasks = 0
    type_count = Counter()
    for t in T["TASK"]:
        if t["proj_id"] not in pids:
            continue
        n_tasks += 1
        typ = t.get("task_type", "")
        type_count[typ] += 1
        code = t.get("task_code", "").strip()
        a = dict(id=code, name=t.get("task_name", "").strip(), wbs=t.get("wbs_id", ""), type=typ, proj=t["proj_id"],
                 task_id=t.get("task_id", ""), dur_hr=num(t.get("target_drtn_hr_cnt")),
                 es=dt(t.get("early_start_date")) or dt(t.get("restart_date")),
                 ef=dt(t.get("early_end_date")) or dt(t.get("reend_date")),
                 as_=dt(t.get("act_start_date")), af=dt(t.get("act_end_date")),
                 dur=num(t.get("target_drtn_hr_cnt")) / 8.0, cal=cal.get(t.get("clndr_id"), ""),
                 status=t.get("status_code", ""), p6pct=None, bl=None, bl_s=None, bl_f=None, bl_task_id=None)
        cur_s, cur_f = dt(t.get("target_start_date")), dt(t.get("target_end_date"))
        a["ps"], a["pf"] = cur_s, cur_f
        if t["proj_id"] in bl_of:
            ent = bl_index.get((bl_of[t["proj_id"]]["proj_id"], code), [])
            if len(ent) == 1 and (ent[0][0] or ent[0][1]):
                a["bl"], a["bl_s"], a["bl_f"], a["bl_task_id"] = True, ent[0][0], ent[0][1], ent[0][2]
                if planned_source == "auto":
                    a["ps"], a["pf"] = a["bl_s"], a["bl_f"]
            else:
                a["bl"] = False
                a["bl_ambiguous"] = len(ent) > 1
        a["cur_s"], a["cur_f"] = cur_s, cur_f
        if typ == "TT_Mile":
            a["pf"] = None
            a["bl_f"] = None
        elif typ == "TT_FinMile":
            a["ps"] = None
            a["bl_s"] = None
        # Performance % complete (raw P6 value, shown only in the hidden RAW DATA sheet)
        if a["status"] == "TK_Complete":
            p = 1.0
        elif a["status"] == "TK_NotStart":
            p = 0.0
        else:
            pt = t.get("complete_pct_type")
            if pt == "CP_Phys":
                p = num(t.get("phys_complete_pct")) / 100.0
            elif pt == "CP_Units":
                tw = num(t.get("target_work_qty")) + num(t.get("target_equip_qty"))
                rw = num(t.get("remain_work_qty")) + num(t.get("remain_equip_qty"))
                p = max(0.0, 1 - rw / tw) if tw > 0 else 0.0
            else:
                od, rd = num(t.get("target_drtn_hr_cnt")), num(t.get("remain_drtn_hr_cnt"))
                p = max(0.0, min(1.0, 1 - rd / od)) if od > 0 else 0.0
        a["p6pct"] = round(min(1.0, max(0.0, p)), 6)
        tasks[a["wbs"]].append(a)
    for k in tasks:
        tasks[k].sort(key=lambda a: natkey(a["id"]))      # P6 shows activities ordered by Activity ID inside a WBS node

    # ---- rows (same order as P6: activities by ID, then child WBS by seq_num)
    def has_acts(w):
        wid = w["wbs_id"]
        return bool(tasks.get(wid)) or any(has_acts(c) for c in kids.get(wid, []))

    rows, empty_wbs = [], []
    include_empty = bool(opts.get("include_empty_wbs"))

    def walk(w, level, key, path):
        nm = w.get("wbs_name", "").strip()
        path = path + [nm]
        rows.append({"kind": "sum", "level": level, "key": key, "name": nm, "wbs": w})
        idx = 0
        for a in tasks.get(w["wbs_id"], []):
            idx += 1
            if idx > 999:
                raise PmsError("More than 999 items under one WBS node (%s) - the 3-digit key limit is exceeded." % nm)
            a["path"] = tuple(path)
            rows.append({"kind": "act", "level": level + 1, "key": "%s.%03d" % (key, idx), "a": a})
        for c in kids.get(w["wbs_id"], []):
            if include_empty or has_acts(c):
                idx += 1
                if idx > 999:
                    raise PmsError("More than 999 items under one WBS node (%s)." % nm)
                walk(c, level + 1, "%s.%03d" % (key, idx), path)
            else:
                empty_wbs.append(c.get("wbs_name", "").strip())

    rows.append({"kind": "sum", "level": 1, "key": "001", "name": "__overall__"})
    for n, rt in enumerate(roots, 1):
        walk(rt, 2, "001.%03d" % n, [])

    acts_in_rows = [r["a"] for r in rows if r["kind"] == "act"]
    if not acts_in_rows:
        raise PmsError("No activities were found under the selected project(s).")

    desc = defaultdict(list)
    for r in rows:
        if r["kind"] == "act":
            parts = r["key"].split(".")
            for n in range(1, len(parts)):
                desc[".".join(parts[:n])].append(r["a"])

    p0, root0 = live[0], roots[0]
    short = pname(p0)
    title = (root0.get("wbs_name", "") or short).strip()
    dds = [dt(p.get("last_recalc_date")) for p in live if dt(p.get("last_recalc_date"))]

    # ---- baseline: refine with activity matching, project-level BL dates, messages
    per = bdiag["per"]
    for x in per:
        mine = [a for a in acts_in_rows if a["proj"] == x["id"]]
        x["total"], x["matched"] = len(mine), sum(1 for a in mine if a["bl"] is True)
        if x["state"] == "FOUND":
            if x["matched"] == 0:
                x["state"] = "PARTIAL"
                x["why"] += " BUT none of its activities could be matched by Activity ID."
            elif x["matched"] < x["total"]:
                x["state"] = "PARTIAL"
                x["why"] += " Only %d of %d activities exist in the baseline (matched by Activity ID)." % (x["matched"], x["total"])
    states = [x["state"] for x in per]
    bstate = ("FOUND" if all(s == "FOUND" for s in states) else "PARTIAL" if any(s in ("FOUND", "PARTIAL") for s in states)
              and not all(s in ("NOT_IN_FILE", "NOT_EXPORTED") for s in states) else bdiag["state"])
    if all(s == "NOT_EXPORTED" for s in states):
        bstate = "NOT_EXPORTED"
    elif all(s == "NOT_IN_FILE" for s in states):
        bstate = "NOT_IN_FILE"
    bl_start = bl_finish = None
    bl_src = ""
    if bl_of:
        ps_ = [dt(b.get("plan_start_date")) for b in bl_of.values()]
        pf_ = [dt(b.get("scd_end_date")) for b in bl_of.values()]
        if all(ps_) and all(pf_):
            bl_start, bl_finish, bl_src = min(ps_), max(pf_), "baseline project's planned start / scheduled finish"
        else:
            m_ = [a for a in acts_in_rows if a["bl"] is True]
            bl_start = mn([a["bl_s"] or a["bl_f"] for a in m_])
            bl_finish = mx([a["bl_f"] or a["bl_s"] for a in m_])
            bl_src = "derived from the baseline activities (project dates missing in the baseline row)"
        if bstate == "PARTIAL" and not any(a["bl"] for a in acts_in_rows):
            bl_start = bl_finish = None
            bl_src = ""
    for x in per:
        if x["state"] == "PARTIAL" and x.get("matched", 0) > 0:
            miss = [a["id"] for a in acts_in_rows if a["proj"] == x["id"] and a["bl"] is False]
            W.append("Baseline PARTIAL for %s: %d activities are not in the baseline - their CURRENT planned dates were used "
                     "(first IDs: %s)." % (x["name"], len(miss), ", ".join(miss[:8])))
    msgs = {
        "NOT_IN_FILE": "NO BASELINE in the XER (no baseline project and no baseline hints). PLANNED START/FINISH use the CURRENT planned "
                       "dates and must NOT be treated as a confirmed baseline. BL PROJECT START/FINISH are 'not available'.",
        "NOT_EXPORTED": "A baseline seems to exist in P6 but it was NOT exported with this XER. PLANNED dates use the CURRENT planned dates "
                        "(not a confirmed baseline); BL PROJECT START/FINISH are 'not available'. Re-export the XER including the "
                        "baseline (see README, section Baseline).",
        "PARTIAL": "Baseline data is partial or could not be linked reliably - see the Baseline diagnostics section.",
    }
    if bstate in msgs and not (bstate == "PARTIAL" and any(x.get("matched", 0) > 0 for x in per)):
        W.append(msgs[bstate])      # (a PARTIAL baseline with matched activities already got its specific warning above)

    baseline = dict(state=bstate, per=per, lines=bdiag["lines"], bl_start=bl_start, bl_finish=bl_finish, src=bl_src,
                    planned_source=planned_source)
    return dict(rows=rows, desc=desc, roots=roots, live=live, short=short, title=title,
                data_date=max(dds) if dds else None, warnings=W, infos=INFO, n_tasks=n_tasks,
                type_count=type_count, empty_wbs=empty_wbs, include_empty=include_empty,
                n_wbs_total=sum(1 for w in wbs.values() if w.get("proj_node_flag") != "Y"),
                has_baseline=bool(bl_of) and bstate in ("FOUND", "PARTIAL") and bl_start is not None,
                bl_start=bl_start, bl_finish=bl_finish, baseline=baseline,
                acts=acts_in_rows, root_name=root0.get("wbs_name", ""))


# =============================================================== template handling
def clear_cell(c):
    c.value = None
    c.style = "Normal"


def inspect_template(ws):
    if (ws.cell(5, 1).value or "").strip().upper() != "VLOOKUP KEY" or (ws.cell(5, 27).value or "").strip().upper() != "FILTER FOR PROG.":
        raise PmsError("The template layout is not the expected PMS layout (header row 5).")
    tlast = max(r for r in range(FIRST, ws.max_row + 1)
                if isinstance(ws.cell(r, 2).value, int) and ws.cell(r, 1).value)
    ncol = max(c for c in range(WK0, ws.max_column + 1) if ws.cell(7, c).value is not None)
    # one style example per (level, is-activity)
    ex = {}
    for r in range(FIRST, tlast + 1):
        ex.setdefault((ws.cell(r, 2).value, ws.cell(r, 3).value), r)
    styles = {k: [copy.copy(ws.cell(r, c)._style) for c in range(1, ncol + 1)] for k, r in ex.items()}
    # formula samples
    sum_row = next((r for r in range(FIRST + 1, tlast + 1) if ws.cell(r, 3).value == "NO"), None)
    act_row = next((r for r in range(FIRST, tlast + 1) if ws.cell(r, 3).value == "YES"
                    and isinstance(ws.cell(r, 19).value, str) and "HLOOKUP" in ws.cell(r, 19).value
                    and isinstance(ws.cell(r, WK0).value, str)), None)
    if sum_row is None or act_row is None:
        raise PmsError("The template must contain at least one summary row and one activity row with formulas.")
    fsum = {c: ws.cell(sum_row, c).value for c in range(1, ncol + 1)
            if isinstance(ws.cell(sum_row, c).value, str) and ws.cell(sum_row, c).value.startswith("=")}
    fact = {c: ws.cell(act_row, c).value for c in range(1, ncol + 1)
            if isinstance(ws.cell(act_row, c).value, str) and ws.cell(act_row, c).value.startswith("=")}
    return dict(tlast=tlast, ncol=ncol, styles=styles, sum_row=sum_row, act_row=act_row, fsum=fsum, fact=fact,
                ae_first=ws.cell(FIRST, 31).value)


def style_for(styles, level, is_act):
    key = (level, "YES" if is_act else "NO")
    if key in styles:
        return styles[key]
    if is_act:
        ks = [k for k in styles if k[1] == "YES"]
        return styles[max(ks)] if ks else styles[min(styles)]
    ks = [k for k in styles if k[1] == "NO" and isinstance(k[0], int) and k[0] <= level]
    return styles[max(ks)] if ks else styles[min(styles)]


def tr(f, src_row, c, dst_row):
    return Translator(f, origin=f"{L(c)}{src_row}").translate_formula(f"{L(c)}{dst_row}")


def restore_chart(tpl, out, old_last, new_last):
    """Put back the template's original S-CURVE chart XML (colours, styles) with the new range."""
    with zipfile.ZipFile(tpl) as z:
        names = sorted(n for n in z.namelist() if n.startswith("xl/charts/chart") and n.endswith(".xml"))
        if not names:
            return
        orig = z.read(names[0]).decode("utf8")
    orig = re.sub(r"\$%s\$(\d+)" % re.escape(old_last), lambda m: "$%s$%s" % (new_last, m.group(1)), orig)
    orig = re.sub(r"<c:numCache>.*?</c:numCache>", "", orig, flags=re.S)
    orig = re.sub(r"<c:strCache>.*?</c:strCache>", "", orig, flags=re.S)
    tmp = out + ".tmp"
    done = False
    with zipfile.ZipFile(out) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if (not done and item.filename.startswith("xl/charts/chart") and item.filename.endswith(".xml")):
                data = orig.encode("utf8")
                done = True
            zout.writestr(item, data)
    shutil.move(tmp, out)


# =============================================================== workbook writer
def write_pms(model, tpl_path, out, opts):
    wb = load_workbook(tpl_path)
    ws = next((s for s in wb if "PMS" in s.title.upper()), None)
    if ws is None:
        raise PmsError("No PMS sheet found in the template.")
    old_title = ws.title
    sc = next((s for s in wb if s.title.upper().startswith("S-CURVE")), None)
    raw = next((s for s in wb if s.title.upper().startswith("RAW")), None)
    tinfo = inspect_template(ws)
    ncol, styles = tinfo["ncol"], tinfo["styles"]
    tlast = tinfo["tlast"]

    # --- keep what is needed from the template before clearing
    sig_start, sig_end = tlast + 2, ws.max_row
    sig = [(r - sig_start, c, ws.cell(r, c).value, copy.copy(ws.cell(r, c)._style))
           for r in range(sig_start, sig_end + 1) for c in range(1, LASTCOL_FIX + 1)]
    sig_heights = {r - sig_start: ws.row_dimensions[r].height for r in range(sig_start, sig_end + 1)}
    sig_merges = [(m.min_row - sig_start, m.min_col, m.max_row - sig_start, m.max_col)
                  for m in ws.merged_cells.ranges if m.min_row >= sig_start]
    had_print_area = bool(ws.print_area)
    tpl_cfg = dict(company=ws["B2"].value, contractor=ws["B3"].value, overall=ws.cell(FIRST, 4).value, b1=ws["B1"].value)

    # --- clear the data area
    for m in list(ws.merged_cells.ranges):
        if m.min_row >= FIRST:
            ws.unmerge_cells(str(m))
    for r in range(FIRST, sig_end + 5):
        ws.row_dimensions[r].height = None
        ws.row_dimensions[r].outlineLevel = 0
        for c in range(1, max(ncol, LASTCOL_FIX) + 1):
            clear_cell(ws.cell(r, c))

    rows, desc = model["rows"], model["desc"]
    for i, rw in enumerate(rows):
        rw["row"] = FIRST + i
    last = FIRST + len(rows) - 1

    all_acts = desc["001"]
    wk_start = mn([a["ps"] or a["pf"] for a in all_acts])
    wk_end = mx([a["pf"] or a["ps"] for a in all_acts])
    warnings_extra = []
    if not wk_start or not wk_end:
        wk_start = wk_end = model["data_date"] or datetime.now()
        warnings_extra.append("No planned dates in any activity - weekly columns could not be sized from the plan.")
    nweeks = int(((wk_end - wk_start).days + 6) // 7) + 1
    lastw = WK0 + nweeks - 1
    wl = L(lastw)
    pmsname = opts.get("sheet_name") or "PMS"
    ws.title = pmsname
    pmsq = "'" + pmsname + "'"

    # --- header text (project data comes from the XER)
    title_txt = opts.get("title") or model["title"]
    tpl_b1 = ws["B1"].value
    ws["B1"] = title_txt
    ws["B4"] = "%s: %s" % (model["short"], title_txt)
    if opts.get("company"):
        ws["B2"] = opts["company"]
    if opts.get("contractor"):
        ws["B3"] = opts["contractor"]
    overall_label = opts.get("overall_label") or ("%s-Overall Progress" % model["short"])

    fsum, fact, sum_row, act_row = tinfo["fsum"], tinfo["fact"], tinfo["sum_row"], tinfo["act_row"]
    wvals = (model.get("weights") or {}).get("values") or {}
    carry = (model.get("cont") or {}).get("carry") or {}
    prev = model.get("prev")
    hl_pat = re.compile(r"\$AH\$7:\$[A-Z]{1,3}\$\d+")

    def put(r, c, f, src_row):
        ws.cell(r, c, tr(f, src_row, c, r))

    paint_cache = {}

    def paint(r, sty, hexv):
        """Structure (borders, number formats, bold) from the template level style; the FILL and the font colour from the
        colour plan. Only cells that carry a fill in the template style are filled. Result is cached per (style, colour)."""
        ck = (id(sty), hexv)
        if ck not in paint_cache:
            for c in range(1, ncol + 1):
                cell = ws.cell(r, c)
                cell._style = copy.copy(sty[c - 1])
                if cell.fill.fill_type:
                    fo = copy.copy(cell.font)
                    if hexv:
                        cell.fill = PatternFill("solid", fgColor="FF" + hexv)
                        fo.color = Color(rgb="FF" + font_for(hexv))
                    else:
                        cell.fill = PatternFill(fill_type=None)
                        fo.color = Color(rgb="FF000000")
                    cell.font = fo
            paint_cache[ck] = [copy.copy(ws.cell(r, c)._style) for c in range(1, ncol + 1)]
        else:
            for c in range(1, ncol + 1):
                ws.cell(r, c)._style = copy.copy(paint_cache[ck][c - 1])
        return paint_cache[ck]

    for rw in rows:
        r = rw["row"]
        sty = style_for(styles, rw["level"], rw["kind"] == "act")
        if rw["kind"] == "sum":
            sty = paint(r, sty, rw["color"][0] if rw.get("color") else None)
        else:
            for c in range(1, ncol + 1):
                ws.cell(r, c)._style = copy.copy(sty[c - 1])
        ws.row_dimensions[r].height = 15
        ws.row_dimensions[r].outlineLevel = max(0, min(7, rw["level"] - 2))
        ws.cell(r, 1, rw["key"])
        ws.cell(r, 2, rw["level"])
        ws.cell(r, 3, "YES" if rw["kind"] == "act" else "NO")
        if rw["kind"] == "sum":
            for c, f in fsum.items():
                if c >= WK0:
                    continue
                put(r, c, f, sum_row)
            if rw["level"] == 1:
                ws.cell(r, 4, overall_label)
            else:
                ws.cell(r, 4, "  " * (rw["level"] - 2) + rw["name"])
            acts = desc[rw["key"]]
            ws.cell(r, 8, mn([a["ps"] or a["pf"] for a in acts])); ws.cell(r, 9, mx([a["pf"] or a["ps"] for a in acts]))
            ws.cell(r, 12, mn([a["ps"] or a["pf"] for a in acts])); ws.cell(r, 13, mx([a["pf"] or a["ps"] for a in acts]))
        else:
            a = rw["a"]
            for c, f in fact.items():
                if c >= WK0:
                    continue
                put(r, c, f, act_row)
            ws.cell(r, 4, a["id"]); ws.cell(r, 5, a["name"])
            ws.cell(r, 8, a["ps"]); ws.cell(r, 9, a["pf"])           # PLANNED (baseline if available)
            ws.cell(r, 12, a["ps"]); ws.cell(r, 13, a["pf"])         # FORECAST starts equal to planned
            ws.cell(r, 14, 1); ws.cell(r, 15, "%")                    # BUG QTY = 100 %, UOM = %
            # G (weight), J/K (actual dates), P/R (actual quantities) stay EMPTY unless one of these applies:
            #   - an automatic Weight method was chosen (G only)  - a previous PMS was supplied and the activity matched reliably
            ak = (a["proj"], a["id"])
            cd = carry.get(ak)
            if wvals:
                if wvals.get(ak) is not None:
                    ws.cell(r, 7, wvals[ak])
            elif cd and cd["G"] is not None:
                ws.cell(r, 7, cd["G"])
            if cd:
                if cd["J"]:
                    ws.cell(r, 10, cd["J"])
                if cd["K"]:
                    ws.cell(r, 11, cd["K"])
                if cd["frac"] is not None:
                    ws.cell(r, 16, cd["frac"]); ws.cell(r, 18, cd["frac"])   # previous cumulative -> PREV. PERIOD and CUM. start equal
            if 19 in fact:
                ws.cell(r, 19, hl_pat.sub("$AH$7:$%s$%d" % (wl, last), ws.cell(r, 19).value))
            if WK0 in fact:
                base = tr(fact[WK0], act_row, WK0, r)
                for c in range(WK0, lastw + 1):
                    ws.cell(r, c, base.replace("AH$7", "%s$7" % L(c)))
        ws.cell(r, 31, tinfo["ae_first"] if r == FIRST else "=AE%d+1" % (r - 1))
        # F = G / total  -> guarded, otherwise every row shows #DIV/0! while weights are still empty
        fcell = ws.cell(r, 6).value
        if isinstance(fcell, str) and fcell.startswith("=") and "IFERROR" not in fcell.upper():
            ws.cell(r, 6, "=IFERROR(%s,0)" % fcell[1:])
        for c in range(WK0, lastw + 1):
            ws.cell(r, c)._style = copy.copy(sty[min(c, ncol) - 1])

    # --- weekly header rows 5-7
    for c in range(WK0, max(lastw, ncol) + 1):
        if c > lastw:
            for r in range(1, 8):
                clear_cell(ws.cell(r, c))
            continue
        cl = L(c)
        for r in (5, 6, 7):
            ws.cell(r, c)._style = copy.copy(ws.cell(r, min(c, ncol))._style)
        ws.cell(6, c, "=SUM(%s%d:%s%d)" % (cl, FIRST, cl, last))
        ws.cell(7, c, "=H%d" % FIRST if c == WK0 else "=%s7+7" % L(c - 1))
    for k, d in list(ws.column_dimensions.items()):
        if d.min and d.min >= WK0:
            d.max = lastw

    # --- signature block (moved below the last row)
    base = last + 2
    for dr, c, v, stl in sig:
        cell = ws.cell(base + dr, c)
        cell.value = v
        cell._style = copy.copy(stl)
    for dr, h in sig_heights.items():
        ws.row_dimensions[base + dr].height = h
    for (r1, c1, r2, c2) in sig_merges:
        ws.merge_cells(start_row=base + r1, start_column=c1, end_row=base + r2, end_column=c2)
    if had_print_area:
        ws.print_area = "B1:Z%d" % (base + 13)
    if ws.auto_filter and ws.auto_filter.ref:
        ws.auto_filter.ref = "A7:AA%d" % last

    # --- reporting period
    fin = opts.get("period_finish") or model["data_date"]
    if fin is None:
        fin = datetime.now()
        warnings_extra.append("No Data Date in the XER - today's date was used as PERIOD FINISH DATE. Please check.")
    fin = datetime(fin.year, fin.month, fin.day)
    if opts.get("period_start"):
        st = opts["period_start"]
    elif prev and prev.get("period_finish"):
        st = prev["period_finish"] + timedelta(days=1)
    else:
        st = fin - timedelta(days=5)
    if prev and prev.get("period_finish") and fin <= prev["period_finish"]:
        warnings_extra.append("The new PERIOD FINISH (%s) is not later than the previous report's (%s)." % (
            fin.strftime("%d-%b-%Y"), prev["period_finish"].strftime("%d-%b-%Y")))
    if opts.get("report_no") is not None:
        report_no = opts["report_no"]
    elif prev and prev.get("report_no"):
        report_no = int(prev["report_no"]) + 1
    else:
        report_no = 1
    ws["X2"], ws["X3"], ws["X4"] = st, fin, report_no
    gtxt = "Weight source: %s." % (model.get("weights") or {}).get("label", "none") if wvals else \
        "Weights are EMPTY (or carried from the previous PMS): BUDGETED UNIT is a manual input."
    ws["G5"].comment = Comment(gtxt + "\nColumn F = G / total, so G only needs relative values.", "PMS Generator", width=300, height=90)

    # ================= S-CURVE
    last_sc_old = last_sc_new = None
    if sc is not None:
        tc = max(c for c in range(3, sc.max_column + 1) if sc.cell(3, c).value is not None)
        tsty = {r: [copy.copy(sc.cell(r, c)._style) for c in range(1, tc + 1)] for r in range(1, 12)}
        f5, f7, f9 = sc["C5"].value, sc["C7"].value, sc["C9"].value
        note = sc["B12"].value
        s0 = wk_start
        hist = (prev or {}).get("hist", {})
        k = ((fin.weekday() - s0.weekday()) % 7) + 7
        dates, d = [s0], s0 + timedelta(days=k)
        while True:
            dates.append(d)
            if d >= wk_end:
                break
            d += timedelta(days=7)
        lastc = 2 + len(dates)

        def sub_pms(f):
            return f.replace("'%s'" % old_title, pmsq)

        for c in range(3, max(lastc, tc) + 1):
            if c > lastc:
                for r in range(3, 12):
                    clear_cell(sc.cell(r, c))
                continue
            cl = L(c)
            for r in range(3, 12):
                sc.cell(r, c)._style = copy.copy(tsty[r][min(c, tc) - 1])
            sc.cell(3, c, dates[0] if c == 3 else (("=C3+%d" % k) if c == 4 else "=%s3+7" % L(c - 1)))
            sc.cell(4, c, "=C5" if c == 3 else "=%s5-%s5" % (cl, L(c - 1)))
            sc.cell(5, c, sub_pms(f5).replace("C$3", "%s$3" % cl).replace("$296", "$%d" % last))
            sc.cell(6, c, "=C7" if c == 3 else "=%s7-%s7" % (cl, L(c - 1)))
            sc.cell(7, c, sub_pms(f7).replace("C$3", "%s$3" % cl).replace("$296", "$%d" % last))
            sc.cell(8, c, ("=IF(ISNA(%s9),NA(),%s9)" % (cl, cl)) if c == 3
                    else "=IF(ISNA(%s9),NA(),%s9-%s9)" % (cl, cl, L(c - 1)))
            sc.cell(9, c, sub_pms(f9).replace("C$3", "%s$3" % cl).replace("C$11", "%s$11" % cl))
            # actual history for weeks before the report date: nothing is known -> 0 (enter manually later)
            dc = dates[c - 3]
            if dc < fin:
                if dc in hist:
                    sc.cell(11, c, hist[dc])
                elif hist and dc > min(hist):
                    sc.cell(11, c, "=NA()")          # no stored value for this past week: leave a gap, do not invent
                else:
                    sc.cell(11, c, 0)
            else:
                sc.cell(11, c, None)
        # BL PROJECT START / FINISH (only from real baseline data)
        lab, val = tsty[3][1], tsty[3][2]
        bl = model["baseline"]
        why_na = {"NOT_IN_FILE": "NOT AVAILABLE (no baseline in XER)", "NOT_EXPORTED": "NOT AVAILABLE (baseline not exported)",
                  "PARTIAL": "NOT AVAILABLE (baseline not linkable)", "FOUND": "NOT AVAILABLE"}.get(bl["state"], "NOT AVAILABLE")
        for rr, txt, v in ((1, "BL PROJECT START", bl["bl_start"]), (2, "BL PROJECT FINISH", bl["bl_finish"])):
            sc.cell(rr, 2, txt)._style = copy.copy(lab)
            cc = sc.cell(rr, 3, v if v else why_na)
            cc._style = copy.copy(val)
            if not v:
                cc.alignment = Alignment(horizontal="left")
        wstate = model.get("weights_state", "empty")
        if wstate != "full":
            sc["E1"] = ("WEIGHTS EMPTY: weighted progress is NOT valid until BUDGETED UNIT (column G) is entered." if wstate == "empty"
                        else "WEIGHTS INCOMPLETE: activities without data are excluded from the weighted progress.")
            sc["E1"].font = Font(name="Calibri", size=11, bold=True, color="FFC00000")
        if isinstance(note, str):
            note = note.replace(old_title, pmsname)
            note = re.sub(r"Row 11 = .*$", "Row 11 = actual cumulative history for weeks before the report date "
                          "(blue inputs, enter manually; a new PMS starts with 0).", note, flags=re.S)
            sc["B12"] = note
        wref = sc.column_dimensions[L(tc)].width or 13.14
        for c in range(tc + 1, lastc + 1):
            sc.column_dimensions[L(c)].width = wref
        last_sc_old, last_sc_new = L(tc), L(lastc)

    # ================= RAW DATA (hidden) - mirror of the XER
    if raw is not None:
        rs = {r: [copy.copy(raw.cell(r, c)._style) for c in range(4, 11)] for r in (6, 7, 8)}
        for r in range(6, raw.max_row + 1):
            for c in range(4, 11):
                clear_cell(raw.cell(r, c))

        def fd(d_, actual):
            if not d_:
                return None
            return d_.strftime("%d-%b-%y") + " A" if actual else d_

        rr = 6
        raw.cell(rr, 4, model["root_name"]); raw.cell(rr, 6, "%d.00d" % max(0, (wk_end - wk_start).days))
        raw.cell(rr, 7, wk_start); raw.cell(rr, 8, wk_end)
        for c in range(4, 11):
            raw.cell(rr, c)._style = copy.copy(rs[6][c - 4])
        for rw in rows[2:]:
            rr += 1
            ind = "  " * (rw["level"] - 2)
            if rw["kind"] == "sum":
                raw.cell(rr, 4, ind + rw["name"])
                acts = desc[rw["key"]]
                raw.cell(rr, 7, mn([a["cur_s"] or a["cur_f"] for a in acts])); raw.cell(rr, 8, mx([a["cur_f"] or a["cur_s"] for a in acts]))
                kind = 7
            else:
                a = rw["a"]
                raw.cell(rr, 4, ind + a["id"]); raw.cell(rr, 5, a["name"])
                raw.cell(rr, 6, "%.2fd" % a["dur"])
                raw.cell(rr, 7, fd(a["as_"] or a["es"], bool(a["as_"]))); raw.cell(rr, 8, fd(a["af"] or a["ef"], bool(a["af"])))
                raw.cell(rr, 9, a["p6pct"]); raw.cell(rr, 10, a["cal"])
                kind = 8
            for c in range(4, 11):
                raw.cell(rr, c)._style = copy.copy(rs[kind][c - 4])

    wb.calculation.fullCalcOnLoad = True
    wb.save(out)
    if sc is not None and last_sc_old:
        restore_chart(tpl_path, out, last_sc_old, last_sc_new)
    return dict(last_row=last, nweeks=nweeks, last_week_col=wl, sheet=pmsname, period=(st, fin),
                report_no=report_no, extra_warnings=warnings_extra, template_cfg=tpl_cfg, sc_last=last_sc_new)


# =============================================================== validation
def validate(model, out, wr, opts):
    """Re-open the produced workbook and check it. Returns (lines, n_errors, n_warnings)."""
    E, Wn, OK, INF = [], list(model["warnings"]) + list(wr["extra_warnings"]), [], list(model["infos"])
    rows = model["rows"]
    acts = model["acts"]
    last, wl = wr["last_row"], wr["last_week_col"]

    # 1. completeness
    n_act_rows = sum(1 for r in rows if r["kind"] == "act")
    if n_act_rows == model["n_tasks"]:
        OK.append("All %d activities of the XER were imported." % model["n_tasks"])
    else:
        E.append("Imported %d activities but the XER has %d in the selected project(s) - some activities have no "
                 "reachable WBS node." % (n_act_rows, model["n_tasks"]))
    n_sum = sum(1 for r in rows if r["kind"] == "sum" and r["level"] >= 2)
    OK.append("WBS rows written: %d of %d WBS nodes (%d empty WBS nodes %s)." % (
        n_sum - len(model["roots"]), model["n_wbs_total"], len(model["empty_wbs"]),
        "included" if model["include_empty"] else "not written"))
    if model["empty_wbs"] and not model["include_empty"]:
        INF.append("WBS nodes without any activity were not written: " + "; ".join(model["empty_wbs"][:15])
                   + (" ..." if len(model["empty_wbs"]) > 15 else ""))
    # 2. duplicates
    ids = Counter((a["proj"], a["id"]) for a in acts)
    same_proj = sorted({i for (pj, i), n in ids.items() if n > 1})
    by_id = defaultdict(set)
    for a in acts:
        by_id[a["id"]].add(a["proj"])
    cross = sorted(i for i, pj in by_id.items() if len(pj) > 1)
    if same_proj:
        E.append("Duplicate Activity IDs inside the same project (%d): %s" % (len(same_proj), ", ".join(same_proj[:10])))
    if cross:
        Wn.append("%d Activity IDs appear in more than one project of this XER (allowed by P6; each keeps its own row): %s%s"
                  % (len(cross), ", ".join(cross[:8]), " ..." if len(cross) > 8 else ""))
    if not same_proj and not cross:
        OK.append("No duplicate Activity IDs.")
    keys = Counter(r["key"] for r in rows)
    kd = [k for k, n in keys.items() if n > 1]
    if kd:
        E.append("Duplicate VLOOKUP KEYs (column A): %s" % ", ".join(kd[:10]))
    else:
        OK.append("VLOOKUP KEYs are unique.")
    # 3. WBS levels / order
    kset = set(keys)
    bad = [r["key"] for r in rows if r["level"] != len(r["key"].split(".")) or
           (r["level"] > 1 and ".".join(r["key"].split(".")[:-1]) not in kset)]
    if bad:
        E.append("WBS level/sequence inconsistency at keys: %s" % ", ".join(bad[:10]))
    else:
        OK.append("WBS levels and sequence are consistent (max level %d)." % max(r["level"] for r in rows))
    # 4. data gaps
    nod = [a["id"] for a in acts if a["type"] not in ("TT_Mile", "TT_FinMile") and not (a["ps"] and a["pf"])]
    if nod:
        Wn.append("%d activities have no planned start or finish (ignored by the S-curve): %s%s" % (
            len(nod), ", ".join(nod[:8]), " ..." if len(nod) > 8 else ""))
    inv = [a["id"] for a in acts if a["ps"] and a["pf"] and a["pf"] < a["ps"]]
    if inv:
        Wn.append("%d activities have planned finish before planned start: %s" % (len(inv), ", ".join(inv[:8])))
    tcnt = model["type_count"]
    odd = {k: v for k, v in tcnt.items() if k not in ("TT_Task", "TT_Mile", "TT_FinMile")}
    if odd:
        Wn.append("Activities of types that are not normal tasks/milestones were imported as activities: "
                  + ", ".join("%s=%d" % kv for kv in odd.items()) + " (check their weights).")
    nm = tcnt.get("TT_Mile", 0) + tcnt.get("TT_FinMile", 0)
    if nm:
        INF.append("%d milestones have a single date. Keep their weight at 0 (template behaviour)." % nm)
    # 5. baseline
    bl = model["baseline"]
    if bl["state"] == "FOUND":
        OK.append("Baseline FOUND for all selected projects: BL PROJECT START = %s, BL PROJECT FINISH = %s (%s)." % (
            bl["bl_start"].strftime("%d-%b-%Y") if bl["bl_start"] else "-",
            bl["bl_finish"].strftime("%d-%b-%Y") if bl["bl_finish"] else "-", bl["src"]))
    else:
        INF.append("Baseline status: %s (details in the Baseline diagnostics section)." % bl["state"])
    # 6. file structure + formulas
    try:
        with zipfile.ZipFile(out) as z:
            bad_member = z.testzip()
            has_chart = any(n.startswith("xl/charts/chart") for n in z.namelist())
        if bad_member:
            E.append("Corrupt member inside the xlsx: %s" % bad_member)
        wb = load_workbook(out)
        names = [s.title for s in wb]
        OK.append("Workbook re-opened successfully. Sheets: %s." % ", ".join(names))
        if not has_chart:
            E.append("The S-CURVE chart is missing from the output.")
        else:
            OK.append("S-CURVE chart present (range extended to column %s)." % wr["sc_last"])
        ws = wb[wr["sheet"]]
        miss = []
        need_sum = [6, 7, 19, 20, 21, 22, 23, 24, 25, 26, 27, 31, 32]
        need_act = [6, 19, 20, 21, 22, 23, 24, 25, 26, 27, 31, 32, WK0, CI(wl)]
        for r in rows:
            rr = r["row"]
            for c in (need_act if r["kind"] == "act" else need_sum):
                if c == 31 and rr == FIRST:
                    continue          # first sequence number is a constant in the template
                v = ws.cell(rr, c).value
                if not (isinstance(v, str) and v.startswith("=")):
                    miss.append("%s%d" % (L(c), rr))
        if miss:
            E.append("Formulas missing in %d cells (first: %s)." % (len(miss), ", ".join(miss[:8])))
        else:
            OK.append("Template formulas are present on all %d rows and on all %d weekly columns." % (len(rows), wr["nweeks"]))
        stale = 0
        last_act = max(r["row"] for r in rows if r["kind"] == "act")
        if "$1296" in str(ws.cell(last_act, 19).value) or ("$%d" % last) not in str(ws.cell(last_act, 19).value):
            stale += 1
        sc = wb["S-CURVE"]
        if last != 296 and "$296" in str(sc["D5"].value):
            stale += 1
        if stale:
            E.append("Some formulas still reference fixed row limits instead of the real last row (%d)." % last)
        else:
            OK.append("Formula ranges follow the real row count (last data row = %d)." % last)
        # no stray formulas left below/after the data
        wv_ = (model.get("weights") or {}).get("values") or {}
        carry_ = (model.get("cont") or {}).get("carry") or {}
        if wv_:
            expect_g = sum(1 for a in acts if wv_.get((a["proj"], a["id"])) is not None)
        else:
            expect_g = sum(1 for a in acts if (carry_.get((a["proj"], a["id"])) or {}).get("G") is not None)
        got_g = sum(1 for r in rows if r["kind"] == "act" and ws.cell(r["row"], 7).value not in (None, ""))
        if got_g != expect_g:
            E.append("Weights (column G): %d cells filled but %d expected." % (got_g, expect_g))
        elif expect_g == 0:
            OK.append("Weights, actual dates and actual quantities are empty as required (manual entry).")
        else:
            OK.append("Weights (column G) filled for %d activities as chosen; actual dates/quantities only where carried from the previous PMS." % got_g)
        nonblank_actuals = sum(1 for r in rows if r["kind"] == "act" and any(ws.cell(r["row"], c).value not in (None, "") for c in (10, 11, 16, 18)))
        exp_actuals = sum(1 for c_ in carry_.values() if c_.get("J") or c_.get("K") or c_.get("frac") is not None)
        if nonblank_actuals != exp_actuals:
            E.append("Actual inputs found on %d rows but %d expected." % (nonblank_actuals, exp_actuals))
        if wr["template_cfg"]["b1"] and ws["B1"].value == wr["template_cfg"]["b1"] and (opts.get("title") or model["title"]) != ws["B1"].value:
            E.append("The report header still shows the template project name.")
        else:
            OK.append("Report header updated from the XER: \"%s\"." % ws["B1"].value)
        if ws.max_row < last:
            E.append("Sheet is shorter than expected.")
    except Exception as e:  # noqa
        E.append("Could not re-open/check the produced file: %s" % e)
    INF.append("Weights (BUDGETED UNIT), actual dates and actual quantities are EMPTY: enter them manually.")
    INF.append("Company/Contractor lines come from the template (B2/B3) unless overridden: %s | %s" % (
        wr["template_cfg"]["company"], wr["template_cfg"]["contractor"]))
    return E, Wn, OK, INF



def write_report(path, model, wr, out, E, Wn, OK, INF, xer, enc):
    ln = []
    ln.append("تقرير التحقق / PMS validation report")
    ln.append("=" * 60)
    ln.append("XER: %s   (encoding: %s)" % (os.path.basename(xer), enc))
    ln.append("Output: %s" % os.path.basename(out))
    ln.append("Project: %s  |  %s" % (model["short"], model["title"]))
    ln.append("Rows: %d | Activities: %d | Weekly columns: %d | Report no.: %s | Period: %s -> %s" % (
        len(model["rows"]), len(model["acts"]), wr["nweeks"], wr["report_no"],
        wr["period"][0].strftime("%d-%b-%Y"), wr["period"][1].strftime("%d-%b-%Y")))
    ln.append("Result: %d error(s), %d warning(s)" % (len(E), len(Wn)))
    ln.append("")
    for title, items, tag in (("أخطاء / ERRORS", E, "[ERROR]"), ("تحذيرات تحتاج مراجعة / WARNINGS", Wn, "[WARNING]"),
                              ("تم التحقق منه / CHECKS PASSED", OK, "[OK]"), ("ملاحظات / NOTES", INF, "[INFO]")):
        ln.append("--- %s ---" % title)
        if not items:
            ln.append("(none)")
        for i in items:
            ln.append("%s %s" % (tag, i))
        ln.append("")
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(ln))


# =============================================================== WBS colour validation
def validate_colors(model, path, wr):
    """Re-open the produced workbook and compare the fill of every WBS row with the colour plan (provenance included).
    This checks the OUTPUT against the PLAN. It can never prove that the plan equals the colours shown in P6."""
    E, W, OK, INF = [], [], [], []
    plan = model["colors"]
    wb = load_workbook(path)
    ws = wb[wr["sheet"]]
    bad, act_filled, by_level = [], 0, {}
    for rw in model["rows"]:
        cell = ws.cell(rw["row"], 5)
        got = cell.fill.fgColor.rgb[-6:].upper() if (cell.fill.fill_type and cell.fill.fgColor.type == "rgb") else None
        if rw["kind"] == "act":
            if cell.fill.fill_type:
                act_filled += 1
            continue
        want = rw["color"][0]
        by_level.setdefault(rw["level"], set()).add(got)
        if got != want:
            bad.append("row %d (level %d): file has %s, plan says %s" % (rw["row"], rw["level"], got, want))
    if bad:
        E.append("WBS colours in the file differ from the colour plan on %d rows (first: %s)." % (len(bad), "; ".join(bad[:3])))
    else:
        OK.append("Every WBS row carries the colour decided by the colour plan (%d summary rows checked in the saved file)." % sum(
            1 for r_ in model["rows"] if r_["kind"] == "sum"))
    if act_filled:
        E.append("%d activity rows carry a WBS fill - activities must not use WBS styles." % act_filled)
    else:
        OK.append("No activity row uses a WBS fill (WBS rows and activities are formatted separately).")
    lv = sorted(by_level)
    mixed = [l for l in lv if len(by_level[l]) > 1]
    if mixed:
        E.append("Rows of the same WBS level have different colours at level(s) %s although no node override exists." % mixed) if not (
            plan["xer_nodes"] or (plan["user"] and plan["user"]["nodes"])) else INF.append(
            "Some levels contain nodes with their own colour (XER / node map): levels %s." % mixed)
    deep = [l for l in lv if l >= 7]
    if deep and plan["counts"].get(FALLBACK) and plan["counts"].get(FALLBACK) == plan["rows"]:
        same6 = [l for l in deep if 6 in by_level and by_level[l] == by_level[6]]
        if same6:
            E.append("Levels %s share the colour of level 6 although the fallback palette defines distinct colours." % same6)
        else:
            OK.append("Levels 7-%d are NOT forced to the level-6 colour (each level has its own palette colour)." % max(lv))
    return E, W, OK, INF


# =============================================================== validation report
def _lst(items, n=40):
    items = list(items)
    out = ["    - %s" % x for x in items[:n]]
    if len(items) > n:
        out.append("    ... and %d more" % (len(items) - n))
    return out


def write_report(path, ctx):
    m, wr, wres, cont, prev = ctx["model"], ctx["wr"], ctx["wres"], ctx.get("cont"), ctx.get("prev")
    E, Wn, OK, INF = ctx["E"], ctx["W"], ctx["OK"], ctx["INF"]
    rows = m["rows"]
    n_wbs = sum(1 for r in rows if r["kind"] == "sum" and r["level"] >= 2) - len(m["roots"])
    n_ms = m["type_count"].get("TT_Mile", 0) + m["type_count"].get("TT_FinMile", 0)
    ln = ["%s  v%s  -  PMS validation report / تقرير التحقق" % (APP_NAME, APP_VERSION), "=" * 72,
          "%s" % COPYRIGHT, ""]
    ln += ["XER file      : %s  (encoding %s)" % (os.path.basename(ctx["xer"]), ctx["enc"]),
           "Output        : %s" % os.path.basename(ctx["out"]),
           "Project       : %s  |  %s" % (m["short"], m["title"]),
           "Activities    : %d    WBS elements: %d    Milestones: %d    Weekly columns: %d" % (len(m["acts"]), n_wbs, n_ms, wr["nweeks"]),
           "Report no.    : %s    Period: %s -> %s" % (wr["report_no"], wr["period"][0].strftime("%d-%b-%Y"), wr["period"][1].strftime("%d-%b-%Y")),
           "Baseline      : %s" % m["baseline"]["state"],
           "Weight source : %s" % wres["label"] + ("  [applied]" if wres["applied"] else "  [not applied - G empty]" if wres["method"] != "none" else ""),
           "Previous PMS  : %s" % (os.path.basename(ctx["prev_path"]) if prev else "none (new report)"),
           "",
           "RESULT: %d error(s), %d warning(s)" % (len(E), len(Wn)),
           "  ERROR   = the file has a structural/data problem: do not use it before fixing.",
           "  WARNING = the file was created, but something needs your review.", ""]
    sections = [("ERRORS / أخطاء", E, "[ERROR]"), ("WARNINGS / تحذيرات تحتاج مراجعة", Wn, "[WARNING]")]
    for title, items, tag in sections:
        ln.append("--- %s ---" % title)
        ln += ["%s %s" % (tag, i) for i in items] or ["(none)"]
        ln.append("")
    # ---- baseline
    bl = m["baseline"]
    ln.append("--- BASELINE DIAGNOSTICS / فحص الـ Baseline ---")
    ln.append("State: %s   (planned dates source setting: %s)" % (bl["state"], bl["planned_source"]))
    ln.append({"FOUND": "FOUND: baseline located and activity dates matched by Activity ID.",
               "NOT_IN_FILE": "NOT_IN_FILE: the XER carries no baseline project and no sign of one.",
               "PARTIAL": "PARTIAL: baseline data is incomplete or cannot be linked reliably.",
               "NOT_EXPORTED": "NOT_EXPORTED: P6 has a baseline but it was not written into this XER."}[bl["state"]])
    ln += ["  " + x for x in bl["lines"]]
    for x in bl["per"]:
        if "total" in x:
            ln.append("  %s: %d of %d activities matched in the baseline." % (x["name"], x["matched"], x["total"]))
    if bl["bl_start"]:
        ln.append("  BL PROJECT START = %s, BL PROJECT FINISH = %s  (%s)" % (bl["bl_start"].strftime("%d-%b-%Y"), bl["bl_finish"].strftime("%d-%b-%Y"), bl["src"]))
    else:
        ln.append("  BL PROJECT START / FINISH were NOT filled (no usable baseline data).")
    if bl["state"] in ("NOT_IN_FILE", "NOT_EXPORTED", "PARTIAL"):
        ln += ["  How to fix: in P6 assign the baseline to the project (Project > Maintain Baselines > Assign) and re-export the XER",
               "  with the baseline included (export wizard: select the baseline(s) to export). Then run PMS GENERATOR again."]
    ln.append("")
    # ---- WBS colours
    col = m["colors"]
    ln.append("--- WBS COLOR VALIDATION / فحص ألوان الـ WBS ---")
    ln.append("Project: %s  [P6 project id: %s]" % (col["project"], col["project_id"]))
    ln.append("P6 WBS rows processed: %d (+1 PMS overall row, colour source: %s)    WBS levels detected: %d (1 .. %d, as shown in column B)" % (
        col["rows"], col["overall_source"], len(col["levels"]), col["max_level"]))
    cn = col["counts"]
    ln.append("Rows with VERIFIED source colours (explicit data in this XER): %d" % cn.get(VERIFIED, 0))
    ln.append("Rows with USER-SUPPLIED colours (colour map for this project): %d" % cn.get(USER, 0))
    ln.append("Rows using FALLBACK colours (standard palette, not P6's): %d" % cn.get(FALLBACK, 0))
    ln.append("Rows with NO colour / original colour unavailable: %d" % cn.get(UNAVAILABLE, 0))
    unverified = cn.get(USER, 0) + cn.get(FALLBACK, 0) + cn.get(UNAVAILABLE, 0)
    ln.append("Rows whose original P6 colour could NOT be verified: %d of %d" % (unverified, col["rows"]))
    ln += ["  XER search: " + x for x in col["xer_info"]]
    if col["user"]:
        ln.append("  User colour source: %s" % col["user"]["origin"])
    if col["exact_possible"]:
        ln.append("EXACT COLOR FIDELITY: colours come from explicit data in the XER for every WBS row; the saved file was checked against them.")
    else:
        ln.append("EXACT COLOR FIDELITY WITH P6: NOT VERIFIED. Reason: " + (
            "the XER carries no WBS colour data (P6 stores the displayed band colours in the layout, which the XER does not export)"
            if not cn.get(VERIFIED) else "only %d of %d rows have colour data in the XER" % (cn.get(VERIFIED, 0), col["rows"])) +
            "; the other rows use user-supplied or fallback colours.")
    ln.append("  Level  Rows  Source(s)                         Colour(s)")
    for lv in sorted(col["levels"]):
        d = col["levels"][lv]
        ln.append("  %5d  %4d  %-32s  %s" % (lv, d["rows"], ", ".join("%s x%d" % kv for kv in d["sources"].items()),
                                            ", ".join("#" + c if c != "-" else "none" for c in d["colors"])))
    ln.append("")
    # ---- weights
    ln.append("--- WEIGHTS / الأوزان ---")
    ln.append("Method: %s" % wres["label"])
    if wres["applied"]:
        have = sum(1 for v in wres["values"].values() if v)
        ln.append("Column G unit: %s   |   activities with weight > 0: %d   |   total G = %.4f  (F = G/total, so weights add up to 100%%)" % (
            wres["unit"], have, wres["total"]))
    for x in wres["notes"]:
        ln.append("  note: " + x)
    for x in wres["warnings"]:
        ln.append("  [WARNING] " + x)
    if wres["missing"]:
        ln.append("  Activities WITHOUT enough data - G left EMPTY, they are excluded from the weighted progress (%d):" % len(wres["missing"]))
        ln += _lst(wres["missing"])
    if wres["zero_weight"]:
        ln.append("  Activities given weight 0 (%d):" % len(wres["zero_weight"]))
        ln += _lst(wres["zero_weight"], 15)
    ln.append("  These weights are calculated from schedule data; they are NOT contractual weights unless you confirm them.")
    ln.append("")
    # ---- continuation
    ln.append("--- PREVIOUS PMS / استكمال التقرير ---")
    if not prev:
        ln += ["Not used: this is a new report (report no. starts at 1).", ""]
    else:
        st = cont["stats"]
        ln.append("Previous PMS: %s (sheet %s) | report no. %s | period finish %s" % (
            os.path.basename(ctx["prev_path"]), prev["sheet"], int(prev["report_no"]) if prev.get("report_no") else "?",
            prev["period_finish"].strftime("%d-%b-%Y") if prev.get("period_finish") else "?"))
        ln.append("Matched %d of %d activities (exact %d, renamed %d, moved %d); new %d; suspect %d; ambiguous %d; removed from schedule %d." % (
            st["matched"], st["total"], st["exact"], st["renamed"], st["moved"], st["new"], st["suspect"], st["ambiguous"], st["removed"]))
        ln.append("Carried for matched activities: weights (only if no automatic weight method was chosen), actual dates, cumulative progress "
                  "(as fraction = CUM / BUG QTY), previous period = previous cumulative; S-CURVE history rows.")
        for key, title in (("suspect", "NOT transferred - same Activity ID but different name AND WBS (check by hand)"),
                           ("ambiguous", "NOT transferred - ambiguous Activity ID"), ("renamed", "Transferred - name changed"),
                           ("moved", "Transferred - WBS path changed"), ("new", "New activities (no previous data)"),
                           ("no_bugqty", "Progress NOT carried - previous BUG QTY missing/0"), ("out_of_range", "Carried but outside 0-100%"),
                           ("converted", "Progress converted from quantity to % (previous BUG QTY was not 100%)")):
            items = cont["lists"].get(key)
            if items:
                ln.append("  %s (%d):" % (title, len(items)))
                ln += _lst(items, 25)
        if cont["removed"]:
            ln.append("  Activities of the previous PMS that are no longer in the XER (%d), not carried:" % len(cont["removed"]))
            ln += _lst(cont["removed"], 25)
        ln.append("")
    for title, items, tag in (("CHECKS PASSED / تم التحقق منه", OK, "[OK]"), ("NOTES / ملاحظات", INF, "[INFO]")):
        ln.append("--- %s ---" % title)
        ln += ["%s %s" % (tag, i) for i in items] or ["(none)"]
        ln.append("")
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(ln))


# =============================================================== public API
def resolve_report_no(opts, prev):
    if opts.get("report_no") is not None:
        return int(opts["report_no"])
    if prev and prev.get("report_no"):
        return int(prev["report_no"]) + 1
    return 1


def generate(xer, out=None, template=None, progress=None, overwrite=False, **opts):
    """Convert one XER to a PMS workbook.

    opts: projects, baseline, planned_source('auto'|'current'), weight_method, custom_cost_file, previous, report_no,
          period_start, period_finish, title, company, contractor, overall_label, sheet_name, out_dir, include_empty_wbs
    Raises PmsError (blocking), PmsExistsError (file exists, overwrite=False), PmsChooseProject (several projects).
    """
    def step(pct, msg):
        log.info("[%s%%] %s", pct, msg)
        if progress:
            progress(pct, msg)

    log.info("=== generate %s | opts=%s", xer, {k: v for k, v in opts.items() if v not in (None, "", False)})
    step(3, "Reading the XER file")
    tpl = find_template(template)
    T, enc = parse_xer(xer)
    step(18, "Analysing projects, WBS and baseline")
    model = build_model(T, opts)
    step(26, "Resolving WBS colours")
    colors = resolve_colors(T, model, opts)
    model["colors"] = colors
    step(32, "Computing weights")
    wres = compute_weights(T, model, opts)
    model["weights"] = wres
    prev = cont = None
    prev_path = opts.get("previous")
    if prev_path:
        step(40, "Reading the previous PMS")
        prev = read_previous_pms(prev_path)
        cont = match_activities(model, prev)
        model["prev"], model["cont"] = prev, cont
    work = [a for a in model["acts"] if a["type"] not in ("TT_Mile", "TT_FinMile", "TT_LOE", "TT_WBS")]
    if wres["applied"]:
        n_w = sum(1 for a in work if wres["values"].get((a["proj"], a["id"])))
    else:
        n_w = sum(1 for a in work if (cont or {"carry": {}})["carry"].get((a["proj"], a["id"]), {}).get("G"))
    model["weights_state"] = "empty" if n_w == 0 else ("full" if n_w == len(work) else "partial")

    out_dir = opts.get("out_dir") or os.path.dirname(os.path.abspath(xer))
    if not out:
        rn = resolve_report_no(opts, prev)
        out = os.path.join(out_dir, "PMS_%s_Rev%02d.xlsx" % (safe_filename(model["short"]), max(0, rn - 1)))
    out = os.path.abspath(out)
    rep = os.path.splitext(out)[0] + "_validation.txt"
    if (os.path.exists(out) or os.path.exists(rep)) and not overwrite:
        raise PmsExistsError(out if os.path.exists(out) else rep)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    part = os.path.splitext(out)[0] + ".~part.xlsx"
    step(50, "Building the PMS workbook (%d rows)" % len(model["rows"]))
    try:
        wr = write_pms(model, tpl, part, opts)
        step(82, "Validating the result")
        E, Wn, OK, INF = validate(model, part, wr, opts)
        cE, cW, cOK, cINF = validate_colors(model, part, wr)
        E, Wn, OK, INF = E + cE, Wn + colors["warnings"] + cW, OK + cOK, INF + colors["infos"] + cINF
        Wn = Wn + [("Weights: " + w) for w in wres["warnings"]]
        if wres["method"] != "none" and not wres["applied"]:
            Wn.append("The chosen weight method could not be applied - column G is EMPTY.")
        if model["weights_state"] == "partial":
            Wn.append("Weights are incomplete: %d activities have no weight data (see the Weights section)." % len(wres["missing"]))
        if model["weights_state"] == "empty":
            Wn.append("Weights are EMPTY: weighted progress and the S-curve are not meaningful until BUDGETED UNIT is entered.")
        if prev:
            Wn += ["Previous PMS: " + w for w in prev["warnings"]]
            st = cont["stats"]
            if st["matched"] == 0:
                Wn.append("NONE of the previous PMS activities could be matched - is it the same project?")
            elif st["matched"] < 0.5 * st["total"]:
                Wn.append("Only %d of %d activities matched the previous PMS - check that it is the right file." % (st["matched"], st["total"]))
            if st["suspect"] or st["ambiguous"]:
                Wn.append("%d activities share an ID with the previous PMS but could not be matched safely - their previous data was NOT carried." % (
                    st["suspect"] + st["ambiguous"]))
        try:
            os.replace(part, out)
        except PermissionError:
            raise PmsError("Cannot write %s - is it open in Excel? Close it and try again." % out)
    finally:
        if os.path.exists(part):
            try:
                os.remove(part)
            except OSError:
                pass
    if not (os.path.isfile(out) and os.path.getsize(out) > 0):
        raise PmsError("The Excel file was not saved correctly: %s" % out)
    step(94, "Writing the validation report")
    write_report(rep, dict(xer=xer, enc=enc, out=out, model=model, wr=wr, wres=wres, cont=cont, prev=prev,
                           prev_path=prev_path, E=E, W=Wn, OK=OK, INF=INF))
    step(100, "Done")
    log.info("done: %s | errors=%d warnings=%d", out, len(E), len(Wn))
    return dict(output=out, report=rep, errors=E, warnings=Wn, ok=OK, info=INF, rows=len(model["rows"]),
                activities=len(model["acts"]), weeks=wr["nweeks"], project=model["short"], title=model["title"],
                baseline_state=model["baseline"]["state"], weights_state=model["weights_state"], weight_label=wres["label"],
                colors=dict(counts=colors["counts"], rows=colors["rows"], max_level=colors["max_level"], exact_possible=colors["exact_possible"]),
                matches=(cont or {}).get("stats"), log=log_path(), report_no=wr["report_no"])


# =============================================================== CLI
def parse_date(s):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d")
    except ValueError:
        raise PmsError("Dates must be written as YYYY-MM-DD (got %r)." % s)


def cli(argv):
    ap = argparse.ArgumentParser(description="%s v%s - %s" % (APP_NAME, APP_VERSION, "Primavera P6 XER -> PMS Excel"),
                                 epilog=COPYRIGHT)
    ap.add_argument("xer", nargs="*", help="one or more .xer files")
    ap.add_argument("--inspect", action="store_true", help="only show projects / baseline / resources found in the XER")
    ap.add_argument("--template", help="override the master template")
    ap.add_argument("-o", "--output", help="output .xlsx (single XER only)")
    ap.add_argument("--out-dir", help="output folder (default: next to the XER)")
    ap.add_argument("--overwrite", action="store_true", help="replace existing output files without asking")
    ap.add_argument("--projects", help="project id(s)/name part(s), comma separated, or 'all' (needed when the XER has several)")
    ap.add_argument("--baseline", help="baseline project id/name part, when the XER has several")
    ap.add_argument("--planned-source", choices=["auto", "current"], default="auto",
                    help="auto = baseline dates when a baseline exists, else current planned dates")
    ap.add_argument("--weights", choices=list(METHODS), default="none", help="weight method (default none = manual)")
    ap.add_argument("--custom-cost", help="CSV/XLSX with 'Activity ID' and 'Cost' (with --weights cost_custom)")
    ap.add_argument("--previous", help="previous PMS .xlsx to continue the next period")
    ap.add_argument("--period-start", help="YYYY-MM-DD"); ap.add_argument("--period-finish", help="YYYY-MM-DD (default: P6 Data Date)")
    ap.add_argument("--report-no", type=int, help="default: previous+1, or 1")
    ap.add_argument("--include-empty-wbs", action="store_true", help="also write WBS nodes without activities")
    ap.add_argument("--wbs-colors", help="WBS colour map for THIS project: .json / .csv (Level,Color) or a PMS .xlsx to copy the level colours from")
    ap.add_argument("--no-remember-colors", action="store_true", help="do not save --wbs-colors as the saved map of this project")
    ap.add_argument("--fallback-colors", choices=["standard", "none"], default="standard",
                    help="rows without a colour source: standard palette (reported as FALLBACK) or no fill")
    ap.add_argument("--title"); ap.add_argument("--overall-label")
    ap.add_argument("--company"); ap.add_argument("--contractor"); ap.add_argument("--sheet-name")
    ap.add_argument("--version", action="version", version="%s %s" % (APP_NAME, APP_VERSION))
    a = ap.parse_args(argv)
    if not a.xer:
        ap.error("give at least one .xer file (or run without arguments for the window)")
    if a.output and len(a.xer) > 1:
        raise PmsError("-o can be used with a single XER only.")
    code = 0
    for x in a.xer:
        if a.inspect:
            info = inspect_xer(x)
            print("File: %s (%.1f KB, %s)  tasks: %d" % (os.path.basename(x), info["size"] / 1024.0, info["encoding"], info["tasks"]))
            for p in info["projects"]:
                print("  project [id %s] %s | %s | %d activities | data date %s" % (p["id"], p["short"], p["root"], p["tasks"],
                      p["data_date"].strftime("%d-%b-%Y") if p["data_date"] else "-"))
            print("  baseline state: %s" % info["baseline_state"])
            for l in info["baseline_lines"]:
                print("    " + l)
            print("  resources: %s" % info["resources"])
            print("  WBS colours: %s" % info["colors"]["summary"])
            for l in info["colors"]["xer_info"]:
                print("    " + l)
            continue
        res = generate(x, a.output, a.template, overwrite=a.overwrite, out_dir=a.out_dir, period_start=parse_date(a.period_start),
                       period_finish=parse_date(a.period_finish), report_no=a.report_no, projects=a.projects,
                       baseline=a.baseline, planned_source=a.planned_source, weight_method=a.weights,
                       custom_cost_file=a.custom_cost, previous=a.previous, include_empty_wbs=a.include_empty_wbs,
                       title=a.title, overall_label=a.overall_label, company=a.company, contractor=a.contractor,
                       sheet_name=a.sheet_name, wbs_colors=a.wbs_colors, remember_colors=not a.no_remember_colors,
                       fallback_colors=a.fallback_colors)
        print("Done: %s" % res["output"])
        print("Report: %s" % res["report"])
        print("Project: %s | rows %d | activities %d | weeks %d | baseline %s | weights %s" % (
            res["project"], res["rows"], res["activities"], res["weeks"], res["baseline_state"], res["weights_state"]))
        print("Errors: %d | Warnings: %d" % (len(res["errors"]), len(res["warnings"])))
        for e in res["errors"]:
            print("  [ERROR]", e)
        for w in res["warnings"]:
            print("  [WARNING]", w[:300])
        code = code or (1 if res["errors"] else 0)
    return code


# =============================================================== simple Tk window (fallback only: used when PySide6 is not installed)
def run_gui(preload=None):
    import queue
    import subprocess
    import threading
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("P6 XER to PMS Generator  v%s" % APP_VERSION)
    root.geometry("760x560")
    pad = dict(padx=8, pady=4)
    v_xer, v_out = tk.StringVar(value=preload or ""), tk.StringVar()
    v_rep, v_fin = tk.StringVar(value="1"), tk.StringVar()
    v_empty = tk.BooleanVar(value=False)
    v_title = tk.StringVar()

    frm = ttk.Frame(root, padding=10)
    frm.pack(fill="both", expand=True)
    frm.columnconfigure(1, weight=1)

    def browse_xer():
        p = filedialog.askopenfilename(title="Select the P6 XER file", filetypes=[("Primavera XER", "*.xer"), ("All", "*.*")])
        if p:
            v_xer.set(p)
            if not v_out.get():
                v_out.set(os.path.dirname(p))

    def browse_out():
        p = filedialog.askdirectory(title="Output folder")
        if p:
            v_out.set(p)

    ttk.Label(frm, text="XER file").grid(row=0, column=0, sticky="w", **pad)
    ttk.Entry(frm, textvariable=v_xer).grid(row=0, column=1, sticky="ew", **pad)
    ttk.Button(frm, text="Browse...", command=browse_xer).grid(row=0, column=2, **pad)
    ttk.Label(frm, text="Output folder").grid(row=1, column=0, sticky="w", **pad)
    ttk.Entry(frm, textvariable=v_out).grid(row=1, column=1, sticky="ew", **pad)
    ttk.Button(frm, text="Browse...", command=browse_out).grid(row=1, column=2, **pad)
    ttk.Label(frm, text="Report number").grid(row=2, column=0, sticky="w", **pad)
    ttk.Entry(frm, textvariable=v_rep, width=8).grid(row=2, column=1, sticky="w", **pad)
    ttk.Label(frm, text="Period finish (YYYY-MM-DD, empty = P6 Data Date)").grid(row=3, column=0, columnspan=2, sticky="w", **pad)
    ttk.Entry(frm, textvariable=v_fin, width=14).grid(row=3, column=2, sticky="e", **pad)
    ttk.Checkbutton(frm, text="Also write WBS nodes that have no activities", variable=v_empty).grid(
        row=4, column=0, columnspan=3, sticky="w", **pad)
    ttk.Label(frm, text="Report title (empty = root WBS name from XER)").grid(row=5, column=0, sticky="w", **pad)
    ttk.Entry(frm, textvariable=v_title).grid(row=5, column=1, columnspan=2, sticky="ew", **pad)
    btn = ttk.Button(frm, text="Generate PMS")
    btn.grid(row=6, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
    log = tk.Text(frm, height=16, wrap="word")
    log.grid(row=7, column=0, columnspan=3, sticky="nsew", **pad)
    frm.rowconfigure(7, weight=1)
    q = queue.Queue()
    state = {"out": None}

    def say(s):
        log.insert("end", s + "\n")
        log.see("end")

    def work(xer, outdir, rep, fin, empty, title):
        try:
            res = generate(xer, None, None, out_dir=outdir or None, report_no=rep, period_finish=fin,
                           include_empty_wbs=empty, title=title or None)
            q.put(("ok", res))
        except PmsChooseProject:
            q.put(("err", "This XER contains several projects. The simple window cannot choose one: install PySide6 "
                          "(pip install PySide6) to get the full window, or use the command line with --projects."))
        except PmsExistsError as e:
            q.put(("err", "The output file already exists:\n%s\nMove or rename it and try again." % e.path))
        except PmsError as e:
            q.put(("err", str(e)))
        except Exception as e:  # noqa
            import traceback
            q.put(("err", "Unexpected error: %s\n%s" % (e, traceback.format_exc())))

    def poll():
        try:
            kind, res = q.get_nowait()
        except queue.Empty:
            root.after(200, poll)
            return
        btn.config(state="normal")
        if kind == "err":
            say("ERROR: " + res)
            messagebox.showerror("PMS Generator", res)
            return
        state["out"] = res["output"]
        say("Done: " + res["output"])
        say("Validation report: " + res["report"])
        say("Project: %s | rows %d | activities %d | weeks %d" % (res["project"], res["rows"], res["activities"], res["weeks"]))
        say("Errors: %d | Warnings: %d" % (len(res["errors"]), len(res["warnings"])))
        for e in res["errors"]:
            say("[ERROR] " + e)
        for w in res["warnings"]:
            say("[WARNING] " + w)
        if messagebox.askyesno("PMS Generator", "PMS created (%d errors, %d warnings).\nOpen the output folder?" % (
                len(res["errors"]), len(res["warnings"]))):
            folder = os.path.dirname(res["output"])
            if sys.platform.startswith("win"):
                os.startfile(folder)  # noqa
            else:
                subprocess.Popen(["xdg-open", folder])

    def start():
        x = v_xer.get().strip().strip('"')
        if not x or not os.path.isfile(x):
            messagebox.showwarning("PMS Generator", "Select an existing .xer file first.")
            return
        try:
            rep = int(v_rep.get().strip() or "1")
            fin = parse_date(v_fin.get().strip())
        except (ValueError, PmsError) as e:
            messagebox.showwarning("PMS Generator", "Check report number / date format.\n%s" % e)
            return
        btn.config(state="disabled")
        say("Working ...")
        threading.Thread(target=work, args=(x, v_out.get().strip(), rep, fin, v_empty.get(), v_title.get().strip()), daemon=True).start()
        root.after(200, poll)

    btn.config(command=start)
    if preload:
        v_out.set(os.path.dirname(os.path.abspath(preload)))
    root.mainloop()




def main():
    args = sys.argv[1:]
    try:
        if not args or (len(args) == 1 and args[0].lower().endswith(".xer") and getattr(sys, "frozen", False)):
            preload = args[0] if args else None
            try:
                from pms_gui import run as run_modern_gui
            except ImportError:
                run_modern_gui = None
            if run_modern_gui:
                return run_modern_gui(preload) or 0
            run_gui(preload)
            return 0
        return cli(args)
    except PmsChooseProject as e:
        print("ERROR: %s\nUse: --projects <id or name> (or --projects all)" % e, file=sys.stderr)
        return 2
    except PmsExistsError as e:
        print("ERROR: %s\nUse --overwrite to replace it." % e, file=sys.stderr)
        return 2
    except PmsError as e:
        print("ERROR: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
